package com.onedirect.migrationapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnedirectMigrationServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}

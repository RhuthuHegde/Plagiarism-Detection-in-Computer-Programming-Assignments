package com.onedirect.migrationapi.configs;

import com.onedirect.migrationapi.constants.BeanConstant;
import com.onedirect.migrationapi.constants.DataConfigConstant;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.*;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Map;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    entityManagerFactoryRef = BeanConstant.CUSTOMER_MASTER_ENTITY_MANAGER_FACTORY,
    transactionManagerRef = BeanConstant.CUSTOMER_MASTER_TRANS_MANAGER,
    basePackages = {DataConfigConstant.CUSTOMER_MASTER_REPO_PACKAGE})
@PropertySources(value = {@PropertySource("classpath:dataSourcesConfig.properties")})
public class CustomerDataSourceDbMasterConfig {

  private final Map<String, Object> jpaRepo;

  public CustomerDataSourceDbMasterConfig(@Qualifier(BeanConstant.JPA_REPO) Map<String, Object> jpaRepo) {
    this.jpaRepo = jpaRepo;
  }

  @Bean(name = BeanConstant.CUSTOMER_MASTER_TRANS_MANAGER)
  public PlatformTransactionManager transactionManager(
      @Qualifier(BeanConstant.CUSTOMER_MASTER_ENTITY_MANAGER_FACTORY)
          EntityManagerFactory entityManagerFactory) {
    return new JpaTransactionManager(entityManagerFactory);
  }

  @Bean(name = BeanConstant.CUSTOMER_MASTER_ENTITY_MANAGER_FACTORY)
  public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(
      final EntityManagerFactoryBuilder builder,
      @Qualifier(BeanConstant.CUSTOMER_MASTER_DATA_SOURCE) DataSource dataSource) {
    return builder
        .dataSource(dataSource)
        .properties(jpaRepo)
        .packages(DataConfigConstant.ENTITY_PACKAGE)
        .persistenceUnit(DataConfigConstant.CUSTOMER_MASTER_REPO_PROCESS_NAME)
        .build();
  }

  @Bean(name = BeanConstant.CUSTOMER_MASTER_DATA_SOURCE)
  @ConfigurationProperties(prefix = DataConfigConstant.CUSTOMER_MASTER_DATA_SOURCE)
  public DataSource masterDataSource(
      @Qualifier(BeanConstant.CUSTOMER_MASTER_DATA_SOURCE_PROPERTIES)
          DataSourceProperties dataSourceProperties) {
    return dataSourceProperties.initializeDataSourceBuilder().build();
  }

  @Bean(BeanConstant.CUSTOMER_MASTER_DATA_SOURCE_PROPERTIES)
  @ConfigurationProperties(DataConfigConstant.CUSTOMER_MASTER_DATA_SOURCE)
  public DataSourceProperties masterDataSourceProperties() {
    return new DataSourceProperties();
  }
}

package com.onedirect.migrationapi.entities.zoho.ticket;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoTicketTeam {

    private Long id;
    private String name;
}

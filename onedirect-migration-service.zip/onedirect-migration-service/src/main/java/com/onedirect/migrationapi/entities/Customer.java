package com.onedirect.migrationapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "customer")
public class Customer implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_name")
    private String name;

    @Column(name = "customer_source")
    private Byte source;

    @Column(name = "customer_handle")
    private String handle;

    @Column(name = "source_user_id")
    private String sourceUserId;

    @Column(name = "profile_picture_url")
    private String profilePictureUrl;

    @Column(name = "status")
    private Byte status;

    @Column(name = "is_spammer")
    private Byte isSpammer;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "brand_id")
    private Integer brandId;

    @Column(name = "product_id")
    private Byte productId;

    @Column(name = "external_customer_id")
    private Long externalCustomerId;

    @Column(name = "brand_customer_uid")
    private String brandCustomerId;

}


package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.repos.email.master.ForwardFeedRepo;
import com.onedirect.migrationapi.services.ForwardFeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ForwardFeedServiceImpl implements ForwardFeedService {
    @Autowired
    ForwardFeedRepo forwardFeedRepo;

    @Override
    public ForwardFeed createForwardFeed(ForwardFeed forwardFeed) {
        return forwardFeedRepo.save(forwardFeed);
    }

}

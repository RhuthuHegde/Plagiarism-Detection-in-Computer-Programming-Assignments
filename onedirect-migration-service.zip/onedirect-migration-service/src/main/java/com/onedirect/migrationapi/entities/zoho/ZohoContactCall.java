package com.onedirect.migrationapi.entities.zoho;

import com.onedirect.migrationapi.entities.zoho.ticket.ZohoTicket;
import lombok.*;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoContactCall {
    private Long id;
    private ZohoCustomFields cf;
    private Long departmentId;
    private String subject;
    private Date startTime;
    private String direction;
    private String duration;
    private String status;
    private Long ownerId;
    private String priority;
    private String description;
    private Date createdTime;
    private Date modifiedTime;
    private Long creatorId;
    private Long ticketId;
    private Long contactId;
    private ZohoTicket ticket;

}

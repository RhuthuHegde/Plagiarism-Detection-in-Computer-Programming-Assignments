package com.onedirect.migrationapi.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ForwardFeedAttachmentDto {

    private String attachmentName;

    private String attachmentUrl;

    private Integer attachmentSize;

    private Integer s3Bucket;
}

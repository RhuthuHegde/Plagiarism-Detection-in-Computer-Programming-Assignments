package com.onedirect.migrationapi.pojos;

import com.onedirect.migrationapi.enums.TicketFieldValueTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TicketFieldLabel {
    private Integer labelId;
    private TicketFieldValueTypeEnum ticketFieldValueType;
}

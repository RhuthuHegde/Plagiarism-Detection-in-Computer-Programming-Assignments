package com.onedirect.migrationapi.services.xmlhandler;

import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskAttachment;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskTicketsDto;
import com.onedirect.migrationapi.dtos.freshdesk.conversation.HelpdeskNote;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.FreshdeskCustomField;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.HelpdeskTag;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.HelpdeskTicket;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class TicketHandler extends DefaultHandler {
    private static final String HELPDESK_TICKETS = "helpdesk-tickets";
    private static final String HELPDESK_TICKET = "helpdesk-ticket";
    private static final String CREATED_AT = "created-at"; //dupe
    private static final String DESCRIPTION = "description";
    private static final String DESCRIPTION_HTML = "description-html";
    private static final String DISPLAY_ID = "display-id";
    private static final String REQUESTER_ID = "requester-id";
    private static final String RESPONDER_ID = "responder-id";
    private static final String SOURCE = "source"; //dupe
    private static final String STATUS = "status";
    private static final String SUBJECT = "subject";
    private static final String UPDATED_AT = "updated-at";//dupe
    private static final String PRIORITY = "priority";
    private static final String TICKET_TYPE = "ticket-type";

    private static final String NOTES = "notes";
    private static final String HELPDESK_NOTE = "helpdesk-note";
    private static final String BODY = "body";
    private static final String ATTACHMENTS = "attachments";
    private static final String TAGS = "tags";
    private static final String BODY_HTML = "body-html";
    private static final String INCOMING = "incoming";
    private static final String PRIVATE = "private";

    private static final String TAG = "tag";
    private static final String TAG_NAME = "name";

    private static final String ATTACHMENT = "attachment";
    private static final String CONTENT_TYPE = "content-content-type";
    private static final String CONTENT_FILE_NAME = "content-file-name";
    private static final String CONTENT_FILE_SIZE = "content-file-size";
    private static final String ID="id"; //dupe
    private static final String ATTACHMENT_URL = "attachment_url";

    private static final String CUSTOM_FIELD = "custom_field";

    private FreshdeskTicketsDto freshdeskTicketsDto;
    private StringBuilder elementValue;
    private Stack<String> elementStack;

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (elementValue == null) {
            elementValue = new StringBuilder();
        } else {
            elementValue.append(ch, start, length);
        }
    }

    @Override
    public void startDocument() throws SAXException {
        freshdeskTicketsDto = new FreshdeskTicketsDto();
        elementStack = new Stack<>();
    }

    @Override
    public void startElement(String uri, String lName, String qName, Attributes attr) throws SAXException {
        switch (qName) {
            case HELPDESK_TICKETS:
                freshdeskTicketsDto.setHelpdeskTicketList(new ArrayList<>());
                break;
            case HELPDESK_TICKET:
                elementStack.push(HELPDESK_TICKET);
                freshdeskTicketsDto.getHelpdeskTicketList().add(new HelpdeskTicket());
                break;
            case NOTES:
                latestTicket().setNotes(new ArrayList<>());
                break;
            case HELPDESK_NOTE:
                elementStack.push(HELPDESK_NOTE);
                latestTicket().getNotes().add(new HelpdeskNote());
                break;
            case ATTACHMENTS:
                addAttachments();
                break;
            case ATTACHMENT:
                addAttachment();
                elementStack.push(ATTACHMENT);
                break;
            case TAGS:
                latestTicket().setHelpdeskTagList(new ArrayList<>());
                break;
            case TAG:
                elementStack.push(TAG);
                latestTicket().getHelpdeskTagList().add(new HelpdeskTag());
                break;
            case CUSTOM_FIELD:
                elementStack.push(CUSTOM_FIELD);
                latestTicket().setCustomFieldList(new ArrayList<>());
                break;
            case CREATED_AT:
            case PRIORITY:
            case UPDATED_AT:
            case SUBJECT:
            case STATUS:
            case SOURCE:
            case RESPONDER_ID:
            case REQUESTER_ID:
            case DISPLAY_ID:
            case DESCRIPTION:
            case BODY:
            case ID:
            case TAG_NAME:
            case CONTENT_TYPE:
            case CONTENT_FILE_NAME:
            case ATTACHMENT_URL:
            case CONTENT_FILE_SIZE:
            case BODY_HTML:
            case DESCRIPTION_HTML:
            case INCOMING:
            case PRIVATE:
            case TICKET_TYPE:
                elementValue = new StringBuilder();
                break;
        }
        if (!elementStack.isEmpty() && elementStack.peek().equals(CUSTOM_FIELD)){
            elementValue = new StringBuilder();
        }
    }


    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        switch (qName) {
            case HELPDESK_TICKET:
            case HELPDESK_NOTE:
            case ATTACHMENT:
            case TAG:
            case CUSTOM_FIELD:
                elementStack.pop();
                break;
            case CREATED_AT:
                setCreatedAt(elementValue.toString());
                break;
            case DESCRIPTION:
                latestTicket().setDescription(elementValue.toString());
                break;
            case DESCRIPTION_HTML:
                latestTicket().setDescriptionHtml(elementValue.toString());
                break;
            case DISPLAY_ID:
                try{
                    latestTicket().setDisplayId(Long.parseLong(elementValue.toString()));
                }catch (NumberFormatException e){
                    latestTicket().setDisplayId(null);
                }

                break;
            case REQUESTER_ID:
                try {
                    latestTicket().setRequesterId(Long.parseLong(elementValue.toString()));
                }catch (Exception e){
                    latestTicket().setRequesterId(null);
                }
                break;
            case RESPONDER_ID:
                try {
                    latestTicket().setResponderId(Long.parseLong(elementValue.toString()));
                }catch (Exception e){
                    latestTicket().setResponderId(null);
                }
                break;
            case SOURCE:
                setSource(elementValue.toString());
                break;
            case STATUS:
                try {
                    latestTicket().setStatus(Integer.parseInt(elementValue.toString()));
                }catch (Exception e){
                    latestTicket().setStatus(null);
                }
                break;
            case SUBJECT:
                latestTicket().setSubject(elementValue.toString());
                break;
            case UPDATED_AT:
                setUpdatedAt(elementValue.toString());
                break;
            case PRIORITY:
                try {
                    latestTicket().setPriority(Integer.parseInt(elementValue.toString()));
                }catch (Exception e){
                    latestTicket().setPriority(null);
                }
                break;
            case BODY:
                latestNote().setBody(elementValue.toString());
                break;
            case BODY_HTML:
                latestNote().setBodyHtml(elementValue.toString());
                break;
            case TAG_NAME:
                latestTag().setName(elementValue.toString());
                break;
            case ID:
                setID(elementValue.toString());
                break;
            case CONTENT_TYPE:
                latestAttachment().setContentType(elementValue.toString());
                break;
            case CONTENT_FILE_NAME:
                latestAttachment().setContentFileName(elementValue.toString());
                break;
            case ATTACHMENT_URL:
                latestAttachment().setAttachmentUrl(elementValue.toString());
                break;
            case CONTENT_FILE_SIZE:
                latestAttachment().setContentFileSize(Integer.parseInt(elementValue.toString()));
                break;
            case INCOMING:
                latestNote().setIncoming(Boolean.valueOf(elementValue.toString()));
                break;
            case PRIVATE:
                latestNote().set_private(Boolean.valueOf(elementValue.toString()));
                break;
            case TICKET_TYPE:
                latestTicket().setTicketType(elementValue.toString());
                break;
        }
        if(!elementStack.isEmpty() && elementStack.peek().equals(CUSTOM_FIELD)){
            latestTicket().getCustomFieldList().add(new FreshdeskCustomField(qName,elementValue.toString()));
        }
    }

    private void setID(String value) {
        String topValue = elementStack.peek();
        if (ATTACHMENT.equals(topValue)) {
            try {
                latestAttachment().setId(Long.parseLong(value));
            }catch (Exception e){
                latestAttachment().setId(null);
            }
        }else if(HELPDESK_NOTE.equals(topValue)){
            try {
                latestNote().setId(Long.parseLong(value));
            }catch (Exception e){
                latestNote().setId(null);
            }
        }
    }

    private void setCreatedAt(String value) {
        String topValue = elementStack.peek();
        switch (topValue){
            case HELPDESK_TICKET:
                latestTicket().setCreatedAt(value);
                break;
            case HELPDESK_NOTE:
                latestNote().setCreatedAt(value);
                break;
            case ATTACHMENT:
                latestAttachment().setCreatedAt(value);
        }
    }
    private void setUpdatedAt(String value) {
        String topValue = elementStack.peek();
        switch (topValue){
            case HELPDESK_TICKET:
                latestTicket().setUpdatedAt(value);
                break;
            case HELPDESK_NOTE:
                latestNote().setUpdatedAt(value);
                break;
            case ATTACHMENT:
                latestAttachment().setUpdatedAt(value);
        }
    }

    private void setSource(String value){
        String topValue = elementStack.peek();
        if (HELPDESK_TICKET.equals(topValue)) {
            try {
                latestTicket().setSource(Integer.parseInt(value));
            }catch (Exception e){
                latestTicket().setSource(null);
            }
        }else if(HELPDESK_NOTE.equals(topValue)){
            try {
                latestNote().setSource(Integer.parseInt(value));
            }catch (Exception e){
                latestNote().setSource(null);
            }
        }
    }

    private HelpdeskTicket latestTicket(){
        List<HelpdeskTicket> helpdeskTicketList = freshdeskTicketsDto.getHelpdeskTicketList();
        int index = helpdeskTicketList.size()-1;
        return helpdeskTicketList.get(index);
    }

    private HelpdeskNote latestNote(){
        List<HelpdeskNote> helpdeskNoteList = latestTicket().getNotes();
        int index = helpdeskNoteList.size()-1;
        return helpdeskNoteList.get(index);
    }

    private FreshdeskAttachment latestAttachment(){
        String top = elementStack.pop();
        String parent = elementStack.peek();
        List<FreshdeskAttachment> freshdeskAttachmentList = null;
        elementStack.push(top);
        switch (parent){
            case HELPDESK_TICKET:
                freshdeskAttachmentList =latestTicket().getFreshdeskAttachmentList();
                break;
            case HELPDESK_NOTE:
                freshdeskAttachmentList = latestNote().getFreshdeskAttachmentList();
                break;
        }
        int index = freshdeskAttachmentList.size()-1;
        return freshdeskAttachmentList.get(index);
    }
    private void addAttachment() {
        String topValue = elementStack.peek();
        switch (topValue){
            case HELPDESK_TICKET:
                latestTicket().getFreshdeskAttachmentList().add(new FreshdeskAttachment());
                break;
            case HELPDESK_NOTE:
                latestNote().getFreshdeskAttachmentList().add(new FreshdeskAttachment());
                break;
        }
    }
    private void addAttachments() {
        String topValue = elementStack.peek();
        switch (topValue){
            case HELPDESK_TICKET:
                latestTicket().setFreshdeskAttachmentList(new ArrayList<>());
                break;
            case HELPDESK_NOTE:
                latestNote().setFreshdeskAttachmentList(new ArrayList<>());
                break;
        }
    }


    private HelpdeskTag latestTag(){
        List<HelpdeskTag> helpdeskTagList = latestTicket().getHelpdeskTagList();
        int index = helpdeskTagList.size()-1;
        return helpdeskTagList.get(index);
    }
    public FreshdeskTicketsDto getFreshdeskTicketsDto() {
        return freshdeskTicketsDto;
    }
}

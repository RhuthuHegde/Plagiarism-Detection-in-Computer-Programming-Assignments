package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.ForwardFeedValueJsonDto;
import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.entities.ForwardFeedAttachment;

public interface ForwardFeedService {
    public ForwardFeed createForwardFeed(ForwardFeed forwardFeed);
}

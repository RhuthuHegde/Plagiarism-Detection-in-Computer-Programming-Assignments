package com.onedirect.migrationapi.bos;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CustomFieldBo {
    private String key;
    private String value;
}

package com.onedirect.migrationapi.entities.zoho.agentcomment;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="zoho_comment")
public class ZohoComment {
    @Id
    private Long id;
    private String comment;
    private Long commentedBy;
    private Boolean isPublic;
    private Date commentedTime;
    private Date modifiedTime;
    private Long entityId;
    private Long moduleId;
}

package com.onedirect.migrationapi.repos.migration.slave.zohorepo.contact;

import com.onedirect.migrationapi.entities.zoho.contact.ZohoContact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ZohoContactRepo extends JpaRepository<ZohoContact,Long> {
    @Query("SELECT zc from ZohoContact zc WHERE zc.id=?1")
    ZohoContact findZohoContactByID(Long ID);
}

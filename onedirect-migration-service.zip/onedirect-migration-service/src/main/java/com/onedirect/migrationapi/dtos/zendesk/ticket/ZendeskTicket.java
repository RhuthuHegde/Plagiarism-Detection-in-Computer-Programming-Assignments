package com.onedirect.migrationapi.dtos.zendesk.ticket;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.onedirect.migrationapi.dtos.zendesk.ZendeskVia;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskTicket {

    @JsonProperty("url")
    private String url;
    @JsonProperty("id")
    private Long id;
    @JsonProperty("external_id")
    private String externalId;
    @JsonProperty("via")
    private ZendeskVia via;
    @JsonProperty("created_at")
    private String createdAt;
    @JsonProperty("updated_at")
    private String updatedAt;
    @JsonProperty("type")
    private String type;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("raw_subject")
    private String rawSubject;
    @JsonProperty("description")
    private String description;
    @JsonProperty("priority")
    private String priority;
    @JsonProperty("status")
    private String status;
    @JsonProperty("recipient")
    private String recipient;
    @JsonProperty("requester_id")
    private Long requesterId;
    @JsonProperty("submitter_id")
    private Long submitterId;
    @JsonProperty("assignee_id")
    private Long assigneeId;
    @JsonProperty("organization_id")
    private Long organizationId;
    @JsonProperty("group_id")
    private Long groupId;
    @JsonProperty("collaborator_ids")
    private List<Object> collaboratorIds = null;
    @JsonProperty("follower_ids")
    private List<Object> followerIds = null;
    @JsonProperty("email_cc_ids")
    private List<Object> emailCcIds = null;
//    @JsonProperty("forum_topic_id")
//    private Integer forumTopicId;
//    @JsonProperty("problem_id")
//    private Integer problemId;
    @JsonProperty("has_incidents")
    private Boolean hasIncidents;
    @JsonProperty("is_public")
    private Boolean isPublic;
    @JsonProperty("due_at")
    private String dueAt;
    @JsonProperty("tags")
    private List<String> tags = null;
    @JsonProperty("custom_fields")
    private List<ZendeskCustomField> customFields = null;
    @JsonProperty("satisfaction_rating")
    private ZendeskSatisfactionRating satisfactionRating;
    @JsonProperty("sharing_agreement_ids")
    private List<Object> sharingAgreementIds = null;
    @JsonProperty("fields")
    private List<ZendeskCustomField> fields = null;
    @JsonProperty("followup_ids")
    private List<Object> followupIds = null;
    @JsonProperty("ticket_form_id")
    private Long ticketFormId;
    @JsonProperty("brand_id")
    private Long brandId;
    @JsonProperty("allow_channelback")
    private Boolean allowChannelback;
    @JsonProperty("allow_attachments")
    private Boolean allowAttachments;
    @JsonProperty("generated_timestamp")
    private Long generatedTimestamp;
}

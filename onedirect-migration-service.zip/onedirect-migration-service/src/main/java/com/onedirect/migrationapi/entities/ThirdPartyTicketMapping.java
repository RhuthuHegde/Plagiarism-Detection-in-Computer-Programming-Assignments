package com.onedirect.migrationapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "third_party_ticket_mapping")
public class ThirdPartyTicketMapping implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "brand_id")
    private Integer brandId;

    @Column(name = "third_party_data_id")
    private Long thirdPartyDataId;

    @Column(name = "ticket_id")
    private Long ticketId;

    @Column(name = "team_id")
    private Integer teamId;

    @Column(name = "customer_id", nullable = true)
    private Long customerId;

    @Column(name = "brand_user_id", nullable = true)
    private Integer brandUserId;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "record_status")
    private Byte recordStatus;

}
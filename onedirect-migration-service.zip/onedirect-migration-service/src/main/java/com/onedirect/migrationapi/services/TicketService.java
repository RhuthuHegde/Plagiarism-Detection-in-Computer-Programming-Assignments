package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.Ticket;

public interface TicketService {
    public Ticket addTicket(Ticket ticket);
}

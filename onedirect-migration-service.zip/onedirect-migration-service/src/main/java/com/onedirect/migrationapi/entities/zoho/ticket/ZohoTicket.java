package com.onedirect.migrationapi.entities.zoho.ticket;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="zoho_ticket")
public class ZohoTicket {
    @Id
    private Long id;
    private Long departmentId;
    private Long contactId;
    private String email;
    private String phone;
    private String subject;
    private String description;
    private String status;
    private Long productId;
    private Long assigneeId;
    private Long createdBy;
    private Long modifiedBy;
    private java.sql.Date createdTime;
    private java.sql.Date modifiedTime;
    private Integer ticketNumber;
    private String resolution;
    private String toAddress;
    private java.sql.Date customerResponseTime;
    private Integer threadCount;
    private Long accountId;
    private String dueDate;
    private String priority;
    private String channel;
    private String category;
    private String subCategory;
    private String closedTime;
    private Boolean isEscalated;
    private String classification;
    private String hoursSinceStatusUpdated;
    private String hoursSinceReopened;
    private String hoursSinceAssigned;
    private String hoursSinceFirstAssigned;
    private String happinessRating;
    private String cf_follow_ups;
    private String agentRespondedTime;
    private Integer commentCount;
    private String cf_issue;
    private String cf_next_action;
    private Long resolutionTimeInBusinessHours;
    private Long firstResponseTimeInBusinessHours;
    private Long totalResponseTimeInBusinessHours;
    private Integer numberOfResponses;
    private Integer numberOfOutgoing;
    private Integer numberOfReassign;
    private Integer numberOfReopen;
    private String responseDueDate;
    private String slaName;
    private String slaViolationType;
    private String cf_lob;
    private Long teamId;
    private String tags;
    private Integer onholdTime;
    private Integer totalTimeSpent;
    private String sentiment;
    private Long layoutId;
    private String language;
    private String cf_picklist_1;
    
//    private Long id;
//    private Long departmentId;
//    private Long contactId;
//    private String email;
//    private String phone;
//    private String subject;
//    private String description;
//    private String status;
//    private Long productId;
//    private Long assigneeId;
//    private Long createdBy;
//    private Long modifiedBy;
//    private Date createdTime;
//    private Date modifiedTime;
//    private Integer ticketNumber;
//    private String resolution;
//    private String toAddress;
//    private Date customerResponseTime;
//    private Integer threadCount;
//    private Long accountId;
//    private String dueDate;
//    private String priority;
//    private String channel;
//    private String category;
//    private String subCategory;
//    private Date closedTime;
//    private Boolean isEscalated;
//    private String classification;
//    private Date hoursSinceStatusUpdated;
//    private Date hoursSinceReopened;
//    private Date hoursSinceAssigned;
//    private Date hoursSinceFirstAssigned;
//    private String happinessRating;
//    private String cf_follow_ups;
//    private Date agentRespondedTime;
//    private Integer commentCount;
//    private String cf_issue;
//    private String cf_next_action;
//    private Long resolutionTimeInBusinessHours;
//    private Integereger firstResponseTimeInBusinessHours;
//    private Integereger totalResponseTimeInBusinessHours;
//    private Integereger numberOfResponses;
//    private Integereger numberOfOutgoing;
//    private Integereger numberOfReassign;
//    private Integereger numberOfReopen;
//    private String responseDueDate;
//    private String slaName;
//    private String slaViolationType;
//    private String cf_lob;
//    private Long teamId;
//    private String tags;
//    private Integereger onholdTime;
//    private Integereger totalTimeSpent;
//    private String sentiment;
//    private Long layoutId;
//    private String language;
//    private String cf_picklist_1;
//
//    private ZohoContact contact;
//    private List<ZohoUploadAttachment> uploads;
//    private String statusType;
//    private String channelCode;
//    private ZohoTicketSource source;
//    @JsonProperty("cf")
//    private List<ZohoCustomFields> cf;
//    private String webUrl;
//    private Integereger timeEntryCount;
//    private Integereger approvalCount;
//    private Integereger attachmentCount;
//    private Integereger taskCount;
//    private Boolean isDeleted;
//    private Boolean isTrashed;
//    private ZohoProduct product;
//    private Boolean isRead;
//    private ZohoTicketAssignee assignee;
//    private Boolean isFollowing;
//    private ZohoTicketDepartment department;
//    private ZohoTicketTeam team;
//    private ZohoChannelRelatedInfo channelRelatedInfo;
//    private List<Long> secondaryContacts;
//    private List<Long> entitySkills;

}

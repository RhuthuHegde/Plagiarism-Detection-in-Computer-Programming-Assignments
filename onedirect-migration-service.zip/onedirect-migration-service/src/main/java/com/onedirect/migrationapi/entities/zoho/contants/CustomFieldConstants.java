package com.onedirect.migrationapi.entities.zoho.contants;

public class CustomFieldConstants {

    public static final String CUSTOM_FIELD_FOLLOW_UPS="cf_follow_ups";
    public static final String CUSTOM_FIELD_ISSUE="cf_issue";
    public static final String CUSTOM_FIELD_NEXT_ACTION="cf_next_action";
    public static final String CUSTOM_FIELD_LOB="cf_lob";
    public static final String CUSTOM_FIELD_PICKLIST_1="cf_picklist_1";





}

package com.onedirect.migrationapi.constants;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author jp
 */

@PropertySource("classpath:services.properties")
@Configuration
public class MigrationPlatformConstants {


    public static String FRESHDESK_FILE_PATH;
    public static String FRESHDESK_DIR_PATH;

    @Value( "${freshdesk.file.path}" )
    public void setFreshdeskFilePath(String path){
        FRESHDESK_FILE_PATH = path;
    }

    @Value( "${freshdesk.dir.path}" )
    public void setFreshdeskDirPath(String path){
        FRESHDESK_DIR_PATH = path;
    }

    public static final String PARAM_BRAND_CONFIG_DTO="PARAM_BRAND_CONFIG_DTO";
    public static final String PARAM_MIGRATION_LOG = "PARAM_MIGRATION_LOG";

    // ZENDESK Constants
    public static final String ZENDESK_INCREMENTAL_TICKET_FETCH_URL = "https://[ZENDESK_BRAND_DOMAIN]/api/v2/incremental/tickets/cursor.json";
    public static final String ZENDESK_CONVERSATIONS_FETCH_URL = "https://[ZENDESK_BRAND_DOMAIN]/api/v2/tickets/[ZENDESK_TICKET_ID]/comments.json";
    public static final String ZENDESK_USER_FETCH_URL = "https://[ZENDESK_BRAND_DOMAIN]/api/v2/users/[ZENDESK_USER_ID].json";
    public static final String ZENDESK_HEADER_AUTHORIZATION = "Authorization";
    public static final String ZENDESK_HEADER_COOKIE = "Cookie";
    public static final String PARAM_KEY_NEXT_TICKET_URL = "NEXT_TICKET_URL";

    //FRESHDESK Constants
    public static final String PARAM_KEY_TICKET_INDEX = "PARAM_KEY_TICKET_INDEX";
    public static final Integer FRESHDESK_TICKET_SOURCE_EMAIL = 1;
    public static final String FRESHDESK_TICKETS_FOLDER_NAME = "Tickets";
    public static final String FRESHDESK_USER_FOLDER_NAME = "Users";
    public static final String FRESHDESK_ATTRIBUTE_TICKET_TYPE = "TICKET_TYPE";

    //ZOHO Constants
    public static final String ZOHO_INCREMENTAL_TICKETS_FETCH_URL="https://[ZOHO_BRAND_DOMAIN]/api/v1/tickets";
    public static final String ZOHO_CONVERSATIONS_FETCH_URL = "https://[ZOHO_BRAND_DOMAIN]/api/v1/tickets/[ZOHO_TICKET_ID]/comments";
    public static final String ZOHO_USERS_FETCH_URL = "https://[ZOHO_BRAND_DOMAIN]/api/v1/contacts";
    public static final String ZOHO_USER_FETCH_URL="https://[ZOHO_BRAND_DOMAIN]/api/v1/contacts/[ZOHO_USER_ID]";
    public static final String ZOHO_TICKET_FETCH_URL="https://[ZOHO_BRAND_DOMAIN]/api/v1/tickets/[ZOHO_TICKET_ID]";
}

package com.onedirect.migrationapi.bos;

import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;

import java.util.Set;

/**
 * @author jp
 */

public class AnnotationScanner extends ClassPathScanningCandidateComponentProvider {

    public AnnotationScanner(AnnotationTypeFilter annotationTypeFilter) {
        super(false);
        this.addIncludeFilter(annotationTypeFilter);
    }

    public boolean isCandidateComponent(AnnotatedBeanDefinition annotatedBeanDefinition) {
        return annotatedBeanDefinition.getMetadata().isConcrete()
                && annotatedBeanDefinition.getMetadata().isIndependent()
                || annotatedBeanDefinition.getMetadata().isInterface();
    }

    public Set<BeanDefinition> find() {
        Set<BeanDefinition> allClasses = this.findCandidateComponents("in.onedirect");
        allClasses.addAll(this.findCandidateComponents("com.onedirect"));
        allClasses.addAll(this.findCandidateComponents("com.odcem"));
        return allClasses;
    }
}

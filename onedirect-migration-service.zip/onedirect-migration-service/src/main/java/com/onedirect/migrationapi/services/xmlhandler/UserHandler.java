package com.onedirect.migrationapi.services.xmlhandler;

import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskUserDto;
import com.onedirect.migrationapi.dtos.freshdesk.user.FreshdeskUser;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;
import java.util.List;

public class UserHandler extends DefaultHandler {
    private FreshdeskUserDto freshdeskUserDto;
    private StringBuilder elementValue;

    private static final String USERS = "users";
    private static final String USER = "user";
    private static final String ADDRESS = "address";
    private static final String CREATED_AT = "created-at";
    private static final String CUSTOMER_ID = "customer-id";
    private static final String DESCRIPTION = "description";
    private static final String EMAIL = "email";
    private static final String FACEBOOK_PROFILE_ID = "fb-profile-id";
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String PHONE = "phone";
    private static final String MOBILE = "mobile";
    private static final String TWITTER_ID = "twitter-id";
    private static final String UPDATED_AT = "updated-at";

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        if (elementValue == null) {
            elementValue = new StringBuilder();
        } else {
            elementValue.append(ch, start, length);
        }
    }

    @Override
    public void startDocument() throws SAXException {
        freshdeskUserDto = new FreshdeskUserDto();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        switch (qName){
            case USERS:
                freshdeskUserDto.setFreshdeskUserList(new ArrayList<>());
                break;
            case USER:
                freshdeskUserDto.getFreshdeskUserList().add(new FreshdeskUser());
                break;
            case ADDRESS:
            case CREATED_AT:
            case CUSTOMER_ID:
            case DESCRIPTION:
            case EMAIL:
            case FACEBOOK_PROFILE_ID:
            case ID:
            case NAME:
            case PHONE:
            case TWITTER_ID:
            case UPDATED_AT:
            case MOBILE:
                elementValue = new StringBuilder();
                break;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        switch (qName){
            case ADDRESS:
                latestUser().setAddress(elementValue.toString());
                break;
            case CREATED_AT:
                latestUser().setCreatedAt(elementValue.toString());
                break;
            case CUSTOMER_ID:
                try{
                    latestUser().setCustomerId(Long.parseLong(elementValue.toString()));
                }catch (Exception e){
                    latestUser().setCustomerId(null);
                }
                break;
            case DESCRIPTION:
                latestUser().setDescription(elementValue.toString());
                break;
            case EMAIL:
                latestUser().setEmail(elementValue.toString());
                break;
            case FACEBOOK_PROFILE_ID:
                try {
                    latestUser().setFacebookProfileId(Long.parseLong(elementValue.toString()));
                }catch (Exception e){
                    latestUser().setFacebookProfileId(null);
                }
                break;
            case ID:
                try{
                    latestUser().setId(Long.parseLong(elementValue.toString()));
                }catch(Exception e){
                    latestUser().setId(null);
                }
                break;
            case NAME:
                latestUser().setName(elementValue.toString());
                break;
            case PHONE:
                latestUser().setPhone(elementValue.toString());
                break;
            case TWITTER_ID:
                latestUser().setTwitterId(elementValue.toString());
                break;
            case UPDATED_AT:
                latestUser().setUpdatedAt(elementValue.toString());
                break;
            case MOBILE:
                latestUser().setMobile(elementValue.toString());
                break;
        }
    }

    public FreshdeskUserDto getFreshdeskUserDto(){
        return freshdeskUserDto;
    }

    private FreshdeskUser latestUser(){
        List<FreshdeskUser> freshdeskUserList = freshdeskUserDto.getFreshdeskUserList();
        int index = freshdeskUserList.size()-1;
        return freshdeskUserList.get(index);
    }
}

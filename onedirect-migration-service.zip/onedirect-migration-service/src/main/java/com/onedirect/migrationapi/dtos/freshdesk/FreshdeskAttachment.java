package com.onedirect.migrationapi.dtos.freshdesk;

public class FreshdeskAttachment {
    private String contentType;
    private String contentFileName;
    private Integer contentFileSize;
    private String createdAt;
    private String attachmentUrl;
    private String updatedAt;
    private Long id;

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getContentFileName() {
        return contentFileName;
    }

    public void setContentFileName(String contentFileName) {
        this.contentFileName = contentFileName;
    }

    public Integer getContentFileSize() {
        return contentFileSize;
    }

    public void setContentFileSize(Integer contentFileSize) {
        this.contentFileSize = contentFileSize;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getAttachmentUrl() {
        return attachmentUrl;
    }

    public void setAttachmentUrl(String attachmentUrl) {
        this.attachmentUrl = attachmentUrl;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "FreshdeskAttachment{" +
                "contentType='" + contentType + '\'' +
                ", contentFileName='" + contentFileName + '\'' +
                ", contentFileSize=" + contentFileSize +
                ", createdAt='" + createdAt + '\'' +
                ", attachmentUrl='" + attachmentUrl + '\'' +
                ", updatedAt='" + updatedAt + '\'' +
                ", id=" + id +
                '}';
    }
}

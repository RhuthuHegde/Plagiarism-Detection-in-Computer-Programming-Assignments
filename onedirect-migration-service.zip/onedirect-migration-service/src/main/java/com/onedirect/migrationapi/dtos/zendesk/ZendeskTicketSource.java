package com.onedirect.migrationapi.dtos.zendesk;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskTicketSource {
        @JsonProperty("from")
        private ZendeskTicketParty from;
        @JsonProperty("to")
        private ZendeskTicketParty to;
        @JsonProperty("rel")
        private Object rel;

}

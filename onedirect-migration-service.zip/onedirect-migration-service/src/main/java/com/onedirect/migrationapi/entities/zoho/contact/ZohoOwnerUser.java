package com.onedirect.migrationapi.entities.zoho.contact;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoOwnerUser {
    
    private Long id;
    private String firstName;
    private String lastName;
}

package com.onedirect.migrationapi.pojos;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TicketFieldOption {
    private String optionValue;
    private Long optionId;
}

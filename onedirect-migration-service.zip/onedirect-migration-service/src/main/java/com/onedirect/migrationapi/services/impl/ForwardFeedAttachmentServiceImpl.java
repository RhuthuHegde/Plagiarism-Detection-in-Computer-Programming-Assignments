package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.dtos.ForwardFeedValueJsonDto;
import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.entities.ForwardFeedAttachment;
import com.onedirect.migrationapi.repos.email.master.ForwardFeedAttachmentRepo;
import com.onedirect.migrationapi.services.ForwardFeedAttachmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class ForwardFeedAttachmentServiceImpl implements ForwardFeedAttachmentService {

    @Autowired
    ForwardFeedAttachmentRepo forwardFeedAttachmentRepo;

    private static Gson gson = new Gson();

    @Override
    public ForwardFeedAttachment createForwardFeedAttachment(ForwardFeedAttachment forwardFeedAttachment) {
        return forwardFeedAttachmentRepo.save(forwardFeedAttachment);
    }

    @Override
    public ForwardFeedAttachment generateForwardFeedAttachment(Integer brandId, Long feedId, ForwardFeedValueJsonDto forwardFeedValueJsonDto) {
        ForwardFeedAttachment forwardFeedAttachment = new ForwardFeedAttachment();
        forwardFeedAttachment.setBrandId(brandId);
        forwardFeedAttachment.setFeedId(feedId);
        forwardFeedAttachment.setValueJson(gson.toJson(forwardFeedValueJsonDto));
        forwardFeedAttachment.setStatus((byte) 1);
        forwardFeedAttachment.setCreatedBy(Constants.INT_SYSTEM_USER);
        forwardFeedAttachment.setCreatedAt(new Date());
        forwardFeedAttachment.setUpdatedAt(new Date());
        return forwardFeedAttachment;
    }
}

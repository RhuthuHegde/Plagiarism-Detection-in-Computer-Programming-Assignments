package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.TicketTag;
import com.onedirect.migrationapi.repos.onedirect.master.TicketTagRepo;
import com.onedirect.migrationapi.services.TicketTagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketTagServiceImpl implements TicketTagService {

    @Autowired
    TicketTagRepo ticketTagRepo;

    @Override
    public TicketTag addTicketTag(TicketTag ticketTag) {
        return ticketTagRepo.save(ticketTag);
    }
}

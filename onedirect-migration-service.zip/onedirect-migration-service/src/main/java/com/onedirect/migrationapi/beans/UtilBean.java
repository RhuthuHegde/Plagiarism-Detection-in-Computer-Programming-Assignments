package com.onedirect.migrationapi.beans;

import com.onedirect.migrationapi.bos.StorageBootstrapCondition;
import com.onedirect.datautils.enums.StorageEnvironment;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

/**
 * @author jp
 */
@Component
@Conditional({StorageBootstrapCondition.class})
public class UtilBean {
    @Value("${storage.environment}")
    private String environment;
    @Value("${storage.project}")
    private String project;
    @Value("${gcp.staging.bucket}")
    private String stagingBucket;
    @Value("${gcp.production.bucket}")
    private String productionBucket;
    @Value("https://%s.storage.googleapis.com/%s")
    private String mediaLinkTemplate;

    public UtilBean() {
    }

    public String getEnvironment() {
        return this.environment;
    }

    public String getProject() {
        return this.project;
    }

    public String getMediaLinkTemplate() {
        return this.mediaLinkTemplate;
    }

    public String getBucket() {
        return StorageEnvironment.getByName(this.environment) == StorageEnvironment.PRODUCTION ? this.productionBucket : this.stagingBucket;
    }
}


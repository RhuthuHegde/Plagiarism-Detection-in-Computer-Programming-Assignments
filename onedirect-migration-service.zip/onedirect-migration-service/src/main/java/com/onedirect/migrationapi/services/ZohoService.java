package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.BrandConfigurationDto;
import com.onedirect.migrationapi.dtos.ForwardFeedAttachmentDto;
import com.onedirect.migrationapi.entities.zoho.ZohoAgent;
import com.onedirect.migrationapi.entities.zoho.agentcomment.ZohoComment;
import com.onedirect.migrationapi.entities.zoho.contact.ZohoContact;
import com.onedirect.migrationapi.entities.zoho.thread.ZohoThread;
import com.onedirect.migrationapi.entities.zoho.thread.ZohoThreadAttachment;
import com.onedirect.migrationapi.entities.zoho.ticket.ZohoTicket;
import com.onedirect.migrationapi.entities.zoho.agentcomment.ZohoUploadAttachment;
import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.entities.Ticket;

import java.util.List;
import java.util.Map;

public interface ZohoService {
    public Customer addCustomer(ZohoContact zohoContact, BrandConfigurationDto brandConfigurationDto);

    List<ZohoThreadAttachment> getZohoUploadAttachmentFromJson(String attachmentListJson);

    List<ForwardFeedAttachmentDto> createForwardFeedAttachmentDtoList(List<ZohoThreadAttachment> zohoUploadAttachmentList, Integer brandId);

    ForwardFeed generateForwardFeed(Ticket ticket, ZohoThread zohoThread, ZohoTicket zohoTicket);

    Ticket buildOneDirectTicket(ZohoTicket zohoTicket, Integer brandId, Long oneDirectCustomerId, Integer brandUserId, Long latestBrandTicketId);

    Map<String, String> uploadAttachments(List<ZohoThreadAttachment> zohoThreadAttachmentList, Integer brandId);

    ZohoTicket getZohoTicketById(Long Id);

    ZohoContact getZohoContactById(Long Id);

    ZohoComment getZohoCommentByEntityId(Long entityId);

    List<ZohoThread> getZohoThreadByTicketId(Long ticketId);

    ZohoAgent getZohoAgentById(Long Id);

    List<ZohoTicket> getAllZohoTickets();

    List<ZohoContact> getAllZohoContacts();

    ZohoUploadAttachment getZohoCommentAttachment(Long commentId);

    List<ZohoThreadAttachment> getZohoThreadAttachment(Long threadId);

    List<Customer> buildCustomersFromZohoContactsList(List<ZohoContact> zohoContactList,Integer brandId);

    List<ZohoThread> getAllThreads();

    ZohoThread createZohoThread(ZohoTicket zohoTicket);
}

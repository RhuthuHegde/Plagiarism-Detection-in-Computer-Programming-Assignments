package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.converters.CustomConverterMapperUtil;
import com.onedirect.migrationapi.dtos.BrandConfigurationDto;
import com.onedirect.migrationapi.dtos.ForwardFeedAttachmentDto;
import com.onedirect.migrationapi.dtos.ForwardFeedDto;
import com.onedirect.migrationapi.entities.zoho.ZohoAgent;
import com.onedirect.migrationapi.entities.zoho.agentcomment.ZohoComment;
import com.onedirect.migrationapi.entities.zoho.contact.ZohoContact;
import com.onedirect.migrationapi.entities.zoho.thread.ZohoThread;
import com.onedirect.migrationapi.entities.zoho.thread.ZohoThreadAttachment;
import com.onedirect.migrationapi.entities.zoho.ticket.ZohoTicket;
import com.onedirect.migrationapi.entities.zoho.agentcomment.ZohoUploadAttachment;
import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.entities.Ticket;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.enums.TicketStatusType;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.repos.migration.master.PlatformCustomerMappingMasterRepo;
import com.onedirect.migrationapi.repos.migration.slave.PlatformAgentMappingRepo;
import com.onedirect.migrationapi.repos.migration.slave.PlatformCustomerMappingRepo;
import com.onedirect.migrationapi.repos.migration.slave.zohorepo.agent.ZohoAgentRepo;
import com.onedirect.migrationapi.repos.migration.slave.zohorepo.attachment.ZohoCommentAttachmentRepo;
import com.onedirect.migrationapi.repos.migration.slave.zohorepo.attachment.ZohoThreadAttachmentRepo;
import com.onedirect.migrationapi.repos.migration.slave.zohorepo.contact.ZohoContactRepo;
import com.onedirect.migrationapi.repos.migration.slave.zohorepo.conversation.ZohoCommentRepo;
import com.onedirect.migrationapi.repos.migration.slave.zohorepo.conversation.ZohoThreadRepo;
import com.onedirect.migrationapi.repos.migration.slave.zohorepo.ticket.ZohoTicketRepo;
import com.onedirect.migrationapi.services.FileTransferService;
import com.onedirect.migrationapi.services.TicketMigrationLogService;
import com.onedirect.migrationapi.services.ZohoService;
import com.onedirect.migrationapi.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ZohoServiceImpl implements ZohoService {
    @Autowired
    PlatformCustomerMappingRepo platformCustomerMappingRepo;

    @Autowired
    PlatformCustomerMappingMasterRepo platformCustomerMappingMasterRepo;

    @Autowired
    PlatformAgentMappingRepo platformAgentMappingRepo;

    @Autowired
    FileTransferService fileTransferService;

    @Autowired
    TicketMigrationLogService ticketMigrationLogService;

    @Autowired
    ZohoTicketRepo zohoTicketRepo;

    @Autowired
    ZohoContactRepo zohoContactRepo;

    @Autowired
    ZohoThreadRepo zohoThreadRepo;

    @Autowired
    ZohoCommentRepo zohoCommentRepo;

    @Autowired
    ZohoAgentRepo zohoAgentRepo;

    @Autowired
    ZohoCommentAttachmentRepo zohoCommentAttachmentRepo;

    @Autowired
    ZohoThreadAttachmentRepo zohoThreadAttachmentRepo;

    private static Gson gson = new Gson();

    private static final Logger logger = LoggerFactory.getLogger(ZendeskServiceImpl.class);
    @Override
    public Customer addCustomer(ZohoContact zohoContact, BrandConfigurationDto brandConfigurationDto) {
        Customer customer=convertZohoContacttoOneDirectCustomer(zohoContact,brandConfigurationDto);
        return customer;
    }

    @Override
    public List<ZohoThreadAttachment> getZohoUploadAttachmentFromJson(String attachmentListJson) {
        return gson.fromJson(attachmentListJson,new TypeToken<List<ZohoThreadAttachment>>(){}.getType());
    }

    @Override
    public List<ForwardFeedAttachmentDto> createForwardFeedAttachmentDtoList(List<ZohoThreadAttachment> zohoThreadAttachmentList, Integer brandId) {
        List<ForwardFeedAttachmentDto> valueJsonList = new ArrayList<>();
        for (ZohoThreadAttachment zohoThreadAttachment : zohoThreadAttachmentList) {
            String gcpAttachmentUrl = fileTransferService.migrateAttachment(brandId,
                    zohoThreadAttachment.getUrl(), zohoThreadAttachment.getFileName());
            ForwardFeedAttachmentDto forwardFeedAttachmentDto = new ForwardFeedAttachmentDto();
            forwardFeedAttachmentDto.setAttachmentName(zohoThreadAttachment.getFileName());
            forwardFeedAttachmentDto.setAttachmentUrl(gcpAttachmentUrl);
//            forwardFeedAttachmentDto.setAttachmentSize(Math.toIntExact(zohoThreadAttachment.get()));
            forwardFeedAttachmentDto.setS3Bucket(2);
            valueJsonList.add(forwardFeedAttachmentDto);
        }
        return valueJsonList;
    }

    @Override
    public ForwardFeed generateForwardFeed(Ticket ticket, ZohoThread zohoThread, ZohoTicket zohoTicket) {
        ForwardFeedDto forwardFeedDto = new ForwardFeedDto();
        forwardFeedDto.setBrandId(ticket.getBrandId());
        // TODO check brand user id
        //////
       ZohoTicket zohoThreadTicket= getZohoTicketById(zohoThread.getTicketId());
        if (zohoThreadTicket.getContactId().equals(zohoTicket.getContactId()))

            forwardFeedDto.setCustomerId(ticket.getCustomerId());
        else
            forwardFeedDto.setBrandUserId(1L);
        forwardFeedDto.setTicketId(ticket.getId());
        forwardFeedDto.setSubject(ticket.getSubject());
        forwardFeedDto.setResourceText(zohoThread.getSummary());
        forwardFeedDto.setParsedResourceText(zohoThread.getSummary());
        forwardFeedDto.setMessageType((byte) 4);
        forwardFeedDto.setMessageState((byte) 2);
        forwardFeedDto.setResourcePublishDate(zohoThread.getCreatedTime());
        forwardFeedDto.setStatus((byte) 1);
        forwardFeedDto.setCreatedAt(zohoThread.getCreatedTime());
        forwardFeedDto.setUpdatedAt(new Date());
        ForwardFeed forwardFeedEntity = CustomConverterMapperUtil.map(forwardFeedDto, ForwardFeed.class);
        return forwardFeedEntity;
    }

    @Override
    public Ticket buildOneDirectTicket(ZohoTicket zohoTicket, Integer brandId, Long oneDirectCustomerId, Integer brandUserId, Long latestBrandTicketId) {
        Ticket ticket=convertZohoTicketToOneDirectTicket(zohoTicket,brandId,oneDirectCustomerId,brandUserId,latestBrandTicketId);
        return ticket;
    }

    @Override
    public Map<String, String> uploadAttachments(List<ZohoThreadAttachment> zohoThreadAttachmentList, Integer brandId) {
        Map<String,String> uploadedAttachments = new HashMap<>();
        zohoThreadAttachmentList.forEach((zohoThreadAttachment -> {
            uploadedAttachments.put(zohoThreadAttachment.getFileName(),
                    fileTransferService.migrateAttachment(brandId,zohoThreadAttachment.getUrl(),
                            zohoThreadAttachment.getFileName()));
        }));
        return uploadedAttachments;
    }

    private Ticket convertZohoTicketToOneDirectTicket(ZohoTicket zohoTicket, Integer brandId, Long oneDirectCustomerId, Integer brandUserId, Long latestBrandTicketId) {
        Ticket ticket = new Ticket();
        ticket.setId(null);
        ticket.setCustomerId(oneDirectCustomerId);
        ticket.setBrandId(brandId);
        ticket.setBrandTicketId(latestBrandTicketId);
        ticket.setSource((byte)5);
        ticket.setSubSource((byte)8);
        if (Objects.nonNull(zohoTicket.getSubject())) {
            String odTicketSubject = zohoTicket.getSubject();
            if (odTicketSubject.length() > 250) {
                odTicketSubject = odTicketSubject.substring(0, 249);
            }
            ticket.setSubject(odTicketSubject);
        }
        else {
            ticket.setSubject("");
        }
        if (Objects.nonNull(zohoTicket.getDescription())) {
            String odTicketDescription = zohoTicket.getDescription();
            if (odTicketDescription.length() > 250) {
                odTicketDescription = odTicketDescription.substring(0, 249);
            }
            ticket.setShortDesc(odTicketDescription);
        }
        else {
            ticket.setShortDesc("");
        }
        switch (zohoTicket.getStatus()) {
            case "Open":
                ticket.setCurrentStatus(TicketStatusType.OPEN.getId());
                break;
            case "Complaint":
                ticket.setCurrentStatus(
                        TicketStatusType.PENDING.getId());
                break;
            case "Addressed":
                ticket.setCurrentStatus(
                        TicketStatusType.RESOLVED.getId()
                );
                break;
            case "Closed":
                ticket.setCurrentStatus(
                        TicketStatusType.CLOSED.getId()
                );
                break;
//            default:
//                ticket.setCurrentStatus(
//                        TicketStatusType.getEnumByValue(TicketStatusType.CLOSED.getValue())
//                );
//                break;
        }
        // ticket.setLatestCustomerResponseDate(zohoTicket.getCustomerResponseTime()); ticket.setLastConversationDate(zohoTicket.getClosedTime());
        ticket.setCurrentPriority((byte)0);
        ticket.setTicketUrl(null);
        ticket.setTeamId(null);
        ticket.setFirstAssignmentDate(zohoTicket.getCreatedTime());
        ticket.setCurrentAssignmentDate(null);
        ticket.setCurrentlyAssignedTo(brandUserId);
        ticket.setResourcePublishDate(zohoTicket.getCreatedTime());
        ticket.setFirstBrandResponseDate(null);
        ticket.setLatestBrandResponseDate(null);
        ticket.setLatestCustomerResponseDate(zohoTicket.getCreatedTime());
        ticket.setDueDate(null);
        ticket.setCurrentSentiment((byte)2);
        ticket.setSlaBreachStatus((byte)0);
        ticket.setRefTicketId(null);
        ticket.setSplitParentId(null);
        ticket.setAccountId(null);
        ticket.setParentTicketId(null);
        ticket.setRequesterId(null);
        ticket.setTicketType((byte)0);
        ticket.setIsActionable((byte)1);
        ticket.setLastConversationDate(zohoTicket.getCreatedTime());
        ticket.setStatus((byte)1);
        ticket.setAssociationType((byte)0);
        ticket.setCurrentStatusUpdatedAt(zohoTicket.getCreatedTime());
        ticket.setCreatedAt(zohoTicket.getCreatedTime());
        ticket.setUpdatedAt(new Date());
        ticket.setCreatedBy(Constants.INT_SYSTEM_USER);
        ticket.setUpdatedBy(Constants.INT_SYSTEM_USER);
        ticket.setLastModifiedAt(new Date());
        ticket.setUpdatedByType((byte)1);
        ticket.setRecordStatus((byte)1);
        ticket.setFirstAssignedTo(null);
        ticket.setLastAssigneeUpdatedAt(null);
        ticket.setLastAssigneeResponseAt(null);
        return ticket;
    }

    private Customer convertZohoContacttoOneDirectCustomer(ZohoContact zohoContact, BrandConfigurationDto brandConfigurationDto) {
        Customer customer=new Customer();
        customer.setId(null);
        customer.setName(zohoContact.getFullName());
        customer.setSource((byte)5);
        customer.setHandle(null);
        customer.setSourceUserId(null);
        customer.setProfilePictureUrl(null);
        customer.setStatus((byte)1);
        customer.setIsSpammer((byte)2);
        customer.setCreatedAt(zohoContact.getCreatedTime());
        customer.setCreatedBy(Constants.INT_SYSTEM_USER);
        customer.setUpdatedAt(new Date());
        customer.setUpdatedBy(Constants.INT_SYSTEM_USER);
        customer.setBrandId(brandConfigurationDto.getBrandId());
        customer.setProductId((byte)1);
        customer.setExternalCustomerId(null);
        customer.setBrandCustomerId(null);
        return customer;
    }

    @Override
    public ZohoTicket getZohoTicketById(Long ID) {
        ZohoTicket zohoTicket;
        zohoTicket=zohoTicketRepo.findZohoTicketByID(ID);
        if(Objects.nonNull(zohoTicket))
            return zohoTicket;
        else {
            logger.info("The ticket id "+ID+" isn't found");
            throw new CustomInternalServerException("Ticket isn't found",ErrorCodes.DATA_NOT_FOUND);
        }
    }

    @Override
    public ZohoContact getZohoContactById(Long ID) {
        ZohoContact zohoContact;
        zohoContact=zohoContactRepo.findZohoContactByID(ID);
        if(Objects.nonNull(zohoContact))
            return zohoContact;
        else
        {
            logger.info("The contact Id "+ID+" isn't found");
            throw new CustomInternalServerException("Contact not found",ErrorCodes.DATA_NOT_FOUND);
        }
    }

    @Override
    public ZohoComment getZohoCommentByEntityId(Long entityId) {
        ZohoComment zohoComment;
        zohoComment=zohoCommentRepo.findZohoCommentByEntityId(entityId);
        if(Objects.nonNull(zohoComment))
            return zohoComment;
        else
        {
            logger.info("The Comment for the ticket "+entityId+" isn't found");
            throw new CustomInternalServerException("Comment not found",ErrorCodes.DATA_NOT_FOUND);
        }
    }

    @Override
    public List<ZohoThread> getZohoThreadByTicketId(Long ticketId) {
        List<ZohoThread> zohoThreadList;
        zohoThreadList=zohoThreadRepo.findZohoThreadByTicketId(ticketId);
        if(Objects.nonNull(zohoThreadList))
            return zohoThreadList;
        else
        {
            logger.info("The Thread conversation for the ticket "+ticketId+" isn't found");
            throw new CustomInternalServerException("Thread conversation not found", ErrorCodes.DATA_NOT_FOUND);
        }
    }

    @Override
    public ZohoAgent getZohoAgentById(Long Id) {
        ZohoAgent zohoAgent;
        zohoAgent=zohoAgentRepo.findZohoAgentByID(Id);
        if(Objects.nonNull(zohoAgent))
            return zohoAgent;
        else
        {
            logger.info("The Thread conversation for the ticket "+Id+" isn't found");
            throw new CustomInternalServerException("Thread conversation not found",ErrorCodes.DATA_NOT_FOUND);
        }
    }

    @Override
    public List<ZohoTicket> getAllZohoTickets() {
        List<ZohoTicket> ticketList;
        ticketList=zohoTicketRepo.findAll();
//        logger.info(ticketList.toString());
        return ticketList;
    }

    @Override
    public List<ZohoContact> getAllZohoContacts() {
        List<ZohoContact> contactList;
        contactList=zohoContactRepo.findAll();
        return contactList;
    }

    @Override
    public ZohoUploadAttachment getZohoCommentAttachment(Long commentId) {
        ZohoUploadAttachment zohoCommentAttachment;
        zohoCommentAttachment=zohoCommentAttachmentRepo.findZohoUploadAttachmentByCommentId(commentId);
        if(Objects.isNull(zohoCommentAttachment))
        {
            logger.info("The Attachment for the Comment "+commentId+" isn't found");
        }
            return zohoCommentAttachment;
//            throw new CustomInternalServerException("Comment Attachment not found",ErrorCodes.DATA_NOT_FOUND);
    }

    @Override
    public List<ZohoThreadAttachment> getZohoThreadAttachment(Long threadId) {
        List<ZohoThreadAttachment> zohoThreadAttachmentList;
        zohoThreadAttachmentList= zohoThreadAttachmentRepo.findZohoThreadAttachmentByThreadId(threadId);
        if(Objects.isNull(zohoThreadAttachmentList)) {
            logger.info("The Attachment for the Thread " + threadId + " isn't found");
        }
//            throw new CustomInternalServerException("Thread Attachment not found",ErrorCodes.DATA_NOT_FOUND);
            return zohoThreadAttachmentList;
    }

    @Override
    public List<Customer> buildCustomersFromZohoContactsList(List<ZohoContact> zohoContactList,Integer brandId) {
        List<Customer> customerList= new ArrayList<>();
        for(ZohoContact contact: zohoContactList)
        {
            customerList.add(createCustomerFromZohoContact(contact,brandId));
        }
        return customerList;
    }

    @Override
    public List<ZohoThread> getAllThreads() {
        List<ZohoThread> zohoThreadList;
        zohoThreadList=zohoThreadRepo.findAll();
        return zohoThreadList;
    }

    @Override
    public ZohoThread createZohoThread(ZohoTicket zohoTicket) {
        ZohoThread zohoThread=new ZohoThread();
        zohoThread.setId(null);
        zohoThread.setCreatedTime(zohoTicket.getCreatedTime());
        zohoThread.setThreadStatus(null);
        zohoThread.setTicketId(zohoTicket.getId());
        zohoThread.setSummary("  .  ");
        zohoThread.setIsPrivate(null);
        zohoThread.setFromEmailAddress(null);
        zohoThread.setReceipients(null);
        zohoThread.setUserId(null);
        zohoThread.setChannelId(null);
        return zohoThread;
    }

    private Customer createCustomerFromZohoContact(ZohoContact contact, Integer brandId) {
        Customer customer=new Customer();
        customer.setId(contact.getId());
        String name = null;
        if(Objects.isNull(contact.getFullName()) || contact.getFullName().isEmpty()){
            name = "nill";
        }else{
            name = contact.getFullName();
        }
        if (name.length()>100){
            name = name.substring(0,99);
        }
        customer.setName(name);
        customer.setSource((byte)5);
        customer.setHandle(null);
        customer.setSourceUserId(null);
        customer.setProfilePictureUrl(null);
        customer.setStatus((byte)1);
        customer.setIsSpammer((byte)2);
        customer.setCreatedAt(contact.getCreatedTime());
//        customer.setCreatedBy(Math.toIntExact(contact.getCreatedBy()));
        customer.setCreatedBy(Constants.INT_SYSTEM_USER);
        customer.setUpdatedAt(new Date());
        //        customer.setUpdatedBy(Math.toIntExact(contact.getModifiedBy()));
        customer.setUpdatedBy(Constants.INT_SYSTEM_USER);
        customer.setBrandId(brandId);
        customer.setProductId((byte)1);
        customer.setExternalCustomerId(null);
        customer.setBrandCustomerId(null);
        return customer;
    }
}

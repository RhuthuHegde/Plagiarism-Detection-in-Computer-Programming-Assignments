package com.onedirect.migrationapi.constants;


public class BeanConstant {

  public static final String ONEDIRECT_MASTER_ENTITY_MANAGER_FACTORY = "oneDirectMasterEntityManagerFactory";
  public static final String ONEDIRECT_MASTER_DATA_SOURCE = "oneDirectMasterDataSource";
  public static final String ONEDIRECT_MASTER_DATA_SOURCE_PROPERTIES = "oneDirectMasterDataSourceProperties";
  public static final String ONEDIRECT_MASTER_TRANS_MANAGER = "oneDirectMasterTransactionManager";

  public static final String CUSTOMER_MASTER_ENTITY_MANAGER_FACTORY = "customerMasterEntityManagerFactory";
  public static final String CUSTOMER_MASTER_DATA_SOURCE = "customerMasterDataSource";
  public static final String CUSTOMER_MASTER_DATA_SOURCE_PROPERTIES = "customerMasterDataSourceProperties";
  public static final String CUSTOMER_MASTER_TRANS_MANAGER = "customerMasterTransactionManager";

  public static final String EMAIL_MASTER_ENTITY_MANAGER_FACTORY = "emailMasterEntityManagerFactory";
  public static final String EMAIL_MASTER_DATA_SOURCE = "emailMasterDataSource";
  public static final String EMAIL_MASTER_DATA_SOURCE_PROPERTIES = "emailMasterDataSourceProperties";
  public static final String EMAIL_MASTER_TRANS_MANAGER = "emailMasterTransactionManager";

  public static final String MIGRATION_MASTER_ENTITY_MANAGER_FACTORY = "migrationMasterEntityManagerFactory";
  public static final String MIGRATION_MASTER_DATA_SOURCE = "migrationMasterDataSource";
  public static final String MIGRATION_MASTER_DATA_SOURCE_PROPERTIES = "migrationMasterDataSourceProperties";
  public static final String MIGRATION_MASTER_TRANS_MANAGER = "migrationMasterTransactionManager";

  public static final String JPA_REPO = "jpaRepositories";

  public static final String ONEDIRECT_SLAVE_ENTITY_MANAGER_FACTORY = "oneDirectSlaveEntityManagerFactory";
  public static final String ONEDIRECT_SLAVE_DATA_SOURCE = "oneDirectSlaveDataSource";
  public static final String ONEDIRECT_SLAVE_TRANSACTION_MANAGER = "oneDirectSlaveTransactionManager";
  public static final String ONEDIRECT_SLAVE_DATA_SOURCE_PROPERTIES = "oneDirectSlaveDataSourceProperties";

  public static final String CUSTOMER_SLAVE_ENTITY_MANAGER_FACTORY = "customerSlaveEntityManagerFactory";
  public static final String CUSTOMER_SLAVE_DATA_SOURCE = "customerSlaveDataSource";
  public static final String CUSTOMER_SLAVE_TRANSACTION_MANAGER = "customerSlaveTransactionManager";
  public static final String CUSTOMER_SLAVE_DATA_SOURCE_PROPERTIES = "customerSlaveDataSourceProperties";

  public static final String EMAIL_SLAVE_ENTITY_MANAGER_FACTORY = "emailSlaveEntityManagerFactory";
  public static final String EMAIL_SLAVE_DATA_SOURCE = "emailSlaveDataSource";
  public static final String EMAIL_SLAVE_TRANSACTION_MANAGER = "emailSlaveTransactionManager";
  public static final String EMAIL_SLAVE_DATA_SOURCE_PROPERTIES = "emailSlaveDataSourceProperties";

  public static final String MIGRATION_SLAVE_ENTITY_MANAGER_FACTORY = "migrationSlaveEntityManagerFactory";
  public static final String MIGRATION_SLAVE_DATA_SOURCE = "migrationSlaveDataSource";
  public static final String MIGRATION_SLAVE_TRANSACTION_MANAGER = "migrationSlaveTransactionManager";
  public static final String MIGRATION_SLAVE_DATA_SOURCE_PROPERTIES = "migrationSlaveDataSourceProperties";
}

package com.onedirect.migrationapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "ticket_field_value")
public class TicketFieldValue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "brand_id")
    private Integer brandId;

    @Column(name = "ticket_id")
    private Long ticketId;

    @Column(name = "ticket_label_id")
    private Integer ticketLabelId;

    @Column(name = "option_id")
    private Long optionId;

    @Column(name = "ticket_label_text")
    private String ticketLabelText;

    @Column(name = "ticket_label_int")
    private Integer ticketLabelInt;

    @Column(name = "ticket_label_decimal")
    private BigDecimal ticketLabelDecimal;

    @Column(name = "ticket_label_latitude")
    private BigDecimal ticketLabelLat;

    @Column(name = "ticket_label_longitude")
    private BigDecimal ticketLabelLong;

    @Column(name = "ticket_label_datetime")
    private Date ticketLabelDate;

    @Column(name = "ticket_label_bool")
    private Byte ticketLabelBool;

    @Column(name = "status")
    private Byte status;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "updated_at")
    private Date updatedAt;

}

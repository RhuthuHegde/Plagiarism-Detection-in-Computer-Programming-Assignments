package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.TicketTag;

public interface TicketTagService {
    public TicketTag addTicketTag(TicketTag ticketTag);
}

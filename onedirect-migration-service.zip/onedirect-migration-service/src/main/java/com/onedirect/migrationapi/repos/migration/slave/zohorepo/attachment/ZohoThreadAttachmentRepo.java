package com.onedirect.migrationapi.repos.migration.slave.zohorepo.attachment;

import com.onedirect.migrationapi.entities.zoho.thread.ZohoThreadAttachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ZohoThreadAttachmentRepo extends JpaRepository<ZohoThreadAttachment,Long> {
    List<ZohoThreadAttachment> findZohoThreadAttachmentByThreadId(Long threadId);
}

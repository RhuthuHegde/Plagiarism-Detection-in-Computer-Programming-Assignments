package com.onedirect.migrationapi.exceptions;

public class ServiceException extends com.onedirect.commonutils.exceptions.exception.ServiceException {
    protected ServiceException(String code, String message, Exception exception, String... info) {
        super(code, message, exception, info);
    }

    public ServiceException(String code, String message, String... info) {
        super(code, message, info);
    }
}

package com.onedirect.migrationapi.repos.migration.slave;

import com.onedirect.migrationapi.entities.PlatformCustomerMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PlatformCustomerMappingRepo extends JpaRepository<PlatformCustomerMappingEntity,Long> {
    @Query(value = "SELECT pcme FROM PlatformCustomerMappingEntity pcme WHERE pcme.platformCustomerId =?1 AND pcme.brandConfigurationId = ?2")
    PlatformCustomerMappingEntity findPlatformCustomerMapping(Long zendeskCustomerId, Integer brandConfigurationId);
}

package com.onedirect.migrationapi.services;

import java.io.InputStream;

/**
 * @author jp
 */

public interface FileTransferService {

    String migrateAttachment(Integer brandId, String attachmentUrl, String fileName);
}

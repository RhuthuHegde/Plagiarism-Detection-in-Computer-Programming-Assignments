package com.onedirect.migrationapi.repos.email.master;

import com.onedirect.migrationapi.entities.ForwardFeedReferenceIds;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface ForwardFeedReferenceIdsRepo extends JpaRepository<ForwardFeedReferenceIds, Long> {

    @Transactional
    @Modifying
    @Query(value = "update ForwardFeedReferenceIds eref set " +
            "eref.referenceIds=:references where " +
            "eref.feedId=:feedId and " +
            "eref.brandId=:brandId and " +
            "eref.status=1")
    public void updateReferencesForEmailId(@Param("feedId") Long feedId, @Param("brandId") Integer brandId, @Param("references") String
            references);
}

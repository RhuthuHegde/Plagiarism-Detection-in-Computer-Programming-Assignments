package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.ThirdPartyData;
import com.onedirect.migrationapi.repos.onedirect.master.ThirdPartyDataRepo;
import com.onedirect.migrationapi.services.ThirdPartyDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ThirdPartyDataServiceImpl implements ThirdPartyDataService {

    @Autowired
    ThirdPartyDataRepo thirdPartyDataRepo;

    @Override
    public ThirdPartyData addThirdPartyData(ThirdPartyData thirdPartyData) {
        return thirdPartyDataRepo.save(thirdPartyData);
    }
}

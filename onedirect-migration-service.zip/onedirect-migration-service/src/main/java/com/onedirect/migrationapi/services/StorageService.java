package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.FileMetaData;
import com.onedirect.migrationapi.dtos.StorageObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author jp
 */

public interface StorageService {
    FileMetaData upload(InputStream var1, StorageObject var2) throws IOException;

    FileMetaData upload(byte[] var1, StorageObject var2);

    FileMetaData upload(File var1, StorageObject var2) throws IOException;

    FileMetaData uploadAsync(byte[] var1, StorageObject var2);

    FileMetaData uploadAsync(File var1, StorageObject var2) throws IOException;

    FileMetaData uploadAsync(InputStream var1, StorageObject var2) throws IOException;

    byte[] getBytes(String var1) throws IOException;

    InputStream getInputStream(String var1) throws IOException;

    Boolean delete(String var1);

    FileMetaData startTransaction(File var1, StorageObject var2) throws IOException;

    void commitTransaction(String var1);
}

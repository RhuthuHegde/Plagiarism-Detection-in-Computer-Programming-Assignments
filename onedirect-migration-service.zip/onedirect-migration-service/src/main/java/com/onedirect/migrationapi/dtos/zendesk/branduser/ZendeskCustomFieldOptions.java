package com.onedirect.migrationapi.dtos.zendesk.branduser;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskCustomFieldOptions {
    private String name;
    private String value;
}

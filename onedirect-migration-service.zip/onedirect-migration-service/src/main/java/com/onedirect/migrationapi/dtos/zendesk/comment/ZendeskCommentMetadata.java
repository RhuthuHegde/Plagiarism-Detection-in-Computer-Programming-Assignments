package com.onedirect.migrationapi.dtos.zendesk.comment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskCommentMetadata {
    public ZendeskCommentSystemMetadata system;
    public Boolean trusted;

}

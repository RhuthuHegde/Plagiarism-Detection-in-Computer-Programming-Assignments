package com.onedirect.migrationapi.dtos;

import lombok.*;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class FileData {
    private String url;
    private String name;
}

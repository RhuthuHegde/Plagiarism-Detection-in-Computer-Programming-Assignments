package com.onedirect.migrationapi.bos;

import com.onedirect.migrationapi.entities.Ticket;
import lombok.*;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class TicketListBo {

    private List<Object> ticketList;
    private Map<String,Object> params;
}

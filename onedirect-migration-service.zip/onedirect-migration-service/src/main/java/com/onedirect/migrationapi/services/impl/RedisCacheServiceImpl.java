package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.utils.SlackNotificationUtil;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.data.redis.support.atomic.RedisAtomicLong;
import org.springframework.stereotype.Service;
import com.onedirect.migrationapi.services.RedisCacheService;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * @author jp
 */

@Service
public class RedisCacheServiceImpl implements RedisCacheService {

    private static final Logger logger = LoggerFactory.getLogger(RedisCacheServiceImpl.class);

    private final RedisTemplate<String, Object> redisTemplate;

    private final SlackNotificationUtil slackNotificationUtil;

    public RedisTemplate<Object, Object> genericRedisTemplate;

    private static Gson gson = new Gson();

    public RedisCacheServiceImpl(
            RedisTemplate<String, Object> redisTemplate, SlackNotificationUtil slackNotificationUtil) {
        this.redisTemplate = redisTemplate;
        this.slackNotificationUtil = slackNotificationUtil;
    }

    @Override
    public boolean putInCache(String key, String value) {
        try {
            String cacheKey = getCacheKey(key);
            redisTemplate.opsForValue().set(cacheKey, value);
            return true;
        } catch (Exception e) {
            logger.error("Error in putting in cache: {}", ExceptionUtils.getStackTrace(e));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in adding in redis", ExceptionUtils.getStackTrace(e));
            return false;
        }
    }

    @Override
    public boolean putInCache(Object hashMapKey, String key, String value) {
        try {
            redisTemplate.opsForHash().put(key, hashMapKey, value);
            return true;
        } catch (Exception e) {
            logger.error("Error in putting in cache: {}", ExceptionUtils.getStackTrace(e));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in adding in redis", ExceptionUtils.getStackTrace(e));
        }
        return false;
    }

    @Override
    public void putInCache(String key, TimeUnit timeUnit, Long ttl, Object obj) {
        redisTemplate.opsForValue().set(key, obj);
        if(Objects.nonNull(ttl)) {
            redisTemplate.expire(key, ttl, timeUnit);
        }
    }

    @Override
    public String getFromCache(String key) {
        Object value = null;
        String cacheKey = getCacheKey(key);
        try {
            value = redisTemplate.opsForValue().get(cacheKey);
        } catch (Exception exception) {
            logger.error(
                    "Exception occurred while getting from cache, for key: {} with exception {}",
                    cacheKey,
                    ExceptionUtils.getStackTrace(exception));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in getting from redis", ExceptionUtils.getStackTrace(exception));
        }
        return value != null ? gson.toJson(value) : null;
    }

    @Override
    public Object getFromCache(Object hashMapKey, String key) {
        Object value = null;
        try {
            value = redisTemplate.opsForHash().get(key, hashMapKey);
        } catch (Exception e) {
            logger.error("Exception occurred while getting from cache, for key: " + key, e);
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in getting from redis", ExceptionUtils.getStackTrace(e));
        }
        return value;
    }

    @Override
    public boolean deleteFromCache(String key) {
        String cacheKey = getCacheKey(key);
        try {
            redisTemplate.delete(cacheKey);
            return true;
        } catch (Exception exception) {
            logger.error(
                    " Exception occurred while deleting from cache, for key: {} with Exception {}",
                    cacheKey,
                    ExceptionUtils.getStackTrace(exception));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in deleting from redis", ExceptionUtils.getStackTrace(exception));
            return false;
        }
    }

    @Override
    public boolean deleteFromCache(Object hashMapKey, String key) {
        try {
            redisTemplate.opsForHash().delete(key, hashMapKey);
            return true;
        } catch (Exception e) {
            logger.error(
                    " Exception occurred while deleting from cache, for key: {} with exception {}",
                    key,
                    ExceptionUtils.getStackTrace(e));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in deleting from redis", ExceptionUtils.getStackTrace(e));
            return false;
        }
    }

    private String getCacheKey(String key) {
        return Constants.REDIS_KEY_PREFIX + key;
    }

    @Override
    public boolean setTtlInCache(String key, Integer ttlTimeInSec, TimeUnit timeUnit) {
        String cacheKey = getCacheKey(key);
        try {
            return redisTemplate.expire(cacheKey, ttlTimeInSec, timeUnit);
        } catch (Exception e) {
            logger.error(
                    "Exception occurred while setting ttl from cache, for key: {} with exception {}",
                    cacheKey,
                    ExceptionUtils.getStackTrace(e));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in setting ttl from redis", ExceptionUtils.getStackTrace(e));
            return false;
        }
    }

    @Override
    public boolean putInCacheWithTtl(
            final String key, final String value, final Integer ttlTimeInSec, final TimeUnit timeUnit) {
        String cacheKey = getCacheKey(key);
        try {
            redisTemplate.execute(
                    new SessionCallback<Object>() {
                        @Override
                        public Object execute(RedisOperations operations) throws DataAccessException {
                            operations.opsForValue().set(cacheKey, value);
                            return operations.expire(cacheKey, ttlTimeInSec, timeUnit);
                        }
                    });
            return true;
        } catch (Exception exception) {
            logger.error(
                    "Exception occurred while putting in cache with ttl, for key: {} "
                            + "and value: {} ttlTimeInSec: {} with Exception {}",
                    cacheKey,
                    value,
                    ttlTimeInSec,
                    ExceptionUtils.getStackTrace(exception));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in putting in cache ttl from redis", ExceptionUtils.getStackTrace(exception));
            return false;
        }
    }

    @Override
    public String atomicGetAndSet(String key, String value) {
        String cacheKey = getCacheKey(key);
        try {
            return gson.toJson(redisTemplate.opsForValue().getAndSet(cacheKey, value));
        } catch (Exception e) {
            logger.error(
                    "Exception occurred while atomic get and set from cache, for key: {} with exception {}"
                            + cacheKey,
                    ExceptionUtils.getStackTrace(e));
            slackNotificationUtil.generateSlackNotification(
                    "", "Error in while atomic get and set", ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    @Override
    public long incrementAndGetAtomicLong(String key) {
        RedisAtomicLong redisAtomicLong = new RedisAtomicLong(key, redisTemplate.getConnectionFactory());
        return redisAtomicLong.incrementAndGet();
    }

    @Override
    public void setAtomicLong(String key, Long newValue) {
        RedisAtomicLong redisAtomicLong = new RedisAtomicLong(key, redisTemplate.getConnectionFactory());
        redisAtomicLong.set(newValue);
    }
}

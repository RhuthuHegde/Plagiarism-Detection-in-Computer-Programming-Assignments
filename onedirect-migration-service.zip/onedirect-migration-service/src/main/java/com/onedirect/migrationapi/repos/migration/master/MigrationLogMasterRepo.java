package com.onedirect.migrationapi.repos.migration.master;

import com.onedirect.migrationapi.entities.MigrationLog;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author jp
 */
public interface MigrationLogMasterRepo extends JpaRepository<MigrationLog, Integer> {
}

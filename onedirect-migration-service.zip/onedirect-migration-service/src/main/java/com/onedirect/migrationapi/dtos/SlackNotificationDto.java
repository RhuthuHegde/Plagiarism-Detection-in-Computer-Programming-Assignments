package com.onedirect.migrationapi.dtos;

import com.google.gson.Gson;

import java.io.Serializable;
import java.util.List;

/**
 * @author jp
 */

public class SlackNotificationDto implements Serializable {
    private String fromService;
    private String endPoint;
    private String message;
    private String description;
    private List<String> targetUsers;
    private String channelName;

    public SlackNotificationDto(
            String fromService,
            String endPoint,
            String message,
            String description,
            List<String> targetUsers,
            String channelName) {
        this.fromService = fromService;
        this.endPoint = endPoint;
        this.message = message;
        this.description = description;
        this.targetUsers = targetUsers;
        this.channelName = channelName;
    }

    public String getFromService() {
        return fromService;
    }

    public void setFromService(String fromService) {
        this.fromService = fromService;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getTargetUsers() {
        return targetUsers;
    }

    public void setTargetUsers(List<String> targetUsers) {
        this.targetUsers = targetUsers;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}

package com.onedirect.migrationapi.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * @author jp
 */
public enum ErrorCodes {
    SOMETHING_WENT_WRONG("MIG_999", "Something went wrong"),
    BAD_REQUEST("MIG_400", "Bad request"),
    DATA_NOT_FOUND("MIG_404", "Data Not Found"),
    ZENDESK_SERVICE_ERROR("MIG_ZENDESK_01", "Error while fetching response from Zendesk"),
    ZENDESK_MAX_RETRY_ERROR("MIG_ZENDESK_02","Max retries reached for request"),
    ZENDESK_BRAND_TICKET_FIELD_CONFIGURATION_NOT_FOUND("MIG_ZENDESK_03","Zendesk brand ticket field configuration not found"),
    BRAND_NOT_CONFIGURED("MIG_3","Brand not configured"),
    UPDATE_MIGRATION_LOG_ERROR("MIG_1", "Unable to update migration log"),
    BRAND_CONFIGURATION_NOT_FOUND("MIG_2", "Brand configuration not found"),
    FAILED_TO_UPLOAD_FILE_TO_GCP("MIG_GCP_01", "Failed to upload file to GCP"),
    FAILED_TO_DECODE_FILE_URL("MIG_GCP_02", "Error while decoding file url from gcp"),
    FAILED_TO_DOWNLOAD_FILE("MIG_GCP_03", "Filed to download file"),
    FAILED_TO_CREATE_FORWARD_FEED("MIG_DATA_01","Error while creating forward_feed"),
    FAILED_TO_CREATE_FORWARD_CUSTOMER_INFO("MIG_DATA_02","Error while creating forward_customer_info"),
    FAILED_TO_CREATE_FORWARD_FEED_ATTACHMENT("MIG_DATA_03","Error while creating forward_feed_attachment"),
    FAILED_TO_CREATE_FORWARD_FEED_REFERENCE_IDS("MIG_DATA_04","Error while creating forward_feed_reference_ids"),
    FAILED_TO_CREATE_CUSTOMER("MIG_DATA_05","Error while creating customer"),
    FAILED_TO_CREATE_TICKET("MIG_DATA_06","Error while creating ticket"),
    FAILED_TO_CREATE_TICKET_TAG("MIG_DATA_07","Error while creating ticket tag"),
    FAILED_TO_CREATE_CUSTOMER_LABEL_VALUE("MIG_DATA_08","Error while creating customer label value"),
    FAILED_TO_CREATE_THIRD_PARTY_DATA("MIG_DATA_09","Error while creating third party data"),
    FAILED_TO_CREATE_THIRD_PARTY_TICKET_MAPPING("MIG_DATA_10","Error while creating third party ticket mapping"),
    FAILED_TO_CONVERT_DATE("MIG_DATA_11","Error while converting date"),
    FAILED_TO_CREATE_TICKET_FIELD_VALUE("MIG_DATA_12","Error while creating ticket field value"),
    INVALID_CUSTOMER_NAME("MIG_VALID_01","Customer name is invalid"),
    INVALID_TICKET_CREATION_REQUEST("MIG_VALID_02","Ticket creation request is invalid"),
    INVALID_TICKET_INFO("MIG_VALID_03","Invalid ticket info"),
    INVALID_THIRD_PARTY_DATA_INFO("MIG_VALID_06","Invalid third party data info"),
    FRESHDESK_TICKETS_NOT_FOUND_FOR_FILE_NAME("MIG_FRESHDESK_01","Could not find freshdesk tickets for file number"),
    FRESHDESK_UNABLE_TO_PROCESS_FILE("MIG_FRESHDESK_02","Unable to process file"),
    FRESHDESK_CUSTOMER_DOES_NOT_EXIST("MIG_FRESHDESK_03","Freshdesk customer does not exist for ticket"),
    FRESHDESK_TICKETS_NOT_FOUND("MIG_FRESHDESK_04","No freshdesk tickets found for brand")
    ;

    private String code;
    private String message;

    private static Map<String, ErrorCodes> reverseMap = new HashMap<>();

    ErrorCodes(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    static {
        for (ErrorCodes errorCode : ErrorCodes.values()) {
            reverseMap.put(errorCode.getCode(), errorCode);
        }
    }

    public static ErrorCodes getErrorCodeEnumByCode(String code) {
        return reverseMap.get(code);
    }
}

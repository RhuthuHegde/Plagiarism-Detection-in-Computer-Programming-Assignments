package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.entities.ThirdPartyData;
import com.onedirect.migrationapi.entities.Ticket;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.services.ValidationService;
import com.onedirect.migrationapi.validators.CustomerValidator;
import com.onedirect.migrationapi.validators.ThirdPartyDataValidator;
import com.onedirect.migrationapi.validators.TicketValidator;
import org.springframework.stereotype.Service;

@Service
public class ValidationServiceImpl implements ValidationService {
    @Override
    public void validateCustomer(Customer customer) throws CustomInternalServerException {
        CustomerValidator.getInstance().validateCustomer(customer);
    }

    @Override
    public void validateTicketRequest(Ticket createTicketDto) throws CustomInternalServerException {
        TicketValidator.getInstance().validateTicketRequest(createTicketDto);
    }

    @Override
    public void validateThirdPartyData(ThirdPartyData thirdPartyData) throws CustomInternalServerException {
        ThirdPartyDataValidator.getInstance().validateRequestData(thirdPartyData);
    }
}

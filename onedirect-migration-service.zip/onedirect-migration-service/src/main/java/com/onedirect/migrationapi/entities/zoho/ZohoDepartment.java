package com.onedirect.migrationapi.entities.zoho;


import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="zoho_department")
public class ZohoDepartment {
    @Id
    private Long id;
    private String name;
    private Boolean isEnabled;
    private Long creatorId;
    private Date createdTime;
    private Date modifiedTime;
    private String status;

}

package com.onedirect.migrationapi.repos.onedirect.slave;

import com.onedirect.migrationapi.entities.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author jp
 */

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

    @Query("select max(t.brandTicketId) from Ticket t where t.brandId=?1 ")
    @Transactional(readOnly = true)
    Long getMaxBrandTicketId(Integer brandId);
}

package com.onedirect.migrationapi.configs;


import com.onedirect.migrationapi.constants.BeanConstant;
import com.onedirect.migrationapi.constants.DataConfigConstant;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.*;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Map;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    entityManagerFactoryRef = BeanConstant.ONEDIRECT_MASTER_ENTITY_MANAGER_FACTORY,
    transactionManagerRef = BeanConstant.ONEDIRECT_MASTER_TRANS_MANAGER,
    basePackages = {DataConfigConstant.ONEDIRECT_MASTER_REPO_PACKAGE})
@PropertySources(value = {@PropertySource("classpath:dataSourcesConfig.properties")})
public class OneDirectDataSourceDbMasterConfig {

  private final Map<String, Object> jpaRepo;

  public OneDirectDataSourceDbMasterConfig(@Qualifier(BeanConstant.JPA_REPO) Map<String, Object> jpaRepo) {
    this.jpaRepo = jpaRepo;
  }

  @Primary
  @Bean(name = BeanConstant.ONEDIRECT_MASTER_TRANS_MANAGER)
  public PlatformTransactionManager transactionManager(
      @Qualifier(BeanConstant.ONEDIRECT_MASTER_ENTITY_MANAGER_FACTORY)
          EntityManagerFactory entityManagerFactory) {
    return new JpaTransactionManager(entityManagerFactory);
  }

  @Primary
  @Bean(name = BeanConstant.ONEDIRECT_MASTER_ENTITY_MANAGER_FACTORY)
  public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(
      final EntityManagerFactoryBuilder builder,
      @Qualifier(BeanConstant.ONEDIRECT_MASTER_DATA_SOURCE) DataSource dataSource) {
    return builder
        .dataSource(dataSource)
        .properties(jpaRepo)
        .packages(DataConfigConstant.ENTITY_PACKAGE)
        .persistenceUnit(DataConfigConstant.ONEDIRECT_MASTER_REPO_PROCESS_NAME)
        .build();
  }

  @Primary
  @Bean(name = BeanConstant.ONEDIRECT_MASTER_DATA_SOURCE)
  @ConfigurationProperties(prefix = DataConfigConstant.ONEDIRECT_MASTER_DATA_SOURCE)
  public DataSource masterDataSource(
      @Qualifier(BeanConstant.ONEDIRECT_MASTER_DATA_SOURCE_PROPERTIES)
          DataSourceProperties dataSourceProperties) {
    return dataSourceProperties.initializeDataSourceBuilder().build();
  }

  @Primary
  @Bean(BeanConstant.ONEDIRECT_MASTER_DATA_SOURCE_PROPERTIES)
  @ConfigurationProperties(DataConfigConstant.ONEDIRECT_MASTER_DATA_SOURCE)
  public DataSourceProperties masterDataSourceProperties() {
    return new DataSourceProperties();
  }
}

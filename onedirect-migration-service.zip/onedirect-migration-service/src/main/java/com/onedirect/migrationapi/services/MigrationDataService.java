package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.ForwardFeedAttachmentDto;
import com.onedirect.migrationapi.dtos.MigrationRequestDto;
import com.onedirect.migrationapi.dtos.QueuedAttachmentsDto;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskComment;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.TicketFieldValueTypeEnum;
import com.onedirect.migrationapi.enums.TicketMigrationEnum;

import java.util.Date;
import java.util.List;

public interface MigrationDataService {
    ThirdPartyData addThirdPartyData(Ticket ticket,String description);

    ForwardFeed addForwardFeed(ForwardFeed forwardFeed);

    Customer addCustomer(Customer customer);

    CustomerLabelValue addCustomerLabelValue(CustomerLabelValue customerLabelValue);

    ForwardCustomerInfo createForwardCustomerInfo(ForwardFeed forwardFeed,String valueJson);

    ForwardFeedReferenceIds createForwardFeedReferenceIds(ForwardFeed forwardFeed);

    ThirdPartyTicketMapping createThirdPartyTicketMapping(Ticket ticket, Long thirdPartyDataId, Long oneDirectCustomerId, Long brandUserId);

    Integer createMigrationLog(MigrationLog migrationLog);

    BrandConfigurationEntity getBrandConfigurationEntityByBrandIdAndPlatformId(Integer brandId, Integer platformId);

    MigrationLog getMigrationLogById(Integer migrationLogId);

    BrandConfigurationEntity getBrandConfigurationEntityById(Integer brandConfigurationId);

    TicketFieldValue addTicketFieldValue(TicketFieldValue ticketFieldValue);

    TicketTag addTag(TicketTag tag);

    Ticket addTicket(Ticket ticket);

    List<TicketFieldValue> getTicketFieldValueForGivenValue(Integer brandId, String valueToSearch, Integer ticketFieldId);

    ThirdPartyDataAttachment addThirdPartyDataAttachment(String attachmentName,String attachmentUrl,Integer brandId, Integer thirdPartyDataId);

    ForwardFeedAttachment createForwardFeedAttachment(Integer brandId, Long forwardFeedId, Date createdAt,
                                                      List<ForwardFeedAttachmentDto> forwardFeedAttachmentDtoList, Long platformConversationId
    );
    CustomerLabelValue buildCustomerLabelValue(Long customerId, String value, Long brandId,
                                                      Date creationDate, Long customerLabelId);

    TicketTag buildTicketTagFromTicketId(Ticket ticket,Integer brandId,Integer ticketTagId);

    QueuedAttachmentsDto createQueuedAttachmentDto(Integer brandId, Long ticketId, Long forwardFeedId,
                                                   Long thirdPartyDataId, Long platformConfersationId,
                                                   Date createdAt, Date updatedAt, Integer platformId,
                                                   String attachmentListJson
                                                   );
    TicketMigrationLog createTicketMigrationLog(Integer migrationLogId, Long platformTicketId,
                                                      Long brandTicketId, Long oneDirectTicketId,
                                                      TicketMigrationEnum status);

    PlatformAgentMapping getPlatformAgentMapping(long assigneeId,Integer brandConfigurationID);

    PlatformCustomerMappingEntity getPlatformCustomerMapping(long requesterID, Integer brandConfigurationId);

    PlatformCustomerMappingEntity createPlatformCustomerMapping(Long zendeskCustomerId,Long customerId,Integer brandConfigurationId);

    TicketFieldValue buildTicketFieldValueFromTicket(Ticket ticket, Integer brandId, Integer labelId,
                                                            TicketFieldValueTypeEnum ticketFieldValueType,
                                                            Long optionId, String value);

    CustomerLabelValue getCustomerLabelValueForCustomerIdAndFieldId(Long customerId, Integer fieldId);

    Customer getCustomerById(Long customerId);
}

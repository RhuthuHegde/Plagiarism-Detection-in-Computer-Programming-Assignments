package com.onedirect.migrationapi.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.Gson;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ForwardCustomerInfoValueJsonDto {

    private NameAddressPairDto from;

    private NameAddressPairDto recievedTo;

    private List<NameAddressPairDto> to;

    private List<NameAddressPairDto> cc;

    private List<NameAddressPairDto> bcc;

}

package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.onedirect.emailutils.HttpUtil;
import com.onedirect.emailutils.model.ApiResponse;
import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.constants.MigrationPlatformConstants;
import com.onedirect.migrationapi.dtos.BrandConfigurationDto;
import com.onedirect.migrationapi.dtos.MigrationRequestDto;
import com.onedirect.migrationapi.dtos.zendesk.ZendeskAttachment;
import com.onedirect.migrationapi.converters.CustomConverterMapperUtil;
import com.onedirect.migrationapi.dtos.*;
import com.onedirect.migrationapi.dtos.zendesk.branduser.ZendeskUser;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskComment;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskCommentsDto;
import com.onedirect.migrationapi.dtos.zendesk.branduser.ZendeskUserDto;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskCustomField;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicket;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicketResponseDto;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.*;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.pojos.TicketFieldLabel;
import com.onedirect.migrationapi.pojos.PlatformTicketFieldOption;
import com.onedirect.migrationapi.pojos.BrandFieldConfiguration;
import com.onedirect.migrationapi.pojos.BrandTicketFieldConfiguration;
import com.onedirect.migrationapi.pojos.PresetTicketFieldOption;
import com.onedirect.migrationapi.repos.migration.master.PlatformCustomerMappingMasterRepo;
import com.onedirect.migrationapi.repos.migration.slave.PlatformAgentMappingRepo;
import com.onedirect.migrationapi.repos.migration.slave.PlatformCustomerMappingRepo;
import com.onedirect.migrationapi.services.FileTransferService;
import com.onedirect.migrationapi.services.MigrationService;
import com.onedirect.migrationapi.services.ZendeskService;
import com.onedirect.migrationapi.services.TicketMigrationLogService;
import com.onedirect.migrationapi.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import com.onedirect.migrationapi.utils.ZendeskHttpUtil;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;


/**
 * @author Hrishikesh
 */

@Service
public class ZendeskServiceImpl implements ZendeskService {

    @Autowired
    PlatformCustomerMappingRepo platformCustomerMappingRepo;

    @Autowired
    PlatformCustomerMappingMasterRepo platformCustomerMappingMasterRepo;

    @Autowired
    PlatformAgentMappingRepo platformAgentMappingRepo;

    @Autowired
    FileTransferService fileTransferService;

    @Autowired
    TicketMigrationLogService ticketMigrationLogService;

    private static Gson gson = new Gson();

    private static final Logger logger = LoggerFactory.getLogger(ZendeskServiceImpl.class);

    public String ZENDESK_VALIDATE_URL = "https://[BRAND_DOMAIN]/api/v2/incremental/tickets/cursor.json";

    @Override
    public ZendeskTicketResponseDto fetchTicketsIncrementally(BrandConfigurationDto brandConfigurationDto,
                                                              Long startTimestamp) {
        return ZendeskHttpUtil.fetchFromZendesk(buildIncrementalTicketFetchUrl(brandConfigurationDto.getPlatformDomain(),startTimestamp), getZendeskHeaderMap(brandConfigurationDto.getPlatformAuthorizationKey()), ZendeskTicketResponseDto.class);
    }

    @Override
    public ZendeskTicketResponseDto fetchTicketsIncrementally(BrandConfigurationDto brandConfigurationEntity,String url) {
        return ZendeskHttpUtil.fetchFromZendesk(url,getZendeskHeaderMap(brandConfigurationEntity.getPlatformAuthorizationKey()),ZendeskTicketResponseDto.class);
    }

    @Override
    public ZendeskCommentsDto fetchCommentsByZendeskTicketId(Long ticketId, BrandConfigurationDto brandConfigurationEntity) {
        return ZendeskHttpUtil.fetchFromZendesk(buildCommentsFetchUrl(brandConfigurationEntity.getPlatformDomain(),ticketId),getZendeskHeaderMap(brandConfigurationEntity.getPlatformAuthorizationKey()),ZendeskCommentsDto.class);
    }

    @Override
    public ZendeskUserDto fetchZendeskUserInfo(Long userId, BrandConfigurationDto brandConfigurationEntity) {
        return ZendeskHttpUtil.fetchFromZendesk(buildUserInfoFetchUrl(brandConfigurationEntity.getPlatformDomain(),userId),getZendeskHeaderMap(brandConfigurationEntity.getPlatformAuthorizationKey()), ZendeskUserDto.class);
    }

    public Boolean isBrandCredentialsValid(MigrationRequestDto migrationRequestDto,BrandConfigurationEntity brandConfigurationEntity) {
        URI validateUri = buildValidateUrl(brandConfigurationEntity.getPlatformDomain(), migrationRequestDto.getStartTime());
        logger.info("Calling Zendesk to validate credentials for brandId:: {}. url:: {}", migrationRequestDto.getBrandId(), validateUri.toString());
        Map<String, String> headersMap = buildHeaders(brandConfigurationEntity.getPlatformAuthorizationKey());
        ApiResponse response;
        try {
            response = HttpUtil.executeGetCall(validateUri.toString(), headersMap);
            if (response.getStatusCode().equals(HttpStatus.OK.value())) {
                logger.info("Got HTTP 200 OK reponse for brandId:: {}", migrationRequestDto.getBrandId());
                return Boolean.TRUE;
            }
            else {
                logger.info("Got non HTTP 200 OK reponse for brandId:: {}", migrationRequestDto.getBrandId());
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            throw new CustomInternalServerException("Error while getting validate response from zendesk", ErrorCodes.ZENDESK_SERVICE_ERROR);
        }
    }

    @Override
    public Customer addCustomer(ZendeskUser zendeskUser, BrandConfigurationDto brandConfigurationDto) {
        Customer customer = covertZendeskUserToOnedirectCustomer(zendeskUser,brandConfigurationDto);
        return customer;
    }

    @Override
    public Ticket createOneDirectTicket(ZendeskTicket zendeskTicket,Integer brandId,Long customerId,Integer brandUserId, Long brandTicketId) {
        Ticket ticket = convertZendeskTicketToOnedirectTicket(zendeskTicket,brandId,customerId,brandUserId,brandTicketId);
        return ticket;
    }

    @Override
    public Map<String,String> uploadAttachments(List<ZendeskAttachment> zendeskAttachmentList,Integer brandId) {
        Map<String,String> uploadedAttachments = new HashMap<>();
        zendeskAttachmentList.forEach((zendeskAttachment -> {
            uploadedAttachments.put(zendeskAttachment.getFileName(),
                    fileTransferService.migrateAttachment(brandId,zendeskAttachment.getContentUrl(),
                            zendeskAttachment.getFileName()));
        }));
        return uploadedAttachments;
    }


    @Override
    public ForwardFeed createOnedirectForwardFeed(Ticket ticket, ZendeskComment zendeskComment, ZendeskTicket zendeskTicket) {
        return generateForwardFeedEntity(ticket, zendeskComment, zendeskTicket);
    }

    @Override
    public List<ForwardFeedAttachmentDto> createForwardFeedAttachmentDtoList(List<ZendeskAttachment> zendeskAttachmentList,Integer brandId){
        List<ForwardFeedAttachmentDto> valueJsonList = new ArrayList<>();
        for (ZendeskAttachment zendeskAttachment : zendeskAttachmentList) {
            String gcpAttachmentUrl = fileTransferService.migrateAttachment(brandId,
                    zendeskAttachment.getContentUrl(), zendeskAttachment.getFileName());
            ForwardFeedAttachmentDto forwardFeedAttachmentDto = new ForwardFeedAttachmentDto();
            forwardFeedAttachmentDto.setAttachmentName(zendeskAttachment.getFileName());
            forwardFeedAttachmentDto.setAttachmentUrl(gcpAttachmentUrl);
            forwardFeedAttachmentDto.setAttachmentSize(zendeskAttachment.getSize());
            forwardFeedAttachmentDto.setS3Bucket(2);
            valueJsonList.add(forwardFeedAttachmentDto);
        }
        return valueJsonList;
    }


    @Override
    public List<ZendeskAttachment> getZendeskAttachmentsFromJson(String s) {
        return gson.fromJson(s, new TypeToken<List<ZendeskAttachment>>(){}.getType());
    }

    public URI buildValidateUrl(String domain, Long startTime) {
        String path = ZENDESK_VALIDATE_URL;
        path = path.replaceFirst("\\[BRAND_DOMAIN\\]", domain);
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(path)
                .queryParam("start_time", String.valueOf(startTime));
        return builder.build().toUri();
    }

    public Map<String, String> buildHeaders(String authToken) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", authToken);
        return headers;
    }

    private String buildIncrementalTicketFetchUrl(String domain, Long startTime){
        String path = MigrationPlatformConstants.ZENDESK_INCREMENTAL_TICKET_FETCH_URL;
        path = path.replaceFirst("\\[ZENDESK_BRAND_DOMAIN\\]", domain);
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(path)
                .queryParam("start_time", String.valueOf(startTime));
        return builder.build().toUri().toString();
    }
    private String buildCommentsFetchUrl(String domain,Long ticketId){
        String path = MigrationPlatformConstants.ZENDESK_CONVERSATIONS_FETCH_URL;
        path = path.replaceFirst("\\[ZENDESK_BRAND_DOMAIN\\]", domain);
        path = path.replaceFirst("\\[ZENDESK_TICKET_ID\\]",ticketId.toString());
        return path;
    }

    private String buildUserInfoFetchUrl(String domain,Long userId){
        String path = MigrationPlatformConstants.ZENDESK_USER_FETCH_URL;
        path = path.replaceFirst("\\[ZENDESK_BRAND_DOMAIN\\]", domain);
        path = path.replaceFirst("\\[ZENDESK_USER_ID\\]", userId.toString());
        return path;
    }

    private Map<String,String> getZendeskHeaderMap(String authToken){
        Map<String,String> headerMap = new HashMap<>();
        headerMap.put(MigrationPlatformConstants.ZENDESK_HEADER_AUTHORIZATION,authToken);
        return headerMap;
    }
    private Customer covertZendeskUserToOnedirectCustomer(ZendeskUser zendeskUser,
                                                          BrandConfigurationDto brandConfigurationDto){
        Customer customer = new Customer();
        customer.setId(null);
        customer.setName(zendeskUser.getName());
        customer.setSource((byte)5);
        customer.setHandle(null);
        customer.setSourceUserId(null);
        customer.setProfilePictureUrl(null);
        customer.setStatus((byte)1);
        customer.setIsSpammer((byte)2);
        customer.setCreatedAt(DateUtils.convertIsoDateStringToDate(zendeskUser.getCreatedAt()));
        customer.setCreatedBy(Constants.INT_SYSTEM_USER);
        customer.setUpdatedAt(new Date());
        customer.setUpdatedBy(Constants.INT_SYSTEM_USER);
        customer.setBrandId(brandConfigurationDto.getBrandId());
        customer.setProductId((byte)1);
        customer.setExternalCustomerId(null);
        customer.setBrandCustomerId(null);
        return customer;
    }

    private Ticket convertZendeskTicketToOnedirectTicket(ZendeskTicket zendeskTicket,
                                                         Integer brandId,Long customerId,Integer brandUserId,
                                                         Long brandTicketId
                                                         ){
        Ticket ticket = new Ticket();
        ticket.setId(null);
        ticket.setCustomerId(customerId);
        ticket.setBrandId(brandId);
        ticket.setBrandTicketId(brandTicketId);
        ticket.setSource((byte)5);
        ticket.setSubSource((byte)8);
        if (Objects.nonNull(zendeskTicket.getSubject())) {
            String odTicketSubject = zendeskTicket.getSubject();
            if (odTicketSubject.length() > 250) {
                odTicketSubject = odTicketSubject.substring(0, 249);
            }
            ticket.setSubject(odTicketSubject);
        }
        else {
            ticket.setSubject("");
        }
        if (Objects.nonNull(zendeskTicket.getDescription())) {
            String odTicketDescription = zendeskTicket.getDescription();
            if (odTicketDescription.length() > 250) {
                odTicketDescription = odTicketDescription.substring(0, 249);
            }
            ticket.setShortDesc(odTicketDescription);
        }
        else {
            ticket.setShortDesc("");
        }
        switch (zendeskTicket.getStatus()) {
            case "new":
                ticket.setCurrentStatus((byte) 0);
                break;
            case "open":
                ticket.setCurrentStatus((byte) 1);
                break;
            case "pending":
                ticket.setCurrentStatus((byte) 2);
                break;
            case "hold":
                ticket.setCurrentStatus((byte) 3);
                break;
            case "solved":
                ticket.setCurrentStatus((byte) 4);
                break;
            case "deleted":
                ticket.setCurrentStatus((byte) 5);
                break;
            default:
                ticket.setCurrentStatus((byte) 5);
                break;
        }
        ticket.setCurrentPriority((byte)0);
        ticket.setTicketUrl(null);
        ticket.setTeamId(null);
        ticket.setFirstAssignmentDate(DateUtils.convertIsoDateStringToDate(zendeskTicket.getCreatedAt()));
        ticket.setCurrentAssignmentDate(null);
        ticket.setCurrentlyAssignedTo(brandUserId);
        ticket.setResourcePublishDate(DateUtils.convertIsoDateStringToDate(zendeskTicket.getCreatedAt()));
        ticket.setFirstBrandResponseDate(null);
        ticket.setLatestBrandResponseDate(null);
        ticket.setLatestCustomerResponseDate(DateUtils.convertIsoDateStringToDate(zendeskTicket.getCreatedAt()));
        ticket.setDueDate(null);
        ticket.setCurrentSentiment((byte)2);
        ticket.setSlaBreachStatus((byte)0);
        ticket.setRefTicketId(null);
        ticket.setSplitParentId(null);
        ticket.setAccountId(null);
        ticket.setParentTicketId(null);
        ticket.setRequesterId(null);
        ticket.setTicketType((byte)0);
        ticket.setIsActionable((byte)1);
        ticket.setLastConversationDate(DateUtils.convertIsoDateStringToDate(zendeskTicket.getCreatedAt()));
        ticket.setStatus((byte)1);
        ticket.setAssociationType((byte)0);
        ticket.setCurrentStatusUpdatedAt(DateUtils.convertIsoDateStringToDate(zendeskTicket.getCreatedAt()));
        ticket.setCreatedAt(DateUtils.convertIsoDateStringToDate(zendeskTicket.getCreatedAt()));
        ticket.setUpdatedAt(new Date());
        ticket.setCreatedBy(Constants.INT_SYSTEM_USER);
        ticket.setUpdatedBy(Constants.INT_SYSTEM_USER);
        ticket.setLastModifiedAt(new Date());
        ticket.setUpdatedByType((byte)1);
        ticket.setRecordStatus((byte)1);
        ticket.setFirstAssignedTo(null);
        ticket.setLastAssigneeUpdatedAt(null);
        ticket.setLastAssigneeResponseAt(null);
        return ticket;
    }


    private ForwardFeed generateForwardFeedEntity(Ticket ticket, ZendeskComment zendeskComment, ZendeskTicket zendeskTicket) {
        ForwardFeedDto forwardFeedDto = new ForwardFeedDto();
        forwardFeedDto.setBrandId(ticket.getBrandId());
        // TODO check brand user id
        if (zendeskComment.getAuthorId().equals(zendeskTicket.getRequesterId()))
            forwardFeedDto.setCustomerId(ticket.getCustomerId());
        else
            forwardFeedDto.setBrandUserId(1L);
        forwardFeedDto.setTicketId(ticket.getId());
        forwardFeedDto.setSubject(ticket.getSubject());
        forwardFeedDto.setResourceText(zendeskComment.getHtmlBody());
        forwardFeedDto.setParsedResourceText(zendeskComment.getPlainBody());
        forwardFeedDto.setMessageType((byte) 4);
        forwardFeedDto.setMessageState((byte) 2);
        forwardFeedDto.setResourcePublishDate(DateUtils.convertIsoDateStringToDate(zendeskComment.getCreatedAt()));
        forwardFeedDto.setStatus((byte) 1);
        forwardFeedDto.setCreatedAt(DateUtils.convertIsoDateStringToDate(zendeskComment.getCreatedAt()));
        forwardFeedDto.setUpdatedAt(new Date());
        ForwardFeed forwardFeedEntity = CustomConverterMapperUtil.map(forwardFeedDto, ForwardFeed.class);
        return forwardFeedEntity;
    }


}

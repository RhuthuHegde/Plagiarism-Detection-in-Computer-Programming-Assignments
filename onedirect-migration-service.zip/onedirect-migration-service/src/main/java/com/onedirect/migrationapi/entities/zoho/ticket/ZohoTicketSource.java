package com.onedirect.migrationapi.entities.zoho.ticket;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoTicketSource {

    private String extId;
    private String type;
    private String appName;
    private String appPhotoURL;
    private String permalink;

}

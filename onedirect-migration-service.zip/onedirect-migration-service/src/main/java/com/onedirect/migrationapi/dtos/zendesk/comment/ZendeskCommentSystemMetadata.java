package com.onedirect.migrationapi.dtos.zendesk.comment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskCommentSystemMetadata {
    public String client;
    @JsonProperty("ip_address")
    public String ipAddress;
    public String location;
    public Double latitude;
    public Double longitude;
}

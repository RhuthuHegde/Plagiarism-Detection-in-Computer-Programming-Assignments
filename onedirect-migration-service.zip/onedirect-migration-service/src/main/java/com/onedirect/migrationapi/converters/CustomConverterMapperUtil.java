package com.onedirect.migrationapi.converters;

import com.onedirect.migrationapi.converters.registry.MapperRegistryUtil;
import com.onedirect.migrationapi.converters.registry.MigrationServiceConverterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;

/**
 * @author jp
 */

public class CustomConverterMapperUtil {

    private static final Logger logger = LoggerFactory.getLogger(CustomConverterMapperUtil.class);

    public static <T> T map(Object val, Class<T> clazz) {
        String key = val.getClass().getSimpleName() + "___" + clazz.getSimpleName();
        GenericMigrationServiceConverter converter = MigrationServiceConverterRegistry.getAllMappersMappings().get(key.trim());
        if (converter == null) {
            logger.error("[No Mapper Exists] for key: {}", key);
            return null;
        }
        return (T) converter.convertFromTDtoToUDto(val);
    }

    public static <U,T> List<T> mapLists(List<U> val, Class<T> clazz) {
        if (CollectionUtils.isEmpty(val)) {
            return (List<T>) Collections.emptyList();
        }
        String key = val.get(0).getClass().getSimpleName() + "___" + clazz.getSimpleName();
        GenericMigrationServiceConverter converter = MigrationServiceConverterRegistry.getAllMappersMappings().get(key.trim());
        if (converter == null) {
            logger.error("[No Mapper Exists] for key: {}", key);
            return null;
        }
        return (List<T>) converter.createTtypeToListOfUtype(val);
    }

    public static <T> T map(Object val, Type type) {
        String key = val.getClass().getSimpleName() + "___" + getTypeName(type);
        GenericMigrationServiceConverter converter = MigrationServiceConverterRegistry.getAllMappersMappings().get(key.trim());
        if (converter == null) {
            logger.error("[No Mapper Exists] for key: {}", key);
            return null;
        }
        return (T) converter.convertFromTDtoToUDto(val);
    }


    private static String getTypeName(Type genericType) {
        if (genericType instanceof ParameterizedType) {
            return MapperRegistryUtil.getTypeName(genericType);
        }
        return null;
    }
}

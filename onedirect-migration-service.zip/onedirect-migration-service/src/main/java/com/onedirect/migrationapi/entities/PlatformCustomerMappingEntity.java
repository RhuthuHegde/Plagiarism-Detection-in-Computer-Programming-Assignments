package com.onedirect.migrationapi.entities;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "platform_customer_mapping")
public class PlatformCustomerMappingEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name="brand_configuration_id")
    private Integer brandConfigurationId;

    @Column(name = "platform_customer_id")
    private Long platformCustomerId;

    @Column(name="onedirect_customer_id")
    private Long  oneDirectCustomerId;

}

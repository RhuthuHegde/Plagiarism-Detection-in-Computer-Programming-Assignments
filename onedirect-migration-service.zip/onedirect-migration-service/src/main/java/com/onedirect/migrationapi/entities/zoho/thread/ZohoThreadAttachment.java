package com.onedirect.migrationapi.entities.zoho.thread;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="zoho_thread_attachment")
public class ZohoThreadAttachment {
    @Id
    private Long id;
    private Long threadId;
    private Long ticketId;
    private String fileName;
    private String url;

}

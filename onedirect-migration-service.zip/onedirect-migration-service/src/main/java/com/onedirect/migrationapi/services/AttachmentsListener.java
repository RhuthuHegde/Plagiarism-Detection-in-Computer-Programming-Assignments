package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.QueuedAttachmentsDto;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.rabbitmq.client.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import java.io.IOException;


@Component
public class AttachmentsListener {

    @Autowired
    MigrationService migrationService;

    private static final Logger logger = LoggerFactory.getLogger(AttachmentsListener.class);

    @RabbitListener(queues = {"${spring.rabbitmq.attachments-queue}"}, containerFactory =
            "attachementsQueueListenerContainerFactory")
    public void processAttachments(Channel channel, QueuedAttachmentsDto queuedAttachmentsDto, @Header(AmqpHeaders.DELIVERY_TAG) long tag){
        try {
            migrationService.processAttachmentFromQueue(queuedAttachmentsDto);
        }catch(CustomInternalServerException customInternalServerException){
            logger.info("Attachments error for conversation ID :: {} Error Code :: {} Error Message :: {}",
                    queuedAttachmentsDto.getPlatformConversationId(),customInternalServerException.getErrorCode(),
                    customInternalServerException.getMessage());
        }catch (Exception e){
            logger.info("There was an unexpected error while creating attachments "+e);
        }finally{
            try {
                channel.basicAck(tag, true);
            }catch (IOException e){
                logger.info("There was an error while trying to acknowledge attachments "+e);
            }
        }
    }
}

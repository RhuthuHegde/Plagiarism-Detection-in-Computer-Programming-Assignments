package com.onedirect.migrationapi.validators;

import com.onedirect.migrationapi.entities.ThirdPartyData;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;

/**
 * @author Srikanth E
 */
public class ThirdPartyDataValidator {

  private static ThirdPartyDataValidator thirdPartyDataValidator = null;

  private ThirdPartyDataValidator() {
  }

  public static ThirdPartyDataValidator getInstance() {
    if (thirdPartyDataValidator == null) {
      return new ThirdPartyDataValidator();

    }
    return thirdPartyDataValidator;
  }

  /**
   * This method check description not empty
   */
  public static void checkDescriptionNotEmpty(String description) {
    if (description == null || description.isEmpty()) {
      throw new CustomInternalServerException("Ticket description is missing");
    }
  }
  // check email and phone and check if uuid and publish date exist
  public void validateRequestData(ThirdPartyData inputData) {
    checkDescriptionNotEmpty(inputData.getDescription());
  }

}

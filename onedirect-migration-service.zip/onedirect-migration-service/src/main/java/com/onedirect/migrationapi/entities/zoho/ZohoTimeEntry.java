package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ZohoTimeEntry {

    private Long id;
    private Long ownerId;
    private String requestChargeType;
    private Date executedTime;
    private Double agentCostPerHour;
    private Double additionalCost;
    private Double totalCost;
    private String description;
    private Long requestId;
    private Long createdBy;
    private Long modifiedBy;
    private Date createdTime;
    private Date modifiedTime;
    private Integer secondsSpent;
    private Boolean isBillable;
    private Long layoutId;
    private Long activityId;
}

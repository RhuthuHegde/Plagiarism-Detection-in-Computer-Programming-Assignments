package com.onedirect.migrationapi.dtos.zendesk;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskAttachment {
    @JsonProperty("content_type")
    private String contentType;
    @JsonProperty("content_url")
    private String contentUrl;
    private Boolean deleted;
    @JsonProperty("file_name")
    private String fileName;
    private String height;
    private Long id;
    private Boolean inline;
    @JsonProperty("mapped_content_url")
    private String mappedContentUrl;
    @JsonProperty("size")
    private Integer size;
//    private List<ZendeskAttachment> thumbnails;
    private String url;
    private String width;
}
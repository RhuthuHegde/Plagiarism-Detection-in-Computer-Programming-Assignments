package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.BrandUser;

public interface BrandUserService {
    public void addBrandUser(BrandUser brandUser);
}

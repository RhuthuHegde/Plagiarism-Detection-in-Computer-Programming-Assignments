package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.ForwardCustomerInfo;
import com.onedirect.migrationapi.repos.email.master.ForwardCustomerInfoRepo;
import com.onedirect.migrationapi.services.ForwardCustomerInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ForwardCustomerInfoServiceImpl implements ForwardCustomerInfoService {

    @Autowired
    ForwardCustomerInfoRepo forwardCustomerInfoRepo;

    @Override
    public ForwardCustomerInfo createForwardCustomerInfo(ForwardCustomerInfo forwardCustomerInfo) {
        return forwardCustomerInfoRepo.save(forwardCustomerInfo);
    }
}

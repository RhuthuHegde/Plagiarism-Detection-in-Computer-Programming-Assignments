package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name="zoho_topic")
public class ZohoTopic {
    @Id
    private Long id;
    private Long ownerId;
    private String name;
    private Long parentCategoryId;
    private Long creatorId;
    private Long modifierId;
    private Date createdTime;
    private Date modifiedTime;
}

package com.onedirect.migrationapi.entities.zoho.agentcomment;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name="zoho_comment_attachment")
public class ZohoUploadAttachment {
    @Id
    private Long id;
    private Long attachmentOwner;
    private Long modifiedBy;
    private Long createdBy;
    private Date createdTime;
    private Date modifiedTime;
    private String fileName;
    private Long size;
    private Long parentId;
    private String attachmentMode;
    private Boolean isPublic;
    private Long threadId;
    private Long commentId;
    private String moduleId;
    private String URL;
}

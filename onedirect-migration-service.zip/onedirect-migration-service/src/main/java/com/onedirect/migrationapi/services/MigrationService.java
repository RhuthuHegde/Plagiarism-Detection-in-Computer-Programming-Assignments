package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.MigrationRequestDto;
import com.onedirect.migrationapi.dtos.QueuedAttachmentsDto;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * @author jp
 */

public interface MigrationService {

    void handleMigrationRequest(MigrationRequestDto migrationRequestDto);

    void processMigrationRequest(MigrationRequestDto migrationRequestDto);

    void processAttachmentFromQueue(QueuedAttachmentsDto queuedAttachmentsDto) throws CustomInternalServerException;

    void pushAttachmentsIntoQueue(List<QueuedAttachmentsDto> queuedAttachmentsDtoList);

}

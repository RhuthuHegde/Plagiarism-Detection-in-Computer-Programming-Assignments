package com.onedirect.migrationapi.constants;

public class DefaultFieldConstants {

    public static final String DEFAULT_TICKET_TAG = "DEFAULT_TICKET_TAG";

    public static final String EMAIL_CUSTOMER_FIELD_ID = "EMAIL_CUSTOMER_FIELD_ID";

}
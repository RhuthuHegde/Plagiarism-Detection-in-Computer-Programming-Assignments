package com.onedirect.migrationapi.constants.brand;

public class EyewaConstants {
    public static Integer EYEWA_BRAND_ID = 8596;
    public static Integer EYEWA_ONEDIRECT_LABEL_ID_FOR_TICKET_FIELD_FRESHDESK_TICKET_ID = 12588;
    public static Integer EYEWA_EMAIL_CUSTOMER_FIELD = 14421;
    public static Integer EYEWA_PHONE_FIELD = 14419;
}

package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.onedirect.migrationapi.bos.ConversationListBo;
import com.onedirect.migrationapi.bos.CustomFieldBo;
import com.onedirect.migrationapi.bos.CustomerBo;
import com.onedirect.migrationapi.bos.TicketListBo;
import com.onedirect.migrationapi.configs.MigrationRabbitMQConfig;
import com.onedirect.migrationapi.constants.MigrationPlatformConstants;
import com.onedirect.migrationapi.dtos.*;
import com.onedirect.migrationapi.dtos.zendesk.ZendeskAttachment;
import com.onedirect.migrationapi.dtos.zendesk.branduser.ZendeskUser;
import com.onedirect.migrationapi.dtos.zendesk.branduser.ZendeskUserDto;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskComment;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskCommentsDto;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskCustomField;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicket;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicketResponseDto;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.enums.TicketMigrationEnum;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.pojos.TicketMigrationStats;
import com.onedirect.migrationapi.pojos.BrandFieldConfiguration;
import com.onedirect.migrationapi.services.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

/**
 * @author jp
 */
@Service
public class ZendeskMigrationService extends PlatformMigrationService {

    @Autowired
    ZendeskService zendeskService;

    @Autowired
    MigrationRabbitMQConfig rabbitMQConfig;

    @Autowired
    CustomerService customerService;

    @Autowired
    MigrationDataService migrationDataService;

    private static final Logger logger = LoggerFactory.getLogger(ZendeskMigrationService.class);

    private static Gson gson = new Gson();


    @Override
    public void validateMigrationRequest(MigrationRequestDto migrationRequestDto,
                                         BrandConfigurationEntity brandConfigurationEntity,
                                         BrandFieldConfiguration brandFieldConfiguration) {
        if(Objects.isNull(migrationRequestDto.getStartTime())){
            logger.info("Start time not specified for brandId :: {}", migrationRequestDto.getBrandId());
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Start time not specified");
        }
        if (!zendeskService.isBrandCredentialsValid(migrationRequestDto,brandConfigurationEntity)) {
            logger.info("Zendesk credentials are invalid for brandId :: {}", migrationRequestDto.getBrandId());
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Zendesk credentials are invalid for brand");
        }
    }

    @Override
    public TicketListBo getTickets(BrandConfigurationDto brandConfigurationDto,
                                    MigrationLog migrationLog, Map<String,Object> params){
        if(Objects.nonNull(params) && params.containsKey(MigrationPlatformConstants.PARAM_KEY_NEXT_TICKET_URL)){
            String nextUrl = (String)params.get(MigrationPlatformConstants.PARAM_KEY_NEXT_TICKET_URL);
            if(Objects.isNull(nextUrl)){
                return null;
            }else{
                ZendeskTicketResponseDto zendeskTicketResponseDto = zendeskService.fetchTicketsIncrementally(brandConfigurationDto,
                        nextUrl);
                return getTicketListBo(zendeskTicketResponseDto);
            }
        }else{
            ZendeskTicketResponseDto zendeskTicketResponseDto =
                    zendeskService.fetchTicketsIncrementally(brandConfigurationDto, migrationLog.getStartTimestamp());
            if (Objects.nonNull(zendeskTicketResponseDto)) {
                return getTicketListBo(zendeskTicketResponseDto);
            } else {
                throw new CustomInternalServerException("Unable to fetch tickets from Zendesk", ErrorCodes.ZENDESK_SERVICE_ERROR);
            }
        }
    }

    @Override
    public TicketFieldValue getPlatformTicketIdTicketField(Ticket ticket, Integer brandId, Object platformTicket, BrandFieldConfiguration brandFieldConfiguration) {
        Long oneDirectLabelIdForTicketFieldZendeskTicketId = brandFieldConfiguration.getPlatformTicketIdTicketFieldId();
        ZendeskTicket zendeskTicket = (ZendeskTicket)platformTicket;
        return getPlatformTicketIdTicketField(oneDirectLabelIdForTicketFieldZendeskTicketId,ticket,brandId,zendeskTicket.getId());
    }

    @Override
    public List<CustomFieldBo> getCustomFieldBoList(Object platformTicket) {
        ZendeskTicket zendeskTicket = (ZendeskTicket)platformTicket;
        List<CustomFieldBo> customFieldBoList = new ArrayList<>();
        for(ZendeskCustomField zendeskCustomField:zendeskTicket.getCustomFields()){
            customFieldBoList.add(new CustomFieldBo(Long.toString(zendeskCustomField.getId()),
                    zendeskCustomField.getValue()));
        }
        return customFieldBoList;
    }

    @Override
    public ThirdPartyData createThirdPartyDataForTicket(Ticket ticket, Object platformConversations) {
        ZendeskComment zendeskComment = (ZendeskComment)platformConversations;
        return createThirdPartyData(ticket,zendeskComment.getHtmlBody());
    }

    private TicketListBo getTicketListBo(ZendeskTicketResponseDto zendeskTicketResponseDto) {
        TicketListBo ticketListBo = new TicketListBo();
        List<Object> ticketList = new ArrayList<>();
        ticketList.addAll(zendeskTicketResponseDto.getTickets());
        ticketListBo.setTicketList(ticketList);
        Map<String, Object> paramList = new HashMap<>();
        if (!zendeskTicketResponseDto.getEndOfStream()) {
            paramList.put(MigrationPlatformConstants.PARAM_KEY_NEXT_TICKET_URL, zendeskTicketResponseDto.getAfterUrl());
        }else{
            paramList.put(MigrationPlatformConstants.PARAM_KEY_NEXT_TICKET_URL, null);
        }
        ticketListBo.setParams(paramList);
    return ticketListBo;
    }

    @Override
    public Boolean shouldMigrationContinue(TicketListBo ticketListBo,TicketMigrationStats ticketMigrationStats,
                                           MigrationLog migrationLog,BrandConfigurationDto brandConfigurationDto){
        List<ZendeskTicket> zendeskTicketList = new ArrayList<>();
        for(Object ticket:ticketListBo.getTicketList()){
            zendeskTicketList.add((ZendeskTicket) ticket);
        }
        if(Objects.nonNull(migrationLog.getEndTimestamp())){
            return !(zendeskTicketList.get(0).getGeneratedTimestamp() > migrationLog.getEndTimestamp());
        }else{
            return true;
        }
    }

    @Override
    public Boolean shouldTicketBeMigrated(Object ticket, TicketMigrationStats ticketMigrationStats,
                                          BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog,
                                          BrandFieldConfiguration brandFieldConfiguration
                                          ) {
        ZendeskTicket zendeskTicket = (ZendeskTicket) ticket;
        if ((Objects.isNull(migrationLog.getEndTimestamp()) || (Objects.nonNull(migrationLog.getEndTimestamp())
                && migrationLog.getEndTimestamp() > zendeskTicket.getGeneratedTimestamp()))
        ) {
            if (doesTicketAlreadyExist(brandConfigurationDto.getBrandId(), zendeskTicket.getId(), brandFieldConfiguration)) {
                ticketMigrationStats.setTicketsAlreadyMigrated(ticketMigrationStats.getTicketsAlreadyMigrated() + 1);
                return false;
            }
            return true;
        }
        return false;
    }

    @Override
    public void createTicketFailureMigrationLog(Integer brandId,Integer migrationLogId,Object platformTicket, Exception e){
        ZendeskTicket zendeskTicket = (ZendeskTicket)platformTicket;
        try{
            CustomInternalServerException exception = (CustomInternalServerException)e;
            logger.info("Migration service error for brand id :: {} Zendesk Ticket ID :: {} Error code :: {}  Error message :: {}",
                    brandId,zendeskTicket.getId(), exception.getErrorCode().getCode(), exception.getErrorCode().getMessage());
        }catch (Exception ex){
            logger.info("An unexpected error occurred while migrating tickets for brand id :: {} Zendesk Ticket ID :: {} Error :: {} ",brandId,zendeskTicket.getId(),Arrays.toString(e.getStackTrace()));
        }
        createZendeskTicketMigrationLog(migrationLogId,zendeskTicket.getId().longValue(), null, null, TicketMigrationEnum.FAILED);
    }

    @Override
    public ConversationListBo getConversationsForTicket(Object ticket,BrandConfigurationDto brandConfigurationDto){
        ConversationListBo conversationListBo = new ConversationListBo();
        ZendeskTicket zendeskTicket = (ZendeskTicket)ticket;
        ZendeskCommentsDto zendeskComments = processComments(zendeskTicket.getId(), brandConfigurationDto);
        List<Object> platformConversation = new ArrayList<>();
        platformConversation.addAll(zendeskComments.getComments());
        conversationListBo.setPlatformConversations(platformConversation);
        return conversationListBo;
    }
    @Override
    public CustomerBo getCustomerForTicket(Object ticket,BrandConfigurationDto brandConfigurationDto){
        ZendeskTicket zendeskTicket = (ZendeskTicket)ticket;
        ZendeskUserDto zendeskCustomerDto = processUsers(zendeskTicket.getRequesterId(),brandConfigurationDto);
        CustomerBo customerBo = new CustomerBo();
        customerBo.setPlatformCustomer(zendeskCustomerDto.getUser());
        return customerBo;
    }

    @Override
    public Customer createCustomerFromPlatformCustomer(CustomerBo platformCustomer, BrandConfigurationDto brandConfigurationDto){
        ZendeskUser zendeskUser = (ZendeskUser)platformCustomer.getPlatformCustomer();
        return createCustomer(zendeskUser,brandConfigurationDto);
    }

    @Override
    public PlatformCustomerMappingEntity getPlatformCustomerMapping(Object platformTicket,BrandConfigurationDto brandConfigurationDto){
        ZendeskTicket zendeskTicket = (ZendeskTicket)platformTicket;
        return getPlatformCustomerMapping(zendeskTicket.getRequesterId(),brandConfigurationDto.getId());
    }

    @Override
    public PlatformCustomerMappingEntity createPlatformCustomerMapping( Object platformCustomer,
                                                                             BrandConfigurationDto brandConfigurationDto,
                                                                             Customer customer
                                                                             ) {
        ZendeskUser zendeskUser = (ZendeskUser)platformCustomer;
        return createPlatformCustomerMapping(zendeskUser.getId(),customer.getId(),
                brandConfigurationDto.getId());
    }

    @Override
    public List<CustomerLabelValue> createCustomerLabelValue(Customer customer, CustomerBo platformCustomer, BrandConfigurationDto brandConfigurationDto, BrandFieldConfiguration brandFieldConfiguration) {
        ZendeskUser zendeskUser = (ZendeskUser)platformCustomer.getPlatformCustomer();
        return createCustomerLabelValues(brandFieldConfiguration,brandConfigurationDto,customer,zendeskUser.getEmail(), zendeskUser.getPhone());
    }
    @Override
    public Long getBrandUserId(Object platformTicket,BrandConfigurationDto brandConfigurationDto){
        ZendeskTicket zendeskTicket = (ZendeskTicket)platformTicket;
        return getBrandUserId(zendeskTicket.getAssigneeId(),brandConfigurationDto.getDefaultAgentId(),brandConfigurationDto.getId());
    }

    @Override
    public QueuedAttachmentsDto createQueuedAttachmentDto(Object platformConversation,
                                                                           Ticket ticket,
                                                                           ThirdPartyData thirdPartyData,
                                                                           BrandConfigurationDto brandConfigurationDto,
                                                                           ForwardFeed forwardFeed
                                                                           ){
        ZendeskComment zendeskComment = (ZendeskComment)platformConversation;
        if(Objects.nonNull(zendeskComment.getAttachments())
                && (zendeskComment.getAttachments().size() != 0)){
            if(Objects.nonNull(forwardFeed)){
                return createQueuedAttachmentDto(brandConfigurationDto.getBrandId(),
                        ticket.getId(),forwardFeed.getId(),
                        null,zendeskComment,forwardFeed.getCreatedAt(),
                        forwardFeed.getUpdatedAt(),brandConfigurationDto.getPlatformId());
            }else{
                return createQueuedAttachmentDto(brandConfigurationDto.getBrandId() , ticket.getId(),
                        null,thirdPartyData.getId(),
                        zendeskComment,thirdPartyData.getCreatedAt(),
                        thirdPartyData.getUpdatedAt(),brandConfigurationDto.getPlatformId());
            }
        }
        return null;
    }
    @Override
    public Map<String, String> uploadAttachmentsForThirdPartyData(String attachmentListJson, Integer brandId){
        List<ZendeskAttachment> zendeskAttachmentList = zendeskService
                .getZendeskAttachmentsFromJson(attachmentListJson);
        return zendeskService.uploadAttachments(zendeskAttachmentList,brandId);
    }

    @Override
    public  List<ForwardFeedAttachmentDto> uploadAttachmentsForForwardFeed(String attachmentListJson,Integer brandId){
        List<ZendeskAttachment> zendeskAttachmentList = zendeskService
                .getZendeskAttachmentsFromJson(attachmentListJson);
        List<ForwardFeedAttachmentDto>  forwardFeedAttachmentDtos =  zendeskService.createForwardFeedAttachmentDtoList(zendeskAttachmentList,brandId);
        return forwardFeedAttachmentDtos;
    }


    @Override
    public ForwardFeed createForwardFeed(Ticket ticket, Object platformConversation, Object platformTicket){
        ZendeskComment zendeskComment = (ZendeskComment)platformConversation;
        ZendeskTicket zendeskTicket = (ZendeskTicket)platformTicket;
        return zendeskService.createOnedirectForwardFeed(ticket,zendeskComment,zendeskTicket);
    }

    @Override
    public ForwardCustomerInfoValueJsonDto createForwardCustomerInfoValueDto(Object platformTicket,
                                                                             Object platformConversation,
                                                                             BrandConfigurationDto brandConfigurationDto,
                                                                             Long customerId,
                                                                             BrandFieldConfiguration brandFieldConfiguration
                                                                             ){
        ZendeskTicket zendeskTicket = (ZendeskTicket)platformTicket;
        ZendeskComment zendeskComment = (ZendeskComment)platformConversation;
        ZendeskUserDto zendeskUserForComment = zendeskService.fetchZendeskUserInfo(zendeskTicket.getRequesterId(), brandConfigurationDto);
        return generateValueJsonForForwardCustomerInfoDto(!zendeskComment.get_public(),
                !zendeskTicket.getRequesterId().equals(zendeskComment.getAuthorId()),
                zendeskUserForComment.getUser().getName(),zendeskUserForComment.getUser().getEmail(),brandConfigurationDto);
    }

    @Override
    public void createTicketSuccessMigrationLog(Integer migrationLogId,Ticket ticket,Object platformTicket){
        ZendeskTicket zendeskTicket = (ZendeskTicket) platformTicket;
        migrationDataService.createTicketMigrationLog(migrationLogId, zendeskTicket.getId(),
                ticket.getBrandTicketId(), ticket.getId(), TicketMigrationEnum.SUCCESS);
    }

    @Override
    public Ticket createTicketFromPlatformTicket(Object platformTicket, Integer brandId, Long oneDirectCustomerId,
                                                 Integer brandUserId, Long latestBrandTicketId){
        ZendeskTicket zendeskTicket = (ZendeskTicket) platformTicket;
        return createTicket(zendeskTicket,brandId,oneDirectCustomerId,brandUserId,latestBrandTicketId);
    }

    private QueuedAttachmentsDto createQueuedAttachmentDto(Integer brandId, Long ticketId, Long forwardFeedId,
                                                           Long thirdPartyDataId,
                                                           ZendeskComment zendeskComment, Date createdAt, Date updatedAt,
                                                           Integer platformId
                                                           ) {
        return migrationDataService.createQueuedAttachmentDto(brandId,ticketId,forwardFeedId,
                thirdPartyDataId,zendeskComment.getId(),
                createdAt,updatedAt,platformId,gson.toJson(zendeskComment.getAttachments()));
    }

    private void createZendeskTicketMigrationLog(Integer migrationLogId,Long zendeskTicketId, Long brandTicketId, Long oneDirectTicketId, TicketMigrationEnum ticketMigrationEnum) {
        migrationDataService.createTicketMigrationLog(migrationLogId,zendeskTicketId, brandTicketId, oneDirectTicketId, ticketMigrationEnum);
    }

    private ZendeskCommentsDto processComments(Long zendeskTicketId, BrandConfigurationDto brandConfigurationDto) {
        return zendeskService.fetchCommentsByZendeskTicketId(zendeskTicketId, brandConfigurationDto);
    }

    private ZendeskUserDto processUsers(Long requesterId, BrandConfigurationDto brandConfigurationDto){
        return zendeskService.fetchZendeskUserInfo(requesterId,brandConfigurationDto);
    }

    private Customer createCustomer(ZendeskUser zendeskUser, BrandConfigurationDto brandConfigurationDto) throws CustomInternalServerException{
        return zendeskService.addCustomer(zendeskUser,brandConfigurationDto);
    }




    private Ticket createTicket(ZendeskTicket zendeskTicket, Integer brandId, Long customerId, Integer brandUserId, Long brandTicketId) {
        return zendeskService.createOneDirectTicket(zendeskTicket, brandId, customerId, brandUserId, brandTicketId);
    }

}

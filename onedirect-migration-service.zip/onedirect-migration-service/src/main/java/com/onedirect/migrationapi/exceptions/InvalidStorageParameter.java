package com.onedirect.migrationapi.exceptions;

import com.onedirect.commonutils.exceptions.exception.ServiceException;
import com.onedirect.datautils.enums.ErrorCode;

/**
 * @author jp
 */
public class InvalidStorageParameter extends ServiceException {
    public InvalidStorageParameter(String message, Exception exception, String... info) {
        super(ErrorCode.NO_STORAGE_TYPE.getCode(), message, exception, info);
    }

    public InvalidStorageParameter(String message, String... info) {
        super(ErrorCode.NO_STORAGE_TYPE.getCode(), message, info);
    }
}

package com.onedirect.migrationapi.exceptions;

import com.onedirect.commonutils.exceptions.exception.ServiceException;
import com.onedirect.migrationapi.enums.ErrorCodes;
import org.springframework.http.HttpStatus;

/**
 * @author jp
 */
public class CustomInternalServerException extends RuntimeException {

    private ErrorCodes errorCode;
    private HttpStatus httpStatus;

    public CustomInternalServerException(String message) {
        super(message);
    }

    public CustomInternalServerException(String message, ErrorCodes errorCodes) {
        super(message);
        this.errorCode = errorCodes;
    }

    public CustomInternalServerException(String message, Throwable cause, ErrorCodes errorCode) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public CustomInternalServerException(String message, ErrorCodes codes, HttpStatus httpStatus) {
        super(message);
        this.errorCode = codes;
        this.httpStatus = httpStatus;
    }

    public ErrorCodes getErrorCode() {
        return errorCode;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}

package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.entities.ThirdPartyData;
import com.onedirect.migrationapi.entities.Ticket;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;

public interface ValidationService {
    public void validateCustomer(Customer customer) throws CustomInternalServerException;
    public void validateTicketRequest(Ticket ticket) throws CustomInternalServerException;
    public void validateThirdPartyData(ThirdPartyData thirdPartyData) throws CustomInternalServerException;
}

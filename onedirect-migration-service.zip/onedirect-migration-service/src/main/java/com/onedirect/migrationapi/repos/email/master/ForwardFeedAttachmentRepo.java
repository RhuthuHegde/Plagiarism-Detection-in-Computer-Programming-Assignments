package com.onedirect.migrationapi.repos.email.master;

import com.onedirect.migrationapi.entities.ForwardFeedAttachment;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface ForwardFeedAttachmentRepo extends JpaRepository<ForwardFeedAttachment, Long> {

    @Transactional
    @Modifying
    @Query(value = "update ForwardFeedAttachment  efa " +
            "set efa.valueJson=:updatedAttachments where " +
            "efa.brandId=:brandId and " +
            "efa.feedId=:feedId and " +
            "efa.status=1")
    void updateByFeedIdAndBrandId(@Param("feedId") Long feedId, @Param("brandId") Integer brandId, @Param
            ("updatedAttachments") String updatedAttachments);

    @Query(value = "select efa from ForwardFeedAttachment efa where efa.feedId=:feedId and efa.brandId=:brandId and efa.status=1")
    ForwardFeedAttachment findByFeedIdAndBrandId(@Param("feedId") Long feedId, @Param("brandId") Integer brandId);
}


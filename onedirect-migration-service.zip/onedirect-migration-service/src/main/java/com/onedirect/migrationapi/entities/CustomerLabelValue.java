package com.onedirect.migrationapi.entities;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "customer_label_value")
public class CustomerLabelValue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "brand_id")
    private Integer brandId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "customer_label_id")
    private Integer customerLabelId;

    @Column(name = "customer_label_option_id")
    private Long customerLabelOptionId;

    @Column(name = "customer_label_search")
    private String customerLabelSearch;

    @Column(name = "customer_label_text")
    private String customerLabelText;

    @Column(name = "customer_label_int")
    private Long customerLabelInt;

    @Column(name = "customer_label_decimal")
    private BigDecimal customerLabelDecimal;

    @Column(name = "customer_label_latitude")
    private BigDecimal customerLabelLat;

    @Column(name = "customer_label_longitude")
    private BigDecimal customerLabelLong;

    @Column(name = "customer_label_datetime")
    private Date customerLabelDate;

    @Column(name = "customer_label_bool")
    private Byte customerLabelBool;

    @Column(name = "customer_label_address")
    private String customerLabelAddress;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "status")
    private Byte status;

    @Column(name = "product_id")
    private Byte productId;


}
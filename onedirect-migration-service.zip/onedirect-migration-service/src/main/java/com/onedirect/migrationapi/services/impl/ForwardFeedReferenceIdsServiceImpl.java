package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.ForwardFeedReferenceIds;
import com.onedirect.migrationapi.repos.email.master.ForwardFeedReferenceIdsRepo;
import com.onedirect.migrationapi.services.ForwardFeedReferenceIdsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ForwardFeedReferenceIdsServiceImpl implements ForwardFeedReferenceIdsService {

    @Autowired
    ForwardFeedReferenceIdsRepo forwardFeedReferenceIdsRepo;

    @Override
    public ForwardFeedReferenceIds createForwardFeedReferenceIds(ForwardFeedReferenceIds forwardFeedReferenceIds) {
        return forwardFeedReferenceIdsRepo.save(forwardFeedReferenceIds);
    }
}

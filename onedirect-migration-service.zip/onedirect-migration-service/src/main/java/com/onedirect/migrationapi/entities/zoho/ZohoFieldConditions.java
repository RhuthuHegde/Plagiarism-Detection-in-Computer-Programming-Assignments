package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoFieldConditions {

    private String fieldName;
    private List<Long> value;
    private String condition;
    private String fieldModule;
}

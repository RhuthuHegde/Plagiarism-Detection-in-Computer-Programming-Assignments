package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="zoho_account")
public class ZohoAccountOrg {
    @Id
    private Long id;
    private Long ownerId;
    private String accountName;
    private String phone;
    private String email;
    private String fax;
    private String website;
    private String industry;
    private Double annualrevenue;
    private Long createdBy;
    private Long modifiedBy;
    private Date createdTime;
    private Date modifiedTime;
    private String street;
    private String city;
    private String state;
    private String code;
    private String country;
    private String description;
    private Long crmAccountId;
    private Long layoutId;

}

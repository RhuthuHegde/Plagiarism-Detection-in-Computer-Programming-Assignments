package com.onedirect.migrationapi.dtos.zendesk.branduser;

import com.fasterxml.jackson.annotation.*;

import java.util.*;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskUserFields {
    private Boolean active;
    @JsonProperty("created_at")
    private String createdAt;
    @JsonProperty("custom_field_options")
    private List<ZendeskCustomFieldOptions> customFieldOptions;
    private String description;
    private Integer id;
    private String key;
    private Integer position;
    @JsonProperty("raw_description")
    private String rawDescription;
    @JsonProperty("raw_title")
    private String rawTitle;
    @JsonProperty("regexp_for_validation")
    private String regexForValidation;
    private Boolean system;
    private String tag;
    private String title;
    private String type;
    @JsonProperty("updated_at")
    private String updatedAt;
    private String url;
}

package com.onedirect.migrationapi.enums;

import java.util.HashMap;

public enum TicketMigrationEnum {
    SUCCESS((byte)1),
    FAILED((byte)0);

    /**
     * The constant values.
     */
    public static final String values;

    /**
     * The reverse map.
     */
    static HashMap<Byte, TicketMigrationEnum> reverseMap;

    private byte id;
    TicketMigrationEnum(byte id){
        this.id = id;
    }

    public byte getId(){
        return this.id;
    }

    static {
        String sep = "";
        String val = "";
        reverseMap = new HashMap<>();
        for (TicketMigrationEnum ticketMigrationEnum : TicketMigrationEnum.values()) {
            reverseMap.put(ticketMigrationEnum.getId(), ticketMigrationEnum);
            val += sep + ticketMigrationEnum.id;
            sep = ",";
        }
        values = "(" + val + ")";
    }

    public static boolean isValidId(Integer id) {
        if(id == null) {
            return true;
        }
        return reverseMap.containsKey(id.byteValue());
    }
}

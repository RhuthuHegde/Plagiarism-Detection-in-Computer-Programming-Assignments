package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.beans.UtilBean;
import com.onedirect.migrationapi.bos.StorageBootstrapCondition;
import com.google.cloud.storage.*;
import com.onedirect.commonutils.utils.StringUtil;
import com.onedirect.migrationapi.dtos.FileMetaData;
import com.onedirect.migrationapi.dtos.StorageObject;
import com.onedirect.migrationapi.enums.StorageType;
import com.onedirect.migrationapi.exceptions.InvalidStorageParameter;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriUtils;
import com.onedirect.migrationapi.services.StorageService;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * @author jp
 */

@Service
@Conditional({StorageBootstrapCondition.class})
public class GoogleStorageService implements StorageService {
    @Autowired
    private Storage gcpStorageInstance;
    @Autowired
    private UtilBean utilBean;
    private static final Tika tika = new Tika();

    public GoogleStorageService() {
    }

    public FileMetaData upload(InputStream inputStream, StorageObject storageObject) throws IOException {
        byte[] fileBytes = this.getFileBytes(inputStream);
        return this.uploadToGoogleStorage(fileBytes, storageObject);
    }

    public FileMetaData upload(byte[] fileByteArray, StorageObject storageObject) {
        byte[] fileBytes = this.getFileBytes(fileByteArray);
        return this.uploadToGoogleStorage(fileBytes, storageObject);
    }

    public FileMetaData upload(File file, StorageObject storageObject) throws IOException {
        byte[] fileBytes = this.getFileBytes(file);
        return this.uploadToGoogleStorage(fileBytes, storageObject);
    }

    public FileMetaData uploadAsync(File file, StorageObject storageObject) throws IOException {
        byte[] fileBytes = this.getFileBytes(file);
        return this.uploadAsync(fileBytes, storageObject);
    }

    public FileMetaData uploadAsync(InputStream inputStream, StorageObject storageObject) throws IOException {
        byte[] fileBytes = this.getFileBytes(inputStream);
        return this.uploadAsync(fileBytes, storageObject);
    }

    public FileMetaData uploadAsync(byte[] fileByteArray, StorageObject storageObject) {
        byte[] fileBytes = this.getFileBytes(fileByteArray);
        return this.uploadToGoogleStorageAsync(fileBytes, storageObject);
    }

    public byte[] getBytes(String url) throws IOException {
        BufferedInputStream in = this.getInputStream(url);
        return IOUtils.toByteArray(in);
    }

    public BufferedInputStream getInputStream(String url) throws IOException {
        return new BufferedInputStream((new URL(url)).openStream());
    }

    public Boolean delete(String uniqueName) {
        return this.gcpStorageInstance.delete(this.utilBean.getBucket(), uniqueName, new Storage.BlobSourceOption[0]);
    }

    public FileMetaData startTransaction(File file, StorageObject storageObject) throws IOException {
        byte[] fileBytes = this.getFileBytes(file);
        return this.uploadToGoogleStorage(fileBytes, this.createTransactionStorageObject(storageObject));
    }

    public void commitTransaction(String uniqueName) {
        Blob blob = this.gcpStorageInstance.get(this.utilBean.getBucket(), uniqueName, new Storage.BlobGetOption[0]);
        blob.copyTo(this.utilBean.getBucket(), this.getOriginalUniqueName(uniqueName), new com.google.cloud.storage.Blob.BlobSourceOption[0]);
        blob.delete(new com.google.cloud.storage.Blob.BlobSourceOption[0]);
    }

    private StorageObject createTransactionStorageObject(StorageObject storageObject) {
        storageObject.setUniqueName(this.getTempName(storageObject.getUniqueName()));
        return storageObject;
    }

    private String getTempName(String uniqueName) {
        return "temp/" + uniqueName;
    }

    private String getOriginalUniqueName(String tempName) {
        return tempName.startsWith("temp/") ? tempName.replaceFirst("temp/", "") : tempName;
    }

    private byte[] getFileBytes(InputStream stream) throws IOException {
        if (stream == null) {
            throw new InvalidStorageParameter("Corrupted stream of file to upload", new String[0]);
        } else {
            return IOUtils.toByteArray(stream);
        }
    }

    private byte[] getFileBytes(File file) throws IOException {
        if (file != null && file.exists()) {
            return FileUtils.readFileToByteArray(file);
        } else {
            throw new InvalidStorageParameter("File not found", new String[0]);
        }
    }

    private byte[] getFileBytes(byte[] fileBytes) {
        if (fileBytes == null) {
            throw new InvalidStorageParameter("Corrupted byte array", new String[0]);
        } else {
            return fileBytes;
        }
    }

    private String bucketName() {
        return this.utilBean.getBucket();
    }

    private FileMetaData uploadToGoogleStorage(byte[] storageBytes, StorageObject storageObject) {
        storageObject.validate();
        FileMetaData fileMetaData = this.mapToFileMetaData(storageBytes, storageObject);
        BlobInfo blobInfo = this.blobInfo(fileMetaData);
        this.gcpStorageInstance.create(blobInfo, storageBytes, new Storage.BlobTargetOption[0]);
        return fileMetaData;
    }

    private FileMetaData uploadToGoogleStorageAsync(byte[] storageBytes, StorageObject storageObject) {
        storageObject.validate();
        FileMetaData fileMetaData = this.mapToFileMetaData(storageBytes, storageObject);
        (new Thread(() -> {
            BlobInfo blobInfo = this.blobInfo(fileMetaData);
            this.gcpStorageInstance.create(blobInfo, storageBytes, new Storage.BlobTargetOption[0]);
        })).start();
        return fileMetaData;
    }

    private BlobInfo blobInfo(FileMetaData fileMetaData) {
        BlobId blobId = BlobId.of(this.bucketName(), fileMetaData.getUniqueId());
        return BlobInfo.newBuilder(blobId).setContentType(fileMetaData.getContentType()).setContentDisposition(fileMetaData.getContentDisposition()).build();
    }

    private String contentDisposition(StorageObject storageObject) {
        return storageObject.getContentDisposition() == null ? "inline; filename=" + this.URLEncodeIfNotEncoded(storageObject.getFileLabel()) : storageObject.getContentDisposition();
    }

    private FileMetaData mapToFileMetaData(byte[] storageBytes, StorageObject storageObject) {
        return FileMetaData.Builder().contentType(
                this.contentType(storageBytes, storageObject)).fileName(
                        storageObject.getFileLabel()).storageType(
                                StorageType.GCP).url(this.resourceUrl(
                                        storageObject)).contentLength(
                                                (long)storageBytes.length).uniqueId(
                                                        this.filePath(storageObject)).contentDisposition(
                                                                this.contentDisposition(storageObject)).build();
    }

    private String contentType(byte[] storageBytes, StorageObject storageObject) {
        return storageObject.getContentType() != null ? storageObject.getContentType() : tika.detect(storageBytes);
    }

    private String resourceUrl(StorageObject storageObject) {
        String rawFilePath = StringUtil.mark(this.utilBean.getMediaLinkTemplate(), new Object[]{this.utilBean.getBucket(), this.filePath(storageObject)});
        return this.URLEncodeIfNotEncoded(rawFilePath);
    }

    private String filePath(StorageObject storageObject) {
        return this.getFolder() + this.resolveSpecialCharacters(storageObject.getUniqueName());
    }

    private String resolveSpecialCharacters(String fileName) {
        return fileName.replaceAll(" ", "%20");
    }

    private String getFolder() {
        return this.utilBean.getProject() + "/";
    }

    private String URLEncodeIfNotEncoded(String str) {
        String decodedUrl = this.URLDecode(str);
        return decodedUrl == null ? this.URLEncode(str) : this.URLEncode(decodedUrl);
    }

    private String URLEncode(String str) {
        try {
            return str != null ? UriUtils.encode(str, "UTF-8") : null;
        } catch (Exception var4) {
            return null;
        }
    }

    private String URLDecode(String str) {
        try {
            return str != null ? UriUtils.decode(str, "UTF-8") : null;
        } catch (Exception var4) {
            return null;
        }
    }

    private Bucket createBucketIfNotExisting() {
        String bucketName = this.bucketName();
        Bucket bucket = this.gcpStorageInstance.get(bucketName, new Storage.BucketGetOption[]{Storage.BucketGetOption.fields(new Storage.BucketField[0])});
        if (bucket == null) {
            bucket = this.gcpStorageInstance.create(BucketInfo.of(bucketName), new Storage.BucketTargetOption[0]);
        }

        return bucket;
    }
}

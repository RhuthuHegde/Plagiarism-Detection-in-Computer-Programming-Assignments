package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.dtos.ForwardFeedAttachmentDto;
import com.onedirect.migrationapi.dtos.QueuedAttachmentsDto;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.enums.TicketFieldValueTypeEnum;
import com.onedirect.migrationapi.enums.TicketMigrationEnum;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.repos.customer.slave.CustomerLabelValueRepo;
import com.onedirect.migrationapi.repos.migration.master.MigrationLogMasterRepo;
import com.onedirect.migrationapi.repos.migration.master.PlatformCustomerMappingMasterRepo;
import com.onedirect.migrationapi.repos.migration.slave.BrandConfigurationRepo;
import com.onedirect.migrationapi.repos.migration.slave.MigrationLogRepo;
import com.onedirect.migrationapi.repos.migration.slave.PlatformAgentMappingRepo;
import com.onedirect.migrationapi.repos.migration.slave.PlatformCustomerMappingRepo;
import com.onedirect.migrationapi.services.*;
import com.onedirect.migrationapi.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class MigrationDataServiceImpl implements MigrationDataService {

    @Autowired
    ValidationService validationService;

    @Autowired
    ThirdPartyDataService thirdPartyDataService;

    @Autowired
    ThirdPartyTicketMappingService thirdPartyTicketMappingService;

    @Autowired
    ForwardFeedService forwardFeedService;

    @Autowired
    ForwardCustomerInfoService forwardCustomerInfoService;

    @Autowired
    ForwardFeedReferenceIdsService forwardFeedReferenceIdsService;

    @Autowired
    MigrationLogMasterRepo migrationLogMasterRepo;

    @Autowired
    BrandConfigurationRepo brandConfigurationRepo;

    @Autowired
    MigrationLogRepo migrationLogRepo;

    @Autowired
    CustomerService customerService;

    @Autowired
    CustomerLabelValueService customerLabelValueService;

    @Autowired
    TicketFieldValueService ticketFieldValueService;

    @Autowired
    TicketTagService ticketTagService;

    @Autowired
    TicketService ticketService;

    @Autowired
    ThirdPartyDataAttachmentService thirdPartyDataAttachmentService;

    @Autowired
    ForwardFeedAttachmentService forwardFeedAttachmentService;
    private static Gson gson = new Gson();

    @Autowired
    TicketMigrationLogService ticketMigrationLogService;

    @Autowired
    PlatformAgentMappingRepo platformAgentMappingRepo;

    @Autowired
    PlatformCustomerMappingRepo platformCustomerMappingRepo;

    @Autowired
    PlatformCustomerMappingMasterRepo platformCustomerMappingMasterRepo;



    @Override
    public ThirdPartyData addThirdPartyData(Ticket ticket,String description){
        ThirdPartyData thirdPartyData = buildThirdPartyDataFromTicket(ticket,description);
        validationService.validateThirdPartyData(thirdPartyData);
        ThirdPartyData insertedThirdPartyData = thirdPartyDataService.addThirdPartyData(thirdPartyData);
        if (Objects.nonNull(insertedThirdPartyData)) {
            return insertedThirdPartyData;
        }
        else {
            throw new CustomInternalServerException("Error while creating third_party_data",
                    ErrorCodes.FAILED_TO_CREATE_THIRD_PARTY_DATA);
        }
    }

    private ThirdPartyData buildThirdPartyDataFromTicket(Ticket ticket,String description) {
        ThirdPartyData thirdPartyData = new ThirdPartyData();
        thirdPartyData.setId(null);
        thirdPartyData.setBrandId(ticket.getBrandId());
        thirdPartyData.setSubSource(Integer.valueOf(ticket.getSubSource()));
        if (Objects.nonNull(ticket.getSubject())) {
            String od3subject = ticket.getSubject();
            if(od3subject.length() > 1500)
                od3subject = od3subject.substring(0, 1499);
            thirdPartyData.setSubject(od3subject);
        }
        thirdPartyData.setDescription(description);
        thirdPartyData.setRating(null);
        thirdPartyData.setUrl(null);
        thirdPartyData.setIsEditable((byte)0);
        thirdPartyData.setCreatedAt(ticket.getCreatedAt());
        thirdPartyData.setCreatedBy(Constants.INT_SYSTEM_USER);
        thirdPartyData.setUpdatedAt(new Date());
        thirdPartyData.setOriginalId(null);
        thirdPartyData.setRecordStatus((byte)1);
        return thirdPartyData;
    }


    @Override
    public ForwardFeed addForwardFeed(ForwardFeed forwardFeed) {
        ForwardFeed savedForwardFeed = forwardFeedService.createForwardFeed(forwardFeed);
        if (Objects.nonNull(savedForwardFeed))
            return  savedForwardFeed;
        else
            throw new CustomInternalServerException("Unable to create forward feed",ErrorCodes.FAILED_TO_CREATE_FORWARD_FEED);
    }

    @Override
    public Customer addCustomer(Customer customer) {
        validationService.validateCustomer(customer);
        Customer addedCustomer = customerService.addCustomer(customer);
        if (Objects.nonNull(addedCustomer)) {
            return addedCustomer;
        }
        else {
            throw new CustomInternalServerException("Error while creating customer",
                    ErrorCodes.FAILED_TO_CREATE_CUSTOMER);
        }
    }

    @Override
    public CustomerLabelValue addCustomerLabelValue(CustomerLabelValue customerLabelValue) {
        CustomerLabelValue insertedCustomerLabelValue = customerLabelValueService.addCustomerLabelValue(customerLabelValue);
        if (Objects.nonNull(insertedCustomerLabelValue)) {
            return insertedCustomerLabelValue;
        }
        else {
            throw new CustomInternalServerException("Error while creating customer_label_value",
                    ErrorCodes.FAILED_TO_CREATE_CUSTOMER_LABEL_VALUE);
        }
    }

    @Override
    public ForwardCustomerInfo createForwardCustomerInfo(ForwardFeed forwardFeed, String valueJson) {
        ForwardCustomerInfo forwardCustomerInfo = buildForwardCustomerInfo(forwardFeed,valueJson);
        ForwardCustomerInfo savedForwardCustomerInfo = forwardCustomerInfoService.createForwardCustomerInfo(forwardCustomerInfo);
        if (Objects.nonNull(savedForwardCustomerInfo)) {
            return  forwardCustomerInfo;
        }
        else {
            throw new CustomInternalServerException("Error while creating forward_customer_info"
                    , ErrorCodes.FAILED_TO_CREATE_FORWARD_CUSTOMER_INFO);
        }
    }

    @Override
    public ForwardFeedReferenceIds createForwardFeedReferenceIds(ForwardFeed forwardFeed) {
        ForwardFeedReferenceIds forwardFeedReferenceIds = createForwardFeedReferenceIdsFromForwardFeed(forwardFeed);
        ForwardFeedReferenceIds savedForwardFeedReferenceIds =forwardFeedReferenceIdsService.createForwardFeedReferenceIds(forwardFeedReferenceIds);
        if (Objects.nonNull(savedForwardFeedReferenceIds)) {
            return savedForwardFeedReferenceIds;
        }
        else {
            throw new CustomInternalServerException("Error while creating forward_feed_reference_ids",
                    ErrorCodes.FAILED_TO_CREATE_FORWARD_FEED_REFERENCE_IDS);
        }
    }

    @Override
    public ThirdPartyTicketMapping createThirdPartyTicketMapping(Ticket ticket, Long thirdPartyDataId, Long oneDirectCustomerId, Long brandUserId) {
        ThirdPartyTicketMapping thirdPartyTicketMapping = buildThirdPartyTicketMapping(ticket,thirdPartyDataId,oneDirectCustomerId,brandUserId);
        ThirdPartyTicketMapping insertedThirdPartyTicketMapping = thirdPartyTicketMappingService.addThirdPartyTicketMapping(thirdPartyTicketMapping);
        if (Objects.nonNull(insertedThirdPartyTicketMapping)) {
            return insertedThirdPartyTicketMapping;
        }
        else {
            throw new CustomInternalServerException("Error while creating third_party_ticket_mapping",
                    ErrorCodes.FAILED_TO_CREATE_THIRD_PARTY_TICKET_MAPPING);
        }
    }

    @Override
    public Integer createMigrationLog(MigrationLog migrationLog) {
        MigrationLog savedMigrationLog = migrationLogMasterRepo.save(migrationLog);
        return savedMigrationLog.getId();
    }

    @Override
    public BrandConfigurationEntity getBrandConfigurationEntityByBrandIdAndPlatformId(Integer brandId, Integer platformId) {
        return brandConfigurationRepo.findAccountByBrandIdAndPlatformId(brandId, platformId);
    }

    @Override
    public MigrationLog getMigrationLogById(Integer migrationLogId) {
        Optional<MigrationLog> migrationLogOptional = migrationLogRepo.findById(migrationLogId);
        if(migrationLogOptional.isPresent())
            return migrationLogOptional.get();
        else
            return null;
    }

    @Override
    public BrandConfigurationEntity getBrandConfigurationEntityById(Integer brandConfigurationId) {
        return brandConfigurationRepo.findAccountById(brandConfigurationId);
    }

    @Override
    public TicketFieldValue addTicketFieldValue(TicketFieldValue ticketFieldValue) {
        TicketFieldValue createdTicketFieldValue = ticketFieldValueService.addTicketFieldValue(ticketFieldValue);
        if (Objects.nonNull(ticketFieldValue)){
            return createdTicketFieldValue;
        }else{
            throw new CustomInternalServerException("Error while adding ticket field value",
                    ErrorCodes.FAILED_TO_CREATE_TICKET_FIELD_VALUE);
        }
    }

    @Override
    public TicketTag addTag(TicketTag tag) {
        TicketTag insertedTag = ticketTagService.addTicketTag(tag);
        if (Objects.nonNull(insertedTag)) {
            return insertedTag;
        }
        else {
            throw new CustomInternalServerException("Error while creating ticket_tag",
                    ErrorCodes.FAILED_TO_CREATE_TICKET_TAG);
        }
    }

    @Override
    public Ticket addTicket(Ticket ticket) {
        validationService.validateTicketRequest(ticket);
        Ticket insertedTicket = ticketService.addTicket(ticket);
        if (Objects.nonNull(insertedTicket)) {
            return insertedTicket;
        }
        else {
            throw new CustomInternalServerException("Error while creating ticket",
                    ErrorCodes.FAILED_TO_CREATE_TICKET);
        }
    }

    @Override
    public List<TicketFieldValue> getTicketFieldValueForGivenValue(Integer brandId, String valueToSearch, Integer ticketFieldId) {
        return ticketFieldValueService.getTicketFieldValueForGivenValue(brandId,valueToSearch,ticketFieldId);
    }

    @Override
    public ThirdPartyDataAttachment addThirdPartyDataAttachment(String attachmentName, String attachmentUrl, Integer brandId, Integer thirdPartyDataId) {
        ThirdPartyDataAttachment thirdPartyDataAttachment = thirdPartyDataAttachmentService.generateThirdPartyDataAttachment(brandId,thirdPartyDataId.longValue(),attachmentName,attachmentUrl);
        return thirdPartyDataAttachmentService.createThirdPartyDataAttachment(thirdPartyDataAttachment);
    }


    private ThirdPartyTicketMapping buildThirdPartyTicketMapping(Ticket ticket, Long thirdPartyDataId, Long customerId, Long brandUserId) {
        ThirdPartyTicketMapping thirdPartyTicketMapping = new ThirdPartyTicketMapping();
        thirdPartyTicketMapping.setId(null);
        thirdPartyTicketMapping.setBrandId(ticket.getBrandId());
        thirdPartyTicketMapping.setThirdPartyDataId(thirdPartyDataId);
        thirdPartyTicketMapping.setTicketId(ticket.getId());
        thirdPartyTicketMapping.setTeamId(null);
        thirdPartyTicketMapping.setCustomerId(customerId);
        thirdPartyTicketMapping.setBrandUserId(brandUserId.intValue());
        thirdPartyTicketMapping.setCreatedAt(ticket.getCreatedAt());
        thirdPartyTicketMapping.setUpdatedAt(new Date());
        thirdPartyTicketMapping.setRecordStatus((byte)1);
        return thirdPartyTicketMapping;
    }

    private ForwardFeedReferenceIds createForwardFeedReferenceIdsFromForwardFeed(ForwardFeed forwardFeed) {
        ForwardFeedReferenceIds forwardFeedReferenceIds = new ForwardFeedReferenceIds();
        forwardFeedReferenceIds.setBrandId(forwardFeed.getBrandId());
        forwardFeedReferenceIds.setFeedId(forwardFeed.getId());
        forwardFeedReferenceIds.setStatus((byte) 1);
        forwardFeedReferenceIds.setCreatedAt(forwardFeed.getCreatedAt());
        forwardFeedReferenceIds.setUpdatedAt(new Date());
        return forwardFeedReferenceIds;
    }

    private ForwardCustomerInfo buildForwardCustomerInfo(ForwardFeed forwardFeed, String valueJson) {
        ForwardCustomerInfo forwardCustomerInfo = new ForwardCustomerInfo();
        forwardCustomerInfo.setBrandId(forwardFeed.getBrandId());
        forwardCustomerInfo.setFeedId(forwardFeed.getId());
        forwardCustomerInfo.setValueJson(valueJson);
        forwardCustomerInfo.setCreatedAt(forwardFeed.getCreatedAt());
        forwardCustomerInfo.setUpdatedAt(new Date());
        forwardCustomerInfo.setStatus((byte) 1);
        return forwardCustomerInfo;
    }
    @Override
    public ForwardFeedAttachment createForwardFeedAttachment(Integer brandId, Long forwardFeedId, Date createdAt,
                                                             List<ForwardFeedAttachmentDto> forwardFeedAttachmentDtoList, Long zendeskCommentId
                                                             ) {
        ForwardFeedAttachment forwardFeedAttachment = buildForwardFeedAttachment(brandId,forwardFeedId,
                forwardFeedAttachmentDtoList,createdAt);
        ForwardFeedAttachment savedForwardFeedAttachment = forwardFeedAttachmentService.createForwardFeedAttachment(forwardFeedAttachment);
        if (Objects.nonNull(savedForwardFeedAttachment)) {
            return savedForwardFeedAttachment;
        }
        else {
            throw new CustomInternalServerException("Error while creating forward_feed_attachment for zendesk comment id:: "
                    + zendeskCommentId , ErrorCodes.FAILED_TO_CREATE_FORWARD_FEED_ATTACHMENT);
        }
    }

    private ForwardFeedAttachment buildForwardFeedAttachment(Integer brandId,Long forwardFeedId,
                                                             List<ForwardFeedAttachmentDto> forwardFeedAttachmentDtoList,
                                                             Date createdAt){
        ForwardFeedAttachment forwardFeedAttachment = new ForwardFeedAttachment();
        forwardFeedAttachment.setBrandId(brandId);
        forwardFeedAttachment.setFeedId(forwardFeedId);
        String valueJson = gson.toJson(forwardFeedAttachmentDtoList);
        forwardFeedAttachment.setValueJson(valueJson);
        forwardFeedAttachment.setStatus((byte) 1);
        forwardFeedAttachment.setCreatedBy(Constants.INT_SYSTEM_USER);
        forwardFeedAttachment.setCreatedAt(createdAt);
        forwardFeedAttachment.setUpdatedAt(new Date());
        return forwardFeedAttachment;
    }

    public CustomerLabelValue buildCustomerLabelValue(Long customerId, String customerEmail, Long brandId,
                                                       Date creationDate, Long customerLabelId) {
        CustomerLabelValue customerLabelValue = new CustomerLabelValue();
        customerLabelValue.setId(null);
        customerLabelValue.setBrandId(brandId.intValue());
        customerLabelValue.setCustomerId(customerId);
        customerLabelValue.setCustomerLabelId(customerLabelId.intValue());
        customerLabelValue.setCustomerLabelOptionId(null);
        customerLabelValue.setCustomerLabelSearch(customerEmail);
        customerLabelValue.setCustomerLabelText(customerEmail);
        customerLabelValue.setCustomerLabelInt(null);
        customerLabelValue.setCustomerLabelDecimal(null);
        customerLabelValue.setCustomerLabelLat(null);
        customerLabelValue.setCustomerLabelLong(null);
        customerLabelValue.setCustomerLabelDate(null);
        customerLabelValue.setCustomerLabelBool(null);
        customerLabelValue.setCustomerLabelAddress(null);
        customerLabelValue.setProductId((byte)1);
        customerLabelValue.setStatus((byte)1);
        customerLabelValue.setCreatedAt(creationDate);
        customerLabelValue.setCreatedBy(Constants.INT_SYSTEM_USER);
        customerLabelValue.setUpdatedAt(new Date());
        customerLabelValue.setUpdatedBy(Constants.INT_SYSTEM_USER);
        return customerLabelValue;
    }

    @Override
    public TicketTag buildTicketTagFromTicketId(Ticket ticket,Integer brandId,Integer ticketTagId){
        TicketTag tag = new TicketTag();
        tag.setId(null);
        tag.setBrandId(brandId);
        tag.setTicketId(ticket.getId());
        tag.setTagId(ticketTagId);
        tag.setStatus((byte)1);
        tag.setCreatedAt(ticket.getCreatedAt());
        tag.setCreatedBy(Constants.INT_SYSTEM_USER);
        tag.setUpdatedAt(new Date());
        tag.setUpdatedBy(Constants.INT_SYSTEM_USER);
        tag.setRecordStatus((byte)1);
        return tag;
    }

    @Override
    public QueuedAttachmentsDto createQueuedAttachmentDto(Integer brandId, Long ticketId, Long forwardFeedId,
                                                          Long thirdPartyDataId, Long platformConversationId,
                                                          Date createdAt, Date updatedAt, Integer platformId,
                                                          String attachmentListJson
                                                          ) {
        QueuedAttachmentsDto queuedAttachmentsDto = new QueuedAttachmentsDto();
        queuedAttachmentsDto.setBrandId(brandId);
        queuedAttachmentsDto.setTicketId(ticketId);
        queuedAttachmentsDto.setForwardFeedId(forwardFeedId);
        queuedAttachmentsDto.setThirdPartyDataId(thirdPartyDataId);
        queuedAttachmentsDto.setPlatformConversationId(platformConversationId);
        queuedAttachmentsDto.setCreatedAt(createdAt);
        queuedAttachmentsDto.setUpdatedAt(new Date());
        queuedAttachmentsDto.setPlatformId(platformId);
        queuedAttachmentsDto.setAttachmentListJson(attachmentListJson);
        return queuedAttachmentsDto;
    }

    @Override
    public TicketMigrationLog createTicketMigrationLog(Integer migrationLogId, Long platformTicketId,
                                                       Long brandTicketId, Long oneDirectTicketId,
                                                       TicketMigrationEnum status) {
        TicketMigrationLog ticketMigrationLog = buildTicketMigrationLog(migrationLogId,platformTicketId,
                brandTicketId,oneDirectTicketId,status);
        return ticketMigrationLogService.createTicketMigrationLog(ticketMigrationLog);
    }

    @Override
    public PlatformAgentMapping getPlatformAgentMapping(long assigneeId,Integer brandConfigurationId) {
        return platformAgentMappingRepo.findPlatformAgentMappingByAssigneeIdAndBrandConfigurationId(assigneeId,brandConfigurationId);
    }

    @Override
    public PlatformCustomerMappingEntity getPlatformCustomerMapping(long requesterID, Integer brandConfigurationId) {
        return platformCustomerMappingRepo.findPlatformCustomerMapping(requesterID,brandConfigurationId);
    }

    @Override
    public PlatformCustomerMappingEntity createPlatformCustomerMapping(Long platformCustomerId, Long customerId, Integer brandConfigurationId) {
        PlatformCustomerMappingEntity platformCustomerMappingEntity = new PlatformCustomerMappingEntity();
        platformCustomerMappingEntity.setPlatformCustomerId(platformCustomerId);
        platformCustomerMappingEntity.setOneDirectCustomerId(customerId);
        platformCustomerMappingEntity.setBrandConfigurationId(brandConfigurationId);
        return platformCustomerMappingMasterRepo.save(platformCustomerMappingEntity);
    }

    private TicketMigrationLog buildTicketMigrationLog(Integer migrationLogId, Long platformTicketId, Long brandTicketId,
                                                       Long oneDirectTicketId, TicketMigrationEnum status) {
        TicketMigrationLog ticketMigrationLog = new TicketMigrationLog();
        ticketMigrationLog.setMigrationLogId(migrationLogId);
        ticketMigrationLog.setPlatformTicketId(platformTicketId);
        ticketMigrationLog.setBrandTicketId(brandTicketId);
        ticketMigrationLog.setOneDirectTicketId(oneDirectTicketId);
        ticketMigrationLog.setStatus(status.getId());
        ticketMigrationLog.setCreatedAt(new Date());
        return ticketMigrationLog;
    }

    @Override
    public TicketFieldValue buildTicketFieldValueFromTicket(Ticket ticket, Integer brandId, Integer labelId,
                                                            TicketFieldValueTypeEnum ticketFieldValueType,
                                                            Long optionId, String value) {
        TicketFieldValue ticketFieldValue = new TicketFieldValue();
        ticketFieldValue.setId(null);
        ticketFieldValue.setBrandId(brandId);
        ticketFieldValue.setTicketId(ticket.getId());
        ticketFieldValue.setTicketLabelId(labelId);
        ticketFieldValue.setOptionId(optionId);

        switch (ticketFieldValueType){
            case TEXT:
                ticketFieldValue.setTicketLabelText(value);
                break;
            case INT:
                try {
                    ticketFieldValue.setTicketLabelInt(Integer.parseInt(value));
                }catch (Exception e){
                    ticketFieldValue.setTicketLabelText(value);
                }
                break;
//            case DECIMAL:
//                ticketFieldValue.setTicketLabelDecimal(BigDecimal.valueOf(Double.parseDouble(value)));
//                break;
//            case LOCATION:
            //TODO : Handle location
            case DATE:
                ticketFieldValue.setTicketLabelDate(DateUtils.convertToDate(value,"yyyy-MM-dd"));
                break;
            case BOOL:
                try {
                    ticketFieldValue.setTicketLabelBool(Byte.valueOf(value));
                }catch (Exception e){
                    ticketFieldValue.setTicketLabelText(value);
                }
                break;
        }

        ticketFieldValue.setStatus((byte)1);
        ticketFieldValue.setCreatedBy(Constants.INT_SYSTEM_USER);
        ticketFieldValue.setCreatedAt(ticket.getCreatedAt());
        ticketFieldValue.setUpdatedAt(new Date());
        ticketFieldValue.setUpdatedBy(Constants.INT_SYSTEM_USER);
        return ticketFieldValue;
    }

    @Override
    public CustomerLabelValue getCustomerLabelValueForCustomerIdAndFieldId(Long customerId, Integer fieldId) {
            return customerLabelValueService.getCustomerLabelValueByCustomerIdAndCustomerLabelId(customerId,fieldId);
    }

    @Override
    public Customer getCustomerById(Long customerId) {
        return customerService.findCustomerById(customerId);
    }
}

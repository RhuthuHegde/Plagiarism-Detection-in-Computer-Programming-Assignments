package com.onedirect.migrationapi.dtos.zendesk.comment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.onedirect.migrationapi.dtos.zendesk.ZendeskAttachment;
import com.onedirect.migrationapi.dtos.zendesk.ZendeskVia;
import lombok.*;

import java.util.List;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskComment {

        @JsonProperty("id")
        private Long id;
        @JsonProperty("type")
        private String type;
        @JsonProperty("author_id")
        private Long authorId;
        @JsonProperty("body")
        private String body;
        @JsonProperty("html_body")
        private String htmlBody;
        @JsonProperty("plain_body")
        private String plainBody;
        @JsonProperty("public")
        private Boolean _public;
        @JsonProperty("attachments")
        private List<ZendeskAttachment> attachments;
        @JsonProperty("audit_id")
        private Long auditId;
//        @JsonProperty("via")
//        private ZendeskVia via;
        @JsonProperty("created_at")
        private String createdAt;
//        @JsonProperty("metadata")
//        private ZendeskCommentMetadata metadata;

}

package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.TicketMigrationLog;

public interface TicketMigrationLogService {
    public TicketMigrationLog createTicketMigrationLog(TicketMigrationLog ticketMigrationLog);
}

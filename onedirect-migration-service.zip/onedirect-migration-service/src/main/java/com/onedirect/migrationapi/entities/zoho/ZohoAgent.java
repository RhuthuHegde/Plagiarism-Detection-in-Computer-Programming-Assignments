package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="zoho_agent")
public class ZohoAgent {
    @Id
    private Long id;
    private String firstName;
    private String lastName;
    private String emailId;
    private String status;
    private Boolean isConfirmed;
    private Date createdTime;
}

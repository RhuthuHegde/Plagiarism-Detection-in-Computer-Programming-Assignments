package com.onedirect.migrationapi.converters.registry;

import com.onedirect.commonutils.utils.GenericUtil;
import com.onedirect.migrationapi.converters.GenericMigrationServiceConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.type.filter.AssignableTypeFilter;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author jp
 */

@Configuration
public class MigrationServiceConverterRegistry implements ApplicationContextAware, BeanFactoryPostProcessor {

    private static final Logger logger = LoggerFactory.getLogger(MigrationServiceConverterRegistry.class);

    private static final Map<String, GenericMigrationServiceConverter> mapConvertersMap = new HashMap<>();
    ApplicationContext context;

    public static Map<String, GenericMigrationServiceConverter> getAllMappersMappings() {
        return mapConvertersMap;
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory configurableListableBeanFactory) throws BeansException {
        logger.info("[Mappers_Init] Mappers initialization started");
        ClassPathScanningCandidateComponentProvider provider = initClassPathScanningProvider(GenericMigrationServiceConverter.class);
        initAllMappers(provider);
        mapConvertersMap.forEach((key, val) -> {
            logger.info("[MappersKeys] {}", key);
        });
        logger.info("[Mappers_Init] Mappers initialization completed successfully");
    }

    private void initAllMappers(ClassPathScanningCandidateComponentProvider provider) {

        Set<BeanDefinition> components = provider.findCandidateComponents("com.onedirect");
        for (BeanDefinition component : components) {
            try {
                Class cls = Class.forName(component.getBeanClassName());
                ParameterizedType parameterizedType = (ParameterizedType) cls.getGenericSuperclass();
                Type[] genericTypes = parameterizedType.getActualTypeArguments();
                if (genericTypes.length == 2) {
                    String srcTypeObject = getSrcOrDestSrcObjectString(genericTypes[0]);
                    String destTypeObject = getSrcOrDestSrcObjectString(genericTypes[1]);
                    if (srcTypeObject != null && destTypeObject != null) {
                        String key = srcTypeObject + "___" + destTypeObject;
                        try {
                            mapConvertersMap.put(key.trim(), (GenericMigrationServiceConverter) cls.newInstance());
                            logger.info("[Mappers_Init] key :{} , value :{}", key, cls.getSimpleName());
                        } catch (InstantiationException e) {
                            e.printStackTrace();
                            logger.error(" [Mappers_Init] Error While Instantiating Object of MapperClass {}, due to:{}",
                                    cls.getSimpleName(), GenericUtil.getStackTraceInStringFmt(e));
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        }
                    } else {
                        logger.error("[Mappers_Init] Not able to map srcObj {} , destType {}", srcTypeObject,
                                destTypeObject);
                    }

                }
            } catch (ClassNotFoundException ex) {
                logger.error("[Mappers_Init] Class not found , {} ", GenericUtil.getStackTraceInStringFmt(ex));
            }

        }
    }

    private String getSrcOrDestSrcObjectString(Type genericType) {
        if (genericType instanceof Class) {
            Class<?> srcTypeObject = (Class) genericType;
            return srcTypeObject.getSimpleName();
        } else if (genericType instanceof ParameterizedType) {
            return MapperRegistryUtil.getTypeName(genericType);
        }
        return null;
    }

    private ClassPathScanningCandidateComponentProvider initClassPathScanningProvider(Class<GenericMigrationServiceConverter> clazz) {
        ClassPathScanningCandidateComponentProvider provider =
                new ClassPathScanningCandidateComponentProvider(false);
        provider.addIncludeFilter(new AssignableTypeFilter(clazz));
        return provider;

    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        context = applicationContext;
    }
}

package com.onedirect.migrationapi.constants;

/**
 * @author jp
 */

public class Constants {

    public static final Integer INT_SYSTEM_USER = 93271;

    public static String FATAL_ERROR_PREFIX = "[FATAL-ERROR]";

    public static String SERVICE_ERROR_PREFIX = "[SERVICE-ERROR]";

    public static final String REDIS_KEY_PREFIX = "MIGRATION_SERVICE_";

    public static final String RMQ_HOST = "spring.rabbitmq.host";

    public static final String RMQ_PORT = "spring.rabbitmq.port";

    public static final String RMQ_PWD = "spring.rabbitmq.password";

    public static final String RMQ_USER = "spring.rabbitmq.username";

    public static final String RMQ_CONN_CACHE_SIZE = "spring.rabbitmq.cache.connection.size";

    public static final String RMQ_CHANNEL_CACHE_SIZE = "spring.rabbitmq.cache.channel.size";

    public static final String RMQ_MIGRATIONS_REQUESTS_QUEUE = "spring.rabbitmq.migration-requests-queue";

    public static final String RMQ_ATTACHMENTS_QUEUE = "spring.rabbitmq.attachments-queue";

    public static final String RMQ_EXCHANGE = "spring.rabbitmq.migration-requests-exchange";

    public static final String BASE_FILE_PATH = "[BUCKET_NAME]/[BRAND_ID]/[FILE_NAME]";

    public static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream";

}

package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.ThirdPartyTicketMapping;

public interface ThirdPartyTicketMappingService {
    public ThirdPartyTicketMapping addThirdPartyTicketMapping(ThirdPartyTicketMapping thirdPartyTicketMapping);
}

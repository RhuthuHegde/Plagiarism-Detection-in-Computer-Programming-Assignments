package com.onedirect.migrationapi.configs;

import com.onedirect.migrationapi.constants.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.RabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * @author jp
 */

@Configuration
public class MigrationRabbitMQConfig{

    @Autowired
    private Environment env;

    private static final Logger logger = LoggerFactory.getLogger(MigrationRabbitMQConfig.class);

    @Bean
    public ConnectionFactory connectionFactory() {
        String hostName = env.getRequiredProperty(Constants.RMQ_HOST);
        logger.debug("Configured RabbitMQ host {}", hostName);
        String password = env.getRequiredProperty(Constants.RMQ_PWD);
        logger.debug("Configured RabbitMQ password {}", password);
        String userName = env.getRequiredProperty(Constants.RMQ_USER);
        logger.debug("Configured RabbitMQ userName {}", userName);
        int connCacheSize = 20;
        int channelCacheSize = 100;
        int port = 5672;
        try {
            connCacheSize = Integer.parseInt(env.getRequiredProperty(Constants.RMQ_CONN_CACHE_SIZE));
        } catch (Exception e) {
            logger.error("Exception reading RMQ Connection Cache size Config {}.  Default to {}", e,
                    connCacheSize);
        }
        logger.debug("Configured RabbitMQ connCacheSize {}", connCacheSize);
        try {
            channelCacheSize = Integer
                    .parseInt(env.getRequiredProperty(Constants.RMQ_CHANNEL_CACHE_SIZE));
        } catch (Exception e) {
            logger.error("Exception reading Channel cache size Config {}. Default to {}", e,
                    channelCacheSize);
        }
        logger.debug("Configured RabbitMQ channelCacheSize {}", channelCacheSize);
        try {
            port = Integer.parseInt(env.getRequiredProperty(Constants.RMQ_PORT));
        } catch (Exception e) {
            logger.error("Exception reading Channel cache size Config {}. Default to {}", e, port);
        }
        logger.debug("Configured RabbitMQ port {}", port);
        CachingConnectionFactory rabbitConnectionFactory = new CachingConnectionFactory(hostName, port);
        rabbitConnectionFactory.setUsername(userName);
        rabbitConnectionFactory.setPassword(password);
        rabbitConnectionFactory.setCacheMode(CachingConnectionFactory.CacheMode.CONNECTION);
        rabbitConnectionFactory.setConnectionCacheSize(connCacheSize);
        rabbitConnectionFactory.setChannelCacheSize(channelCacheSize);
        return rabbitConnectionFactory;
    }

    @Bean
    public AmqpAdmin amqpAdmin() {
        RabbitAdmin admin = new RabbitAdmin(connectionFactory());
        String migrationRequestsQueueName = env.getRequiredProperty(Constants.RMQ_MIGRATIONS_REQUESTS_QUEUE);
        String exchangeName = env.getRequiredProperty(Constants.RMQ_EXCHANGE);
        Queue migrationRequestsQueue = new Queue(migrationRequestsQueueName);
        DirectExchange exchange = new DirectExchange(exchangeName, true, false);
        admin.declareQueue(migrationRequestsQueue);
        admin.declareExchange(exchange);
        admin.declareBinding(BindingBuilder.bind(migrationRequestsQueue).to(exchange).with(migrationRequestsQueueName));

        String attachmentsQueueName = env.getRequiredProperty(Constants.RMQ_ATTACHMENTS_QUEUE);
        Queue attachmentsQueue = new Queue(attachmentsQueueName);
        admin.declareQueue(attachmentsQueue);
        admin.declareBinding(BindingBuilder.bind(attachmentsQueue).to(exchange).with(attachmentsQueueName));
        return admin;
    }

    @Bean
    public RabbitListenerContainerFactory<SimpleMessageListenerContainer> migrationRequestsQueueListenerContainerFactory
            (ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory simpleRabbitListenerContainerFactory = new
                SimpleRabbitListenerContainerFactory();
        simpleRabbitListenerContainerFactory.setPrefetchCount(2);
        simpleRabbitListenerContainerFactory.setConnectionFactory(connectionFactory);
        simpleRabbitListenerContainerFactory.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        simpleRabbitListenerContainerFactory.setConcurrentConsumers(10);
        simpleRabbitListenerContainerFactory.setAutoStartup(true);
        simpleRabbitListenerContainerFactory.setMessageConverter(new Jackson2JsonMessageConverter());
        return simpleRabbitListenerContainerFactory;
    }
    
    @Bean
    public RabbitListenerContainerFactory<SimpleMessageListenerContainer> attachementsQueueListenerContainerFactory
            (ConnectionFactory connectionFactory){
        SimpleRabbitListenerContainerFactory simpleRabbitListenerContainerFactory = new
                SimpleRabbitListenerContainerFactory();
        simpleRabbitListenerContainerFactory.setConnectionFactory(connectionFactory);
        simpleRabbitListenerContainerFactory.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        simpleRabbitListenerContainerFactory.setConcurrentConsumers(10);
        simpleRabbitListenerContainerFactory.setAutoStartup(true);
        simpleRabbitListenerContainerFactory.setPrefetchCount(Integer.MAX_VALUE);
        simpleRabbitListenerContainerFactory.setMessageConverter(new Jackson2JsonMessageConverter());
        return simpleRabbitListenerContainerFactory;
    }

    public Environment getEnvironment() {
        return this.env;

    }

    @Bean
    public RabbitTemplate rabbitTemplate()
    {
        String queueName = getEnvironment().getRequiredProperty(Constants.RMQ_MIGRATIONS_REQUESTS_QUEUE);
        String exchangeName = getEnvironment().getRequiredProperty(Constants.RMQ_EXCHANGE);
        logger.info("MigrationRabbitMQ Queue Name:{} , Exchange Name :{}", queueName, exchangeName);
        RabbitTemplate template = new RabbitTemplate(connectionFactory());
        template.setRoutingKey(queueName);
//        template.setQueue(queueName);
        template.setDefaultReceiveQueue(queueName);
        template.setExchange(exchangeName);
        template.setMessageConverter(jsonMessageConverter());
        return template;
    }

    @Bean
    public RabbitTemplate attachmentsRabbitTemplate()
    {
        String queueName = getEnvironment().getRequiredProperty(Constants.RMQ_ATTACHMENTS_QUEUE);
        String exchangeName = getEnvironment().getRequiredProperty(Constants.RMQ_EXCHANGE);
        logger.info("MigrationRabbitMQ Queue Name:{} , Exchange Name :{}", queueName, exchangeName);
        RabbitTemplate template = new RabbitTemplate(connectionFactory());
        template.setRoutingKey(queueName);
//        template.setQueue(queueName);
        template.setDefaultReceiveQueue(queueName);
        template.setExchange(exchangeName);
        template.setMessageConverter(jsonMessageConverter());
        return template;
    }

    @Bean
    public Queue tasksQueue()
    {
        String queueName = getEnvironment().getRequiredProperty(Constants.RMQ_MIGRATIONS_REQUESTS_QUEUE);
        return new Queue(queueName);
    }

    @Bean
    public MessageConverter jsonMessageConverter(){
        return new Jackson2JsonMessageConverter();
    }
}

package com.onedirect.migrationapi.converters;

import com.onedirect.migrationapi.dtos.BrandConfigurationDto;
import com.onedirect.migrationapi.entities.BrandConfigurationEntity;
import com.onedirect.migrationapi.utils.GenericBuilder;

import java.util.Date;

/**
 * @author jp
 */

public class BrandConfigurationEntityToBrandConfigurationDtoConverter extends GenericMigrationServiceConverter<BrandConfigurationEntity,BrandConfigurationDto>{
    public BrandConfigurationEntityToBrandConfigurationDtoConverter() {
        super(brandConfigurationEntity -> {
            if(brandConfigurationEntity == null){
                return null;
            }
            return GenericBuilder.of(BrandConfigurationDto::new)
                    .with(BrandConfigurationDto::setId, brandConfigurationEntity.getId() == null ? null : brandConfigurationEntity.getId())
                    .with(BrandConfigurationDto::setBrandId, brandConfigurationEntity.getBrandId())
                    .with(BrandConfigurationDto::setBrandSupportName, brandConfigurationEntity.getBrandSupportName())
                    .with(BrandConfigurationDto::setBrandSupportAddress, brandConfigurationEntity.getBrandSupportAddress())
                    .with(BrandConfigurationDto::setPlatformDomain, brandConfigurationEntity.getPlatformDomain())
                    .with(BrandConfigurationDto::setPlatformId, brandConfigurationEntity.getPlatformId())
                    .with(BrandConfigurationDto::setPlatformAuthorizationKey, brandConfigurationEntity.getPlatformAuthorizationKey())
                    .with(BrandConfigurationDto::setRecordStatus, brandConfigurationEntity.getRecordStatus())
                    .with(BrandConfigurationDto::setIsMigrationEnabled, brandConfigurationEntity.getIsMigrationEnabled())
                    .with(BrandConfigurationDto::setCreatedAt, brandConfigurationEntity.getCreatedAt())
                    .with(BrandConfigurationDto::setUpdatedAt, new Date())
                    .with(BrandConfigurationDto::setDefaultAgentId, brandConfigurationEntity.getDefaultAgentId())
                    .build();

        }, null);
    }
}

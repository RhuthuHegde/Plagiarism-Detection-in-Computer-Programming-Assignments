package com.onedirect.migrationapi.entities.zoho.contact;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoCustomerHappiness {
    private Integer goodPercentage;
    private Integer badPercentage;
    private Integer okPercentage;
}

package com.onedirect.migrationapi.enums;

import java.util.HashMap;

/**
 * @author jp
 */
public enum PlatformEnum {
    ZENDESK(1),
    FRESHDESK(2),
    ZOHO(3);

    /**
     * The constant values.
     */
    public static final String values;

    /**
     * The reverse map.
     */
    static HashMap<Integer, PlatformEnum> reverseMap;

    static {
        String sep = "";
        String val = "";
        reverseMap = new HashMap<>();
        for (PlatformEnum platformEnum : PlatformEnum.values()) {
            reverseMap.put(platformEnum.getId(), platformEnum);
            val += sep + platformEnum.id;
            sep = ",";
        }
        values = "(" + val + ")";
    }

    private int id;

    PlatformEnum(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }


    public static PlatformEnum getEnumById(Integer id) {
        if(id == null) {
            return null;
        }
        return reverseMap.get(id);
    }

    public static boolean isValidId(Integer id) {
        if(id == null) {
            return true;
        }
        return reverseMap.containsKey(id.byteValue());
    }
}

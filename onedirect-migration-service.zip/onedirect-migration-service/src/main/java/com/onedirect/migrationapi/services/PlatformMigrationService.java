package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.bos.ConversationListBo;
import com.onedirect.migrationapi.bos.CustomFieldBo;
import com.onedirect.migrationapi.bos.CustomerBo;
import com.onedirect.migrationapi.bos.TicketListBo;
import com.onedirect.migrationapi.configs.MigrationRabbitMQConfig;
import com.onedirect.migrationapi.dtos.*;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicket;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.TicketFieldValueTypeEnum;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.pojos.BrandFieldConfiguration;
import com.onedirect.migrationapi.pojos.BrandTicketFieldConfiguration;
import com.onedirect.migrationapi.pojos.TicketMigrationStats;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

/**
 * @author Hrishikesh
 */

public abstract class PlatformMigrationService {
    @Autowired
    MigrationRabbitMQConfig rabbitMQConfig;

    @Autowired
    MigrationDataService migrationDataService;

    public void performPreMigration(BrandConfigurationDto brandConfigurationDto,MigrationLog migrationLog,
                                    BrandFieldConfiguration brandFieldConfiguration){
    }

    public abstract TicketListBo getTickets(BrandConfigurationDto brandConfigurationDto,
                                   MigrationLog migrationLog, Map<String,Object> params);

    public Boolean shouldMigrationContinue(TicketListBo ticketListBo,TicketMigrationStats ticketMigrationStats,
                                           MigrationLog migrationLog,BrandConfigurationDto brandConfigurationDto){
        return Boolean.TRUE;
    }

    public abstract void validateMigrationRequest(MigrationRequestDto migrationRequestDto,
                                                  BrandConfigurationEntity brandConfigurationEntity,
                                                  BrandFieldConfiguration brandFieldConfiguration
                                                  )
            throws ResponseStatusException;

    public Boolean doesTicketAlreadyExist(Integer brandId, Long valueToSearch, BrandFieldConfiguration brandFieldConfiguration){
        if (Objects.nonNull(brandFieldConfiguration) && Objects.nonNull(brandFieldConfiguration.getPlatformTicketIdTicketFieldId())
        ) {
            Integer ticketFieldId = brandFieldConfiguration.getPlatformTicketIdTicketFieldId().intValue();
            List<TicketFieldValue> ticketFieldValues = migrationDataService.getTicketFieldValueForGivenValue(brandId,
                    valueToSearch.toString(),ticketFieldId);
            return Objects.nonNull(ticketFieldValues) && ticketFieldValues.size()!=0;
        }else{
            return false;
        }
//        return false;
    }

    public Boolean shouldTicketBeMigrated(Object ticket, TicketMigrationStats ticketMigrationStats,
                                          BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog,
                                          BrandFieldConfiguration brandFieldConfiguration
                                          ){
        return true;
    }
    public abstract ConversationListBo getConversationsForTicket(Object ticket,
                                                                 BrandConfigurationDto brandConfigurationDto);

    public abstract void createTicketFailureMigrationLog(Integer brandId,Integer migrationLogId,Object platformTicket, Exception e);

    public abstract PlatformCustomerMappingEntity getPlatformCustomerMapping(Object platformTicket,
                                                                             BrandConfigurationDto brandConfigurationDto);

    public abstract CustomerBo getCustomerForTicket(Object platformTicket,BrandConfigurationDto brandConfigurationDto);

    public abstract Customer createCustomerFromPlatformCustomer(CustomerBo platformCustomer, BrandConfigurationDto brandConfigurationDto);

    public abstract List<CustomerLabelValue> createCustomerLabelValue(Customer customer, CustomerBo platformCustomer,
                                                  BrandConfigurationDto brandConfigurationDto,
                                                  BrandFieldConfiguration brandFieldConfiguration);

    public abstract Long getBrandUserId(Object platformTicket, BrandConfigurationDto brandConfigurationDto);
    

    public List<TicketTag> createTicketTagsForPlatformTicket(Object platformTicket, Ticket ticket,
                                                                      Integer brandId,
                                                                      BrandFieldConfiguration brandFieldConfiguration){
        return createPresetTicketTags(ticket,brandId,brandFieldConfiguration);
    }
    public abstract QueuedAttachmentsDto createQueuedAttachmentDto(Object platformConversation,
                                                   Ticket ticket,
                                                   ThirdPartyData thirdPartyData,
                                                   BrandConfigurationDto brandConfigurationDto,
                                                   ForwardFeed forwardFeed
    );


    public abstract List<ForwardFeedAttachmentDto> uploadAttachmentsForForwardFeed(String attachmentListJson, Integer brandId);

    public abstract ForwardFeed createForwardFeed(Ticket ticket, Object platformConversation, Object platformTicket);

    public abstract ForwardCustomerInfoValueJsonDto createForwardCustomerInfoValueDto(Object platformTicket,
                                                                                      Object platformConversation,
                                                                                      BrandConfigurationDto brandConfigurationDto,
                                                                                      Long customerId,
                                                                                      BrandFieldConfiguration brandFieldConfiguration
                                                                                      );

    public abstract void createTicketSuccessMigrationLog(Integer id, Ticket ticket, Object platformTicket);


    public abstract Ticket createTicketFromPlatformTicket(Object platformTicket, Integer brandId, Long oneDirectCustomerId, Integer brandUserId, Long latestBrandTicketId);

    public abstract Map<String, String> uploadAttachmentsForThirdPartyData(String attachmentListJson, Integer brandId);

    public abstract PlatformCustomerMappingEntity createPlatformCustomerMapping(Object platformCustomer,
                                                                                      BrandConfigurationDto brandConfigurationDto,
                                                                                      Customer customer
                                                                                      );

    protected Long getBrandUserId(Long assigneeId,Long defaultAgentId,Integer brandConfigurationId) {
        PlatformAgentMapping platformAgentMapping = null;
        if(Objects.nonNull(assigneeId)){
            platformAgentMapping = migrationDataService.getPlatformAgentMapping(assigneeId,brandConfigurationId);
        }
        return Objects.isNull(platformAgentMapping) ? defaultAgentId : platformAgentMapping.getBrandUserId();
    }

    protected PlatformCustomerMappingEntity getPlatformCustomerMapping(Long requesterId,Integer brandConfigurationId){
        return migrationDataService.getPlatformCustomerMapping(requesterId,brandConfigurationId);
    }

    protected PlatformCustomerMappingEntity createPlatformCustomerMapping(Long zendeskCustomerId,Long customerId,Integer brandConfigurationId){
        return migrationDataService.createPlatformCustomerMapping(zendeskCustomerId,customerId,brandConfigurationId);
    }

    public abstract TicketFieldValue getPlatformTicketIdTicketField(Ticket ticket, Integer brandId, Object platformTicket,
                                                                    BrandFieldConfiguration brandFieldConfiguration);

    protected TicketFieldValue getPlatformTicketIdTicketField(Long fieldId,Ticket ticket,Integer brandId,Long platformTicketId){
        if(Objects.nonNull(fieldId)){
            return migrationDataService.buildTicketFieldValueFromTicket(ticket,brandId,
                    fieldId.intValue(), TicketFieldValueTypeEnum.TEXT,null,
                    platformTicketId.toString());
        }
        return null;
    }

    public abstract List<CustomFieldBo> getCustomFieldBoList(Object platformTicket);

    protected List<CustomerLabelValue> createCustomerLabelValues(BrandFieldConfiguration brandFieldConfiguration,
                                                                 BrandConfigurationDto brandConfigurationDto,
                                                                 Customer customer,String email,String phone
                                                                 ){
        List<CustomerLabelValue> customerLabelValueList = new ArrayList<>();
        if(Objects.nonNull(brandFieldConfiguration) && Objects.nonNull(brandFieldConfiguration.getEmailCustomerFieldId())){
            customerLabelValueList.add(createCustomerLabelValue(brandFieldConfiguration.getEmailCustomerFieldId(),brandConfigurationDto.getBrandId(),
                    customer.getId(),customer.getCreatedAt(), email));
        }
        if(Objects.nonNull(brandFieldConfiguration) && Objects.nonNull(brandFieldConfiguration.getPhoneCustomerFieldId())){
            customerLabelValueList.add(createCustomerLabelValue(brandFieldConfiguration.getPhoneCustomerFieldId(),brandConfigurationDto.getBrandId(),
                    customer.getId(),customer.getCreatedAt(), phone));
        }
        return customerLabelValueList;
    }

    protected CustomerLabelValue createCustomerLabelValue(Long fieldId,Integer brandId,Long customerId,Date createdAt,String value){
        return migrationDataService.addCustomerLabelValue(migrationDataService.buildCustomerLabelValue(customerId, value,
                brandId.longValue(),
                createdAt,
                fieldId));
    }

    protected List<TicketTag> createPresetTicketTags(Ticket ticket, Integer brandId, BrandFieldConfiguration brandFieldConfiguration) {
        List<TicketTag> ticketTagList = new ArrayList<>();
        if (Objects.nonNull(brandFieldConfiguration.getPresetTags())) {
        for (Long tti : brandFieldConfiguration.getPresetTags()) {
            Integer ticketTagId = tti.intValue();
            ticketTagList.add(migrationDataService.buildTicketTagFromTicketId(ticket, brandId, ticketTagId));
        }
        }
        return ticketTagList;
    }

    protected  ForwardCustomerInfoValueJsonDto generateValueJsonForForwardCustomerInfoDto(Boolean isPrivate,
                                                                                          Boolean isReplyFromBrand,
                                                                                          String userName,String userEmail,
                                                                                          BrandConfigurationDto brandConfigurationDto){
        ForwardCustomerInfoValueJsonDto forwardCustomerInfoValueJsonDto = new ForwardCustomerInfoValueJsonDto();
        List<NameAddressPairDto> nameAddressPairDtoList = new ArrayList<>();
        NameAddressPairDto toNameAddressPairDto;
        NameAddressPairDto fromNameAddressPairDro;
        if(isPrivate){
            NameAddressPairDto nameAddressPairDto = createNameAddressPairDto(brandConfigurationDto.getBrandSupportName(), brandConfigurationDto.getBrandSupportAddress());
            nameAddressPairDtoList.add(nameAddressPairDto);
            forwardCustomerInfoValueJsonDto.setFrom(nameAddressPairDto);
            forwardCustomerInfoValueJsonDto.setTo(nameAddressPairDtoList);
        }
        else{
            if(isReplyFromBrand){
                toNameAddressPairDto = createNameAddressPairDto(userName,userEmail);
                fromNameAddressPairDro = createNameAddressPairDto(brandConfigurationDto.getBrandSupportName(),
                        brandConfigurationDto.getBrandSupportAddress());
            }else{
                fromNameAddressPairDro = createNameAddressPairDto(userName,userEmail);
                toNameAddressPairDto = createNameAddressPairDto(brandConfigurationDto.getBrandSupportName(),
                        brandConfigurationDto.getBrandSupportAddress());
            }
            nameAddressPairDtoList.add(toNameAddressPairDto);
            forwardCustomerInfoValueJsonDto.setFrom(fromNameAddressPairDro);
            forwardCustomerInfoValueJsonDto.setTo(nameAddressPairDtoList);
        }
        return forwardCustomerInfoValueJsonDto;
    }

    private NameAddressPairDto createNameAddressPairDto(String name, String email) {
        NameAddressPairDto nameAddressPairDto = new NameAddressPairDto();
        nameAddressPairDto.setName(name);
        nameAddressPairDto.setAddress(email);
        return nameAddressPairDto;
    }
    protected CustomerLabelValue getCustomerLabelValueForCustomerIdAndFieldId(Long customerId, Integer fieldId) {
        return migrationDataService.getCustomerLabelValueForCustomerIdAndFieldId(customerId,fieldId);
    }
    protected ThirdPartyData createThirdPartyData(Ticket ticket,String description){
        return migrationDataService.addThirdPartyData(ticket,description);
    }

    public abstract ThirdPartyData createThirdPartyDataForTicket(Ticket ticket, Object platformConversations);
}

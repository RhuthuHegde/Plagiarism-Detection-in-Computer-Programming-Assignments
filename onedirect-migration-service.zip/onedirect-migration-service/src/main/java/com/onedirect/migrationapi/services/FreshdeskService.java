package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.ForwardFeedAttachmentDto;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskAttachment;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskTicketsDto;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskUserDto;
import com.onedirect.migrationapi.dtos.freshdesk.conversation.HelpdeskNote;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.HelpdeskTicket;
import com.onedirect.migrationapi.dtos.freshdesk.user.FreshdeskUser;
import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.entities.Ticket;

import java.io.File;
import java.util.List;
import java.util.Map;

public interface FreshdeskService {
    FreshdeskTicketsDto getFreshDeskTicketsDtoFromFile(Integer brandId, String fileName);

    String createDataPath(String baseFilePath, Integer brandId, String fileNumber, String data);

    Boolean doTicketsExistForBrand(Integer brandId);

    HelpdeskNote createFirstHelpdeskNoteFromTicket(HelpdeskTicket helpdeskTicket);

    FreshdeskUserDto getFreshdeskUserDtoFromFile(File file);

    List<Customer> buildCustomersFromFreshdeskUserDto(FreshdeskUserDto freshdeskUserDto, Integer brandId);

    Ticket buildTicketFromHelpdeskTicket(HelpdeskTicket helpdeskTicket,
                                         Integer brandId, Long customerId, Integer brandUserId,
                                         Long brandTicketId);

    ForwardFeed generateForwardFeedEntity(Ticket ticket, HelpdeskNote helpdeskNote, HelpdeskTicket helpdeskTicket);

    List<FreshdeskAttachment> getFreshdeskAttachmentsFromJson(String attachmentListJson);

    Map<String, String> uploadAttachments(List<FreshdeskAttachment> freshdeskAttachmentList, Integer brandId);

    List<ForwardFeedAttachmentDto> createForwardFeedAttachmentDtoList(List<FreshdeskAttachment> freshdeskAttachmentList, Integer brandId);
}

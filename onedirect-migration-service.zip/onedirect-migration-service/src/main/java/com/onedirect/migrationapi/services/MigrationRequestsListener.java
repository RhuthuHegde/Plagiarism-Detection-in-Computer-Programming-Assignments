package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.MigrationRequestDto;
import com.rabbitmq.client.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author jp
 */

@Component
public class MigrationRequestsListener {

    @Autowired
    private MigrationService migrationService;

    private static final Logger logger = LoggerFactory.getLogger(MigrationRequestsListener.class);

    @RabbitListener(queues = {"${spring.rabbitmq.migration-requests-queue}"}, containerFactory =
            "migrationRequestsQueueListenerContainerFactory")
    public void receiveMigrationRequestsAndStartProcessing(Channel channel,
                                                           MigrationRequestDto migrationRequestDto,
                                                           @Header(AmqpHeaders.DELIVERY_TAG) long tag) throws IOException {
        logger.info("Received Message:: {}", migrationRequestDto.toString());
        channel.basicAck(tag, true);
        migrationService.processMigrationRequest(migrationRequestDto);
    }
}

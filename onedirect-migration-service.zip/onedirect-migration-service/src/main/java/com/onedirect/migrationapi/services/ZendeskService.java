package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.dtos.*;
import com.onedirect.migrationapi.dtos.zendesk.ZendeskAttachment;
import com.onedirect.migrationapi.dtos.zendesk.branduser.ZendeskUser;
import com.onedirect.migrationapi.dtos.zendesk.branduser.ZendeskUserDto;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskComment;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskCommentsDto;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicket;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicketResponseDto;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.TicketMigrationEnum;
import com.onedirect.migrationapi.pojos.BrandFieldConfiguration;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author Hrishikesh
 */

public interface ZendeskService {
    public ZendeskTicketResponseDto fetchTicketsIncrementally(BrandConfigurationDto brandConfigurationEntity,
                                                              Long startTimestamp);

    public ZendeskTicketResponseDto fetchTicketsIncrementally(BrandConfigurationDto brandConfigurationEntity,String url);

    public ZendeskCommentsDto fetchCommentsByZendeskTicketId(Long ticketId, BrandConfigurationDto brandConfigurationEntity);

    public ZendeskUserDto fetchZendeskUserInfo(Long conversationId, BrandConfigurationDto brandConfigurationEntity);

    Boolean isBrandCredentialsValid(MigrationRequestDto migrationRequestDto,BrandConfigurationEntity brandConfigurationEntity);

    public Customer addCustomer(ZendeskUser zendeskUser, BrandConfigurationDto brandConfigurationDto);

    public Ticket createOneDirectTicket(ZendeskTicket ticket,Integer brandId,Long customerId,Integer brandUserId, Long brandTicketId);

    public Map<String,String> uploadAttachments(List<ZendeskAttachment> zendeskAttachmentList, Integer brandId);

    ForwardFeed createOnedirectForwardFeed(Ticket ticket, ZendeskComment zendeskComment, ZendeskTicket zendeskTicket);

    List<ForwardFeedAttachmentDto> createForwardFeedAttachmentDtoList(List<ZendeskAttachment> zendeskAttachmentList, Integer brandId);

    List<ZendeskAttachment> getZendeskAttachmentsFromJson(String s);
}

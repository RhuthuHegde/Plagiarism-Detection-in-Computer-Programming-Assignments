package com.onedirect.migrationapi.entities.zoho;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomFields {

    Map<String, String> customFields = new LinkedHashMap<>();

    @JsonAnyGetter
    public Map<String, String> getCustomFields() {
        return customFields;
    }

    @JsonAnySetter
    public void addCustomFields(String key,String value) {
        customFields.put(key, value);
    }
}
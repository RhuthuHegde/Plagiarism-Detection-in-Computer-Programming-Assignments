package com.onedirect.migrationapi.constants;


public class DataConfigConstant {

  public static final String HIBERNATE_DIALCET = "hibernate.dialect";
  public static final String HIBERNATE_SHOW_SQL = "hibernate.show_sql";
  public static final String HIBERNATE_FORMAT_SQL = "hibernate.format_sql";
  public static final String HIBERNATE_AUTO = "hibernate.hbm2ddl.auto";
  public static final String HIBERNATE_QUERYPLAN_CACHESIZE = "hibernate.query.plan_cache_max_size";

  public static final String ONEDIRECT_MASTER_REPO_PACKAGE = "com.onedirect.migrationapi.repos.onedirect.master";
  public static final String ONEDIRECT_MASTER_REPO_PROCESS_NAME = "migrationOnedirectMaster";
  public static final String ONEDIRECT_MASTER_DATA_SOURCE = "db.master.spring.datasource";

  public static final String EMAIL_MASTER_REPO_PACKAGE = "com.onedirect.migrationapi.repos.email.master";
  public static final String EMAIL_MASTER_REPO_PROCESS_NAME = "migrationEmailMaster";
  public static final String EMAIL_MASTER_DATA_SOURCE = "db.email.master.spring.datasource";

  public static final String CUSTOMER_MASTER_REPO_PACKAGE = "com.onedirect.migrationapi.repos.customer.master";
  public static final String CUSTOMER_MASTER_REPO_PROCESS_NAME = "migrationCustomerMaster";
  public static final String CUSTOMER_MASTER_DATA_SOURCE = "db.customer.master.spring.datasource";

  public static final String MIGRATION_MASTER_REPO_PACKAGE = "com.onedirect.migrationapi.repos.migration.master";
  public static final String MIGRATION_MASTER_REPO_PROCESS_NAME = "migrationMigrationMaster";
  public static final String MIGRATION_MASTER_DATA_SOURCE = "db.migration.master.spring.datasource";

  public static final String ONEDIRECT_SLAVE_TRANS_MANAGER = "oneDirectSlaveTransactionManager";
  public static final String ONEDIRECT_SLAVE_REPO_PACKAGE = "com.onedirect.migrationapi.repos.onedirect.slave";
  public static final String ONEDIRECT_SLAVE_DATA_SOURCE = "db.onedirect.slave.spring.datasource";
  public static final String ONEDIRECT_SLAVE_REPO_PROCESS_NAME = "migrationOnedirectSlave";

  public static final String EMAIL_SLAVE_TRANS_MANAGER = "emailSlaveTransactionManager";
  public static final String EMAIL_SLAVE_REPO_PACKAGE = "com.onedirect.migrationapi.repos.email.slave";
  public static final String EMAIL_SLAVE_DATA_SOURCE = "db.email.slave.spring.datasource";
  public static final String EMAIL_SLAVE_REPO_PROCESS_NAME = "migrationEmailSlave";

  public static final String CUSTOMER_SLAVE_TRANS_MANAGER = "customerSlaveTransactionManager";
  public static final String CUSTOMER_SLAVE_REPO_PACKAGE = "com.onedirect.migrationapi.repos.customer.slave";
  public static final String CUSTOMER_SLAVE_DATA_SOURCE = "db.customer.slave.spring.datasource";
  public static final String CUSTOMER_SLAVE_REPO_PROCESS_NAME = "migrationCustomerSlave";

  public static final String MIGRATION_SLAVE_TRANS_MANAGER = "migrationSlaveTransactionManager";
  public static final String MIGRATION_SLAVE_REPO_PACKAGE = "com.onedirect.migrationapi.repos.migration.slave";
  public static final String MIGRATION_SLAVE_DATA_SOURCE = "db.migration.slave.spring.datasource";
  public static final String MIGRATION_SLAVE_REPO_PROCESS_NAME = "migrationMigrationSlave";

  public static final String ENTITY_PACKAGE = "com.onedirect.migrationapi.entities";
}

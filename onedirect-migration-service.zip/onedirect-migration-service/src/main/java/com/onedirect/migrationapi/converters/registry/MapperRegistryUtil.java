package com.onedirect.migrationapi.converters.registry;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

/**
 * @author jp
 */

public class MapperRegistryUtil {

    public static String getTypeName(Type genericType) {
        if (genericType instanceof ParameterizedType) {
            String packageName = ((ParameterizedType) genericType).getActualTypeArguments()[0].getTypeName();
            String[] tests = packageName.trim().split("\\.");
            String typeString = ((ParameterizedType) genericType).getRawType().getTypeName()
                    + "<" + tests[tests.length - 1] + ">";
            return typeString;
        }
        return null;
    }
}

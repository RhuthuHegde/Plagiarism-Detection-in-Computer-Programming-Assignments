package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.ThirdPartyData;

public interface ThirdPartyDataService {
    public ThirdPartyData addThirdPartyData(ThirdPartyData thirdPartyData);
}

package com.onedirect.migrationapi.bos;

import com.onedirect.migrationapi.configs.GcpStorageConfiguration;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.core.type.filter.AnnotationTypeFilter;

/**
 * @author jp
 */

public class StorageBootstrapCondition implements Condition {

        public StorageBootstrapCondition() {
        }

        public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
            AnnotationScanner gcpScanner = new AnnotationScanner(new AnnotationTypeFilter(GcpStorageConfiguration.class));
//        boolean isGcpConfig = gcpScanner.find().size() > 0;
//        if (isGcpConfig) {
//            return true;
//        }
            return true;
        }

}

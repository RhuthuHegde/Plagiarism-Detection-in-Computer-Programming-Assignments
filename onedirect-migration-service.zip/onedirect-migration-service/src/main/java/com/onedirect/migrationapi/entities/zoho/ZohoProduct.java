package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="zoho_product")
public class ZohoProduct {
    @Id
    private Long id;
    private Long ownerId;
    private String productName;
    private String productCode;
    private String manufacturer;
    private String productCategory;
    private Long createdBy;
    private Long modifiedBy;
    private Date createdTime;
    private Date modifiedTime;
    private Double unitPrice;
    private String description;
    private Long layoutId;
}

package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoCustomFields {
    private String key;
    private String value;
}

package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.Ticket;
import com.onedirect.migrationapi.repos.onedirect.master.TicketRepo;
import com.onedirect.migrationapi.services.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketServiceImpl implements TicketService {

    @Autowired
    TicketRepo ticketRepo;

    @Override
    public Ticket addTicket(Ticket ticket) {
        return ticketRepo.save(ticket);
    }
}

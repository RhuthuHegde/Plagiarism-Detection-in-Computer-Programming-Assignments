package com.onedirect.migrationapi.validators;

import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import org.apache.commons.lang3.StringUtils;

public class CustomerValidator {

    private static CustomerValidator customerValidator = null;

    private CustomerValidator(){
    }

    public static CustomerValidator getInstance(){
        if(customerValidator==null){
            return new CustomerValidator();
        }
        return customerValidator;
    }

    public void validateCustomer(Customer customer) throws CustomInternalServerException {
        if (StringUtils.isBlank(customer.getName())) {
            throw new CustomInternalServerException(ErrorCodes.INVALID_CUSTOMER_NAME.getMessage());
        }
    }
}

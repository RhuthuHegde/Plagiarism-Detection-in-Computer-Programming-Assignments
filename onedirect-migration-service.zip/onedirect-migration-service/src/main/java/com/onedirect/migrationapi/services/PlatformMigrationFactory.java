package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.enums.PlatformEnum;
import com.onedirect.migrationapi.services.impl.FreshdeskMigrationService;
import com.onedirect.migrationapi.services.impl.ZendeskMigrationService;
import com.onedirect.migrationapi.services.impl.ZohoMigrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlatformMigrationFactory {
    @Autowired
    ZendeskMigrationService zendeskMigrationService;

    @Autowired
    FreshdeskMigrationService freshdeskMigrationService;

    @Autowired
    ZohoMigrationService zohoMigrationService;

    public PlatformMigrationService getPlatformMigrationService(Integer platformId){
        PlatformEnum platformEnum = PlatformEnum.getEnumById(platformId);
        switch (platformEnum){
            case ZENDESK:
                return zendeskMigrationService;
            case FRESHDESK:
                return freshdeskMigrationService;
            case ZOHO:
                return zohoMigrationService;
            default:
                return null;
        }
    }
}

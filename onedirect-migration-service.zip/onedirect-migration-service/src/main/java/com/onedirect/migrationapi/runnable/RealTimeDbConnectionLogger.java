package com.onedirect.migrationapi.runnable;

import com.onedirect.migrationapi.constants.BeanConstant;
import com.onedirect.migrationapi.controllers.MigrationController;
import com.zaxxer.hikari.pool.HikariPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.DirectFieldAccessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@Service
public class RealTimeDbConnectionLogger implements Runnable {

    @Autowired
    @Qualifier(value = BeanConstant.ONEDIRECT_SLAVE_DATA_SOURCE)
    DataSource oneDirectSlaveDataSource;

    @Autowired
    @Qualifier(value = BeanConstant.ONEDIRECT_MASTER_DATA_SOURCE)
    DataSource oneDirectMasterDataSource;

    @Autowired
    @Qualifier(value = BeanConstant.CUSTOMER_MASTER_DATA_SOURCE)
    DataSource customerMasterDataSource;

    @Autowired
    @Qualifier(value = BeanConstant.CUSTOMER_SLAVE_DATA_SOURCE)
    DataSource customerSlaveDataSource;

    @Autowired
    @Qualifier(value = BeanConstant.EMAIL_MASTER_DATA_SOURCE)
    DataSource emailMasterDataSource;

    @Autowired
    @Qualifier(value = BeanConstant.EMAIL_SLAVE_DATA_SOURCE)
    DataSource emailSlaveDataSource;

    @Autowired
    @Qualifier(value = BeanConstant.MIGRATION_MASTER_DATA_SOURCE)
    DataSource migrationMasterDataSource;

    @Autowired
    @Qualifier(value = BeanConstant.MIGRATION_SLAVE_DATA_SOURCE)
    DataSource migrationSlaveDataSource;

    private String hostname = null;

    private static final Logger logger = LoggerFactory.getLogger(MigrationController.class);

    private void setHostName(){
        try {
            hostname = new BufferedReader(
                    new InputStreamReader(Runtime.getRuntime().exec("hostname").getInputStream()))
                    .readLine();
        } catch (IOException e) {
            logger.info("Unable to determine hostname|"+e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        setHostName();
        while (true) {
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(hostname);
            if (oneDirectMasterDataSource != null) {
                createMasterLog(oneDirectMasterDataSource,stringBuffer," | ONEDIRECT MASTER DATASOURCE[");
            }
            if (oneDirectSlaveDataSource != null) {
                createSlaveLog(oneDirectSlaveDataSource, stringBuffer," | ONEDIRECT SLAVE DATASOURCE[");
            }
            if(emailMasterDataSource!=null){
                createMasterLog(emailMasterDataSource,stringBuffer," | EMAIL MASTER DATASOURCE[");
            }
            if(emailSlaveDataSource!=null){
                createSlaveLog(emailSlaveDataSource, stringBuffer," | EMAIL SLAVE DATASOURCE[");
            }
            if(customerMasterDataSource!=null){
                createMasterLog(customerMasterDataSource,stringBuffer," | CUSTOMER MASTER DATASOURCE[");
            }
            if(customerSlaveDataSource!=null){
                createSlaveLog(customerSlaveDataSource, stringBuffer," | CUSTOMER SLAVE DATASOURCE[");
            }
            if(migrationMasterDataSource!=null){
                createMasterLog(migrationMasterDataSource,stringBuffer," | MIGRATION MASTER DATASOURCE[");
            }
            if(migrationSlaveDataSource!=null){
                createSlaveLog(migrationSlaveDataSource, stringBuffer," | MIGRATION SLAVE DATASOURCE[");
            }
            try {
                logger.info(stringBuffer.toString());
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


private void createMasterLog(DataSource dataSource,StringBuffer stringBuffer,String message){
    HikariPool hikariPoolMaster = (HikariPool) new DirectFieldAccessor(dataSource).getPropertyValue("pool");
    stringBuffer.append(message+dataSource+"],Active Connection="+hikariPoolMaster.getActiveConnections()+",IdleConnection="+hikariPoolMaster.getIdleConnections());
}

private void createSlaveLog(DataSource dataSource,StringBuffer stringBuffer,String message){
    logger.info("SLAVE DATASOURCE CONNECTION POOL = " + dataSource);
    HikariPool hikariPoolSlave = (HikariPool) new DirectFieldAccessor(dataSource).getPropertyValue("pool");
    stringBuffer.append(message+dataSource+"],Active Connection="+hikariPoolSlave.getActiveConnections()+",IdleConnection="+hikariPoolSlave.getIdleConnections());
}
}
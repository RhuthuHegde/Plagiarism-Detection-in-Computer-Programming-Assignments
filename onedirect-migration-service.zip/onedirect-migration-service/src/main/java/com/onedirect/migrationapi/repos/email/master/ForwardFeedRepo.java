package com.onedirect.migrationapi.repos.email.master;

import com.onedirect.migrationapi.entities.ForwardFeed;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Date;

@Repository
public interface ForwardFeedRepo extends JpaRepository<ForwardFeed, Long> {

    @Transactional
    @Modifying
    @Query("update ForwardFeed feed set feed.sentiment=:sentiment where feed.id=:dataId and feed.brandId=:brandId and feed.status=1")
    public void updateSentiment(@Param("brandId") Integer brandId, @Param("dataId") Long dataId, @Param("sentiment") Byte sentiment);

    @Transactional
    @Modifying
    @Query("update ForwardFeed feed set feed.ticketId=:ticketId where feed.id=:dataId and feed.brandId=:brandId and feed.status=1")
    public int updateTicketId(@Param("ticketId") Long ticketId, @Param("dataId") Long dataId, @Param("brandId") Integer brandId);

    @Transactional
    @Modifying
    @Query(value = "update ForwardFeed ed " +
            "set ed.messageId=:messageId, " +
            "ed.hashMessageId=:hashMessageId " +
            "where ed.id=:id and " +
            "ed.brandId=:brandId and " +
            "ed.status=1")
    void updateMessageIdAndHashMessageId(@Param("id") Long id, @Param("brandId") Integer brandId,
                                         @Param("messageId") String messageId, @Param("hashMessageId") String hashMessageId);

    @Transactional
    @Modifying
    @Query(value = "update ForwardFeed ed set ed.messageState=:msgState where ed.id=:id and ed.brandId=:brandId and ed.status=1")
    void updateMessageState(@Param("id") Long id, @Param("brandId") Integer brandId, @Param("msgState") Byte msgState);

    @Query(value = "select ed from ForwardFeed ed where ed.id=:dataId and ed.brandId=:brandId and ed.status=1")
    public ForwardFeed findByBrandIdAndId(@Param("brandId") Integer brandId, @Param("dataId") Long dataId);

    @Query(value = "select ed.id from ForwardFeed ed where" +
            " ed.brandId=:brandId and" +
            " ed.parentId=:parentId and" +
            " ed.messageState=:messageState and" +
            " ed.status=1")
    public Long findByBrandIdAndParentIdAndMessageState(@Param("brandId") Integer brandId, @Param("parentId") Long parentId, @Param
            ("messageState") Byte
            messageState);

    @Transactional
    @Modifying
    @Query(value = "update ForwardFeed ed set " +
            "ed.brandUserId=:brandUserId, " +
            "ed.subject=:subject, " +
            "ed.hashSubject=:hashSubject, " +
            "ed.resourceText=:resourceText, " +
            "ed.resourcePublishDate=:resourcePublishDate, " +
            "ed.parsedResourceText=:parsedText where " +
            "ed.id=:id and " +
            "ed.brandId=:brandId and " +
            "ed.status=1")
    void updateByIdAndBrandId(@Param("brandUserId") Long brandUserId, @Param("subject") String subject,
                              @Param("hashSubject") String hashSubject, @Param("resourceText") String resourceText,
                              @Param("resourcePublishDate") Date resourcePublishDate,
                              @Param("parsedText") String parsedText, @Param("id") Long id,
                              @Param("brandId") Integer brandId);


    @Transactional
    @Modifying
    @Query("update ForwardFeed ed set ed.resourceText=:resourceText where ed.id=:id and ed.brandId=:brandId and ed.status=1 and ed.ticketId=:ticketId")
    void updateResourceText(@Param("resourceText") String resourceText,
                            @Param("id") Long id,
                            @Param("brandId") Integer brandId,
                            @Param("ticketId") Long ticketId);
}
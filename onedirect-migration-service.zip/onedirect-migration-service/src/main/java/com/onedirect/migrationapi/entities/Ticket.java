package com.onedirect.migrationapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "ticket")
@DynamicUpdate
public class Ticket implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "brand_id")
    private Integer brandId;

    @Column(name = "brand_ticket_id")
    private Long brandTicketId;

    @Column(name = "source")
    private Byte source;

    @Column(name = "sub_source")
    private Byte subSource;

    @Column(name = "subject")
    private String subject;

    @Column(name = "short_desc")
    private String shortDesc;

    @Column(name = "current_status")
    private Byte currentStatus;

    @Column(name = "current_priority")
    private Byte currentPriority;

    @Column(name = "ticket_url")
    private String ticketUrl;

    @Column(name = "team_id")
    private Integer teamId;

    @Column(name = "first_assignment_date")
    private Date firstAssignmentDate;

    @Column(name = "current_assignment_date")
    private Date currentAssignmentDate;

    @Column(name = "currently_assigned_to")
    private Integer currentlyAssignedTo;

    @Column(name = "resource_publish_date")
    private Date resourcePublishDate;

    @Column(name = "first_brand_response_date")
    private Date firstBrandResponseDate;

    @Column(name = "latest_brand_response_date")
    private Date latestBrandResponseDate;

    @Column(name = "latest_customer_response_date")
    private Date latestCustomerResponseDate;

    @Column(name = "due_date")
    private Date dueDate;

    @Column(name = "current_sentiment")
    private Byte currentSentiment;

    @Column(name = "sla_breach_status")
    private Byte slaBreachStatus;

    @Column(name = "ref_ticket_id")
    private Long refTicketId;

    @Column(name = "split_parent_id")
    private Long splitParentId;

    @Column(name = "account_id")
    private Integer accountId;

    @Column(name = "parent_ticket_id")
    private Long parentTicketId;

    @Column(name = "requester_id")
    private Integer requesterId;

    @Column(name = "ticket_type")
    private Byte ticketType;

    @Column(name = "is_actionable")
    private Byte isActionable;

    @Column(name = "last_conversation_date")
    private Date lastConversationDate;

    @Column(name = "status")
    private Byte status;

    @Column(name = "association_type")
    private Byte associationType;

    @Column(name = "current_status_updated_at")
    private Date currentStatusUpdatedAt;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "updated_by")
    private Integer updatedBy;

    @Column(name = "last_modified_at")
    private Date lastModifiedAt;

    @Column(name = "updated_by_type")
    private Byte updatedByType;

    @Column(name = "record_status")
    private Byte recordStatus;

    @Column(name = "first_assigned_to")
    private Integer firstAssignedTo;

    @Column(name = "last_assignee_response_at")
    private Date lastAssigneeResponseAt;

    @Column(name = "last_assignee_updated_at")
    private Date lastAssigneeUpdatedAt;

}
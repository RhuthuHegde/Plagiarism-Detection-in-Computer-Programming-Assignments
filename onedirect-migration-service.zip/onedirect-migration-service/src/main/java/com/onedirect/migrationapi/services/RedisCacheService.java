package com.onedirect.migrationapi.services;

import java.util.concurrent.TimeUnit;

/**
 * @author jp
 */
public interface RedisCacheService {

    /**
     * Put in cache.
     *
     * @param key the key
     * @param value the value
     * @return true, if successful
     */
    boolean putInCache(String key, String value);

    /**
     * Put in cache.
     *
     * @param hashMapKey the hash map key
     * @param key the key
     * @param value the value
     * @return true, if successful
     */
    boolean putInCache(Object hashMapKey, String key, String value);

    void putInCache(String key, TimeUnit timeUnit, Long ttl, Object obj);

    /**
     * Put in cache with ttl.
     *
     * @param key the key
     * @param value the value
     * @param ttlTimeInSec the ttl time in sec
     * @param timeUnit the time unit
     * @return true, if successful
     */
    boolean putInCacheWithTtl(String key, String value, Integer ttlTimeInSec, TimeUnit timeUnit);

    /**
     * Gets the from cache.
     *
     * @param key the key
     * @return the from cache
     */
    String getFromCache(String key);

    /**
     * Gets the from cache.
     *
     * @param hashMapKey the hash map key
     * @param key the key
     * @return the from cache
     */
    Object getFromCache(Object hashMapKey, String key);

    /**
     * Delete from cache.
     *
     * @param key the key
     * @return true, if successful
     */
    boolean deleteFromCache(String key);

    /**
     * Delete from cache.
     *
     * @param hashMapKey the hash map key
     * @param key the key
     * @return true, if successful
     */
    boolean deleteFromCache(Object hashMapKey, String key);

    /**
     * Sets the ttl in cache.
     *
     * @param key the key
     * @param ttlTimeInSec the ttl time in sec
     * @param timeUnit the time unit
     * @return true, if successful
     */
    boolean setTtlInCache(String key, Integer ttlTimeInSec, TimeUnit timeUnit);

    /**
     * Atomic get and set.
     *
     * @param key the key
     * @param value the value
     * @return the integer
     */
    String atomicGetAndSet(String key, String value);

    long incrementAndGetAtomicLong(String key);

    void setAtomicLong(String key, Long newValue);
}

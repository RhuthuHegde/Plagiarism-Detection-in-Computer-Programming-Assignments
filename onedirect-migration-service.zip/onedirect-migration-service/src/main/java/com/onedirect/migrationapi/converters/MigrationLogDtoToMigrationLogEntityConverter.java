package com.onedirect.migrationapi.converters;

import com.onedirect.migrationapi.dtos.MigrationLogDto;
import com.onedirect.migrationapi.entities.MigrationLog;
import com.onedirect.migrationapi.utils.GenericBuilder;

import java.util.Date;

/**
 * @author jp
 */

public class MigrationLogDtoToMigrationLogEntityConverter extends GenericMigrationServiceConverter<MigrationLogDto, MigrationLog>{
    public MigrationLogDtoToMigrationLogEntityConverter() {
        super(migrationLogDto -> {
            if(migrationLogDto == null){
                return null;
            }
            return GenericBuilder.of(MigrationLog::new)
                    .with(MigrationLog::setId, migrationLogDto.getId() == null ? null : Integer.valueOf(migrationLogDto.getId()))
                    .with(MigrationLog::setBrandConfigurationId, migrationLogDto.getBrandConfigurationId())
                    .with(MigrationLog::setRecordStatus, migrationLogDto.getRecordStatus())
                    .with(MigrationLog::setMigrationStatus, migrationLogDto.getMigrationStatus())
                    .with(MigrationLog::setStartTimestamp, migrationLogDto.getStartTimestamp())
                    .with(MigrationLog::setEndTimestamp, migrationLogDto.getEndTimestamp())
                    .with(MigrationLog::setCreatedAt, migrationLogDto.getCreatedAt())
                    .with(MigrationLog::setUpdatedAt, new Date())
                    .with(MigrationLog::setNumberOfTickets,migrationLogDto.getNumberOfTickets())
                    .with(MigrationLog::setFileList,migrationLogDto.getFileList())
                    .build();

        }, null);
    }
}

package com.onedirect.migrationapi.dtos.freshdesk;

import com.onedirect.migrationapi.dtos.freshdesk.user.FreshdeskUser;

import java.util.List;

public class FreshdeskUserDto {
    List<FreshdeskUser> freshdeskUserList;

    @Override
    public String toString() {
        return "FreshdeskUserDto{" +
                "freshdeskUserList=" + freshdeskUserList +
                '}';
    }

    public List<FreshdeskUser> getFreshdeskUserList() {
        return freshdeskUserList;
    }

    public void setFreshdeskUserList(List<FreshdeskUser> freshdeskUserList) {
        this.freshdeskUserList = freshdeskUserList;
    }
}

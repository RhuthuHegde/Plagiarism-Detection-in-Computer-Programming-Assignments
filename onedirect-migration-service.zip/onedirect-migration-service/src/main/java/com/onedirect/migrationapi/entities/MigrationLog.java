package com.onedirect.migrationapi.entities;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "migration_log")
public class MigrationLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "brand_configuration_id")
    private Integer brandConfigurationId;

    @Column(name = "record_status")
    private Byte recordStatus;

    @Column(name = "migration_status")
    private Byte migrationStatus;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name = "start_timestamp")
    private Long startTimestamp;

    @Column(name = "end_timestamp")
    private Long endTimestamp;

    @Column(name="number_of_tickets")
    private Long numberOfTickets;

    @Column(name="file_list")
    private String fileList;

}

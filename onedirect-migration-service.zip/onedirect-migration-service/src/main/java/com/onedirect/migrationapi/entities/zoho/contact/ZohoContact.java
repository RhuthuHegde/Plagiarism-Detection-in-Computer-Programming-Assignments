package com.onedirect.migrationapi.entities.zoho.contact;


import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="zoho_contact")
public class ZohoContact {
    @Id
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private Long accountId;
    private String phone;
    private String mobile;
    private String title;
    private Long ownerId;
    private String type;
    private Long createdBy;
    private String modifiedBy;
    private java.sql.Date createdTime;
    private String modifiedTime;
    private String fullName;
    private String salutation;
    private Boolean isEndUser;
    private String street;
    private String city;
    private String state;
    private String zip;
    private String country;
    private String description;
    private String twitter;
    private String facebook;
    private Long crmContactId;
    private String secondaryEmail;
    private Double potentialsRevenue;
    private String potentialsClosingDate;
    private Double revenueReceived;
    private String customerSince;
    private Long layoutId;
//    private Long id;
//    private String firstName;
//    private String lastName;
//    private String email;
//    private Long accountId;
//    private String phone;
//    private String mobile;
//    private String title;
//    private Long ownerId;
//    private String type;
//    private Long createdBy;
//    private Long modifiedBy;
//    private Date createdTime;
//    private Date modifiedTime;
//    private String fullName;
//    private String salutation;
//    private Boolean isEndUser;
//    private String street;
//    private String city;
//    private String state;
//    private String zip;
//    private String country;
//    private String description;
//    private String twitter;
//    private String facebook;
//    private Long crmContactId;
//    private String secondaryEmail;
//    private Double potentialsRevenue;
//    private Date potentialsClosingDate;
//    private Double revenueReceived;
//    private Date customerSince;
//    private Long layoutId;
//
//
//    private String contactType;
//    private ZohoOwnerUser owner;
//
//    private ZohoCustomerHappiness zohoCustomerHappinessRating;
//    private Boolean isDeleted;
//    private Boolean isTrashed;
//    private Boolean isSpam;
//    private String photoURL;
//    private String webUrl;

}

package com.onedirect.migrationapi.configs;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

/**
 * @author jp
 */

@Configuration
@ConfigurationProperties(prefix = "com.onedirect.migrationapi.services.slack")
@PropertySources(value = {@PropertySource("classpath:services.properties")})
@Getter
@Setter
public class SlackConfig {
    private String url;
    private String channelName;
    private String users;
}

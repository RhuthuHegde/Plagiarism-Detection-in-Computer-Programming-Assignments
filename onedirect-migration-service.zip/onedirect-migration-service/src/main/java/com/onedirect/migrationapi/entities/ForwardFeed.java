package com.onedirect.migrationapi.entities;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "forward_feed")
public class ForwardFeed {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "brand_id", nullable = false)
    private Integer brandId;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "brand_user_id")
    private Long brandUserId;

    @Column(name = "ticket_id")
    private Long ticketId;

    @Column(name = "team_id")
    private Integer teamId;

    @Column(name = "parent_id")
    private Long parentId;

    @Column(name = "brand_canned_response_id")
    private Integer brandCannedResponseId;

    @Column(name = "subject")
    private String subject;

    @Column(name = "hash_subject")
    private String hashSubject;

    @Column(name = "resource_text")
    private String resourceText;

    @Column(name = "parsed_resource_text")
    private String parsedResourceText;

    @Column(name = "message_id")
    private String messageId;

    @Column(name = "hash_message_id")
    private String hashMessageId;

    @Column(name = "message_type")
    private Byte messageType;

    @Column(name = "message_state")
    private Byte messageState;

    @Column(name = "sentiment")
    private Byte sentiment;

    @Column(name = "resource_publish_date")
    private Date resourcePublishDate;

    @Column(name = "brand_parser_config_id")
    private Integer brandParserConfigId;

    @Column(name = "status")
    private Byte status = 1;

    @Column(name = "created_at", nullable = false)
    private Date createdAt;

    @Column(name = "updated_at", nullable = false)
    private Date updatedAt;
}
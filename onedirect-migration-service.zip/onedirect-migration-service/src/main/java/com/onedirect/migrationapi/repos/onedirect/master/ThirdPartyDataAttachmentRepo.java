package com.onedirect.migrationapi.repos.onedirect.master;
import org.springframework.data.jpa.repository.JpaRepository;
import com.onedirect.migrationapi.entities.ThirdPartyDataAttachment;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ThirdPartyDataAttachmentRepo extends JpaRepository<ThirdPartyDataAttachment, Long> {

}

package com.onedirect.migrationapi.repos.migration.slave;

import com.onedirect.migrationapi.entities.BrandConfigurationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * @author jp
 */

@Repository
public interface BrandConfigurationRepo extends JpaRepository<BrandConfigurationEntity, Integer> {

    @Query(value = "SELECT bace FROM BrandConfigurationEntity bace WHERE bace.id =?1 AND bace.recordStatus =1")
    BrandConfigurationEntity findAccountById(Integer id);

    @Query(value = "SELECT bace FROM BrandConfigurationEntity bace WHERE bace.brandId =?1 AND bace.platformId =?2 AND bace.recordStatus =1")
    BrandConfigurationEntity findAccountByBrandIdAndPlatformId(Integer brandId, Integer platformId);

    @Query(value = "SELECT bace FROM BrandConfigurationEntity bace WHERE bace.brandId =?1 AND bace.recordStatus =1")
    BrandConfigurationEntity findAccountByBrandId(Integer brandID);
}

package com.onedirect.migrationapi.services.impl;
import com.google.gson.Gson;
import com.onedirect.migrationapi.bos.ConversationListBo;
import com.onedirect.migrationapi.bos.CustomFieldBo;
import com.onedirect.migrationapi.bos.CustomerBo;
import com.onedirect.migrationapi.bos.TicketListBo;
import com.onedirect.migrationapi.dtos.*;
import com.onedirect.migrationapi.entities.zoho.contact.ZohoContact;
import com.onedirect.migrationapi.entities.zoho.contants.CustomFieldConstants;
import com.onedirect.migrationapi.entities.zoho.thread.ZohoThread;
import com.onedirect.migrationapi.entities.zoho.thread.ZohoThreadAttachment;
import com.onedirect.migrationapi.entities.zoho.ticket.ZohoTicket;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.enums.TicketMigrationEnum;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.pojos.BrandFieldConfiguration;
import com.onedirect.migrationapi.services.MigrationDataService;
import com.onedirect.migrationapi.services.PlatformMigrationService;
import com.onedirect.migrationapi.services.ZohoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

@Service
public class ZohoMigrationService extends PlatformMigrationService {

    @Autowired
    MigrationDataService migrationDataService;

    @Autowired
    ZohoService zohoService;

    private static final Logger logger = LoggerFactory.getLogger(ZohoMigrationService.class);

    private static Gson gson = new Gson();


    public void performPreMigration(BrandConfigurationDto brandConfigurationDto,MigrationLog migrationLog,
                                    BrandFieldConfiguration brandFieldConfiguration){
//            try {
//                logger.info("Processing customers from DB");
//                List<ZohoContact> zohoContactList=zohoService.getAllZohoContacts();
//                List<Customer> customerList = zohoService.buildCustomersFromZohoContactsList(zohoContactList,brandConfigurationDto.getBrandId());
//                createCustomersAndPerformMapping(zohoContactList,customerList,brandConfigurationDto,brandFieldConfiguration);
//            }catch (Exception e){
//                logger.info("Unable to process customers",e);
//            }
        }

//    private void createCustomersAndPerformMapping(List<ZohoContact> zohoContactList, List<Customer> customerList, BrandConfigurationDto brandConfigurationDto, BrandFieldConfiguration brandFieldConfiguration) {
//        logger.info("Adding customers to DB and performing mapping");
//        for(int i=0;i<zohoContactList.size();i++) {
//            ZohoContact zohoContact = zohoContactList.get(i);
//            Customer customer = customerList.get(i);
//            try {
//                if (Objects.isNull(getPlatformCustomerMapping(zohoContact.getId(), brandConfigurationDto.getId()))) {
//                    Customer savedCustomer = migrationDataService.addCustomer(customer);
//                    String email = null;
//                    if (Objects.nonNull(zohoContact.getEmail()) && !zohoContact.getEmail().isEmpty()) {
//                        email = zohoContact.getEmail();
//                    } else if (Objects.nonNull(zohoContact.getFacebook())) {
//                        email = zohoContact.getFacebook() + "@facebook.com";
//                    } else if (Objects.nonNull(zohoContact.getTwitter()) && !zohoContact.getTwitter().isEmpty()) {
//                        email = zohoContact.getTwitter() + "@twitter.com";
//                    }
//                    String phone = null;
//                    if (Objects.nonNull(zohoContact.getPhone()) && !zohoContact.getPhone().isEmpty()) {
//                        phone = zohoContact.getPhone();
//                    }
//                    if (Objects.nonNull(zohoContact.getMobile()) && !zohoContact.getMobile().isEmpty()) {
//                        phone = zohoContact.getMobile();
//                    }
//                    List<CustomerLabelValue> customerLabelValueList = createCustomerLabelValues(brandFieldConfiguration, brandConfigurationDto, customer, email, phone);
//                    createPlatformCustomerMapping(zohoContact.getId(), savedCustomer.getId(), brandConfigurationDto.getId());
//                }
//            } catch (Exception e) {
//                logger.info("There was a problem migrating customer with Zoho customer Id :: {}  Exception : {}", zohoContact.getId(), e);
//            }
//
//        }

//}
////use ticket file
    @Override
    public TicketListBo getTickets(BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog, Map<String, Object> params) {
        TicketListBo ticketListBo=new TicketListBo();
        List<ZohoTicket> zohoTicketList=zohoService.getAllZohoTickets();
        List<Object> platformTicketList = new ArrayList<>(zohoTicketList);
        ticketListBo.setTicketList(platformTicketList);
        logger.info("Processing tickets");
        return ticketListBo;
    }

    @Override
    public void validateMigrationRequest(MigrationRequestDto migrationRequestDto,
                                         BrandConfigurationEntity brandConfigurationEntity,
                                         BrandFieldConfiguration brandFieldConfiguration) throws ResponseStatusException {
//        List<ZohoTicket> ticketList=zohoService.getAllZohoTickets();
//        List<ZohoContact> contactList=zohoService.getAllZohoContacts();
//        List<ZohoThread> threadList=zohoService.getAllThreads();
//        if(!(ticketList.size() >0))
//        {
//            logger.info("Ticket data doesn't exist in the DB");
//            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Tickets not found for brand");
//        }
//        if(!(contactList.size() >0))
//        {
//            logger.info("Contact data doesn't exist in the DB");
//            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Contacts not found for brand");
//        }
//        if(!(threadList.size() >0))
//        {
//            logger.info("Threads or conversation data doesn't exist in the DB");
//            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Threads not found for brand");
//        }
    }
//added the threads
    @Override
    public ConversationListBo getConversationsForTicket(Object ticket, BrandConfigurationDto brandConfigurationDto) {
        ConversationListBo conversationListBo = new ConversationListBo();
        ZohoTicket zohoTicket= (ZohoTicket) ticket;
//        Integer commentCheck= zohoTicket.getCommentCount();
             List<ZohoThread> zohoThreadList=zohoService.getZohoThreadByTicketId(zohoTicket.getId());
             if(zohoThreadList.size()<=0)
             {
                 logger.info("The Threads don't exist for ticket with ticket ID "+zohoTicket.getId());
                 zohoThreadList.add(zohoService.createZohoThread(zohoTicket));
             }
                 List<Object> platformConversation = new ArrayList<>(zohoThreadList);
            conversationListBo.setPlatformConversations(platformConversation);
            return conversationListBo;
//        catch(Exception e) {
//            logger.info("The Threads don't exist for ticket with ticket ID "+zohoTicket.getId());
//            throw new CustomInternalServerException("The Threads don't exist for ticket with ticket ID "+zohoTicket.getId(), ErrorCodes.DATA_NOT_FOUND);
//        }
    }

    @Override
    public void createTicketFailureMigrationLog(Integer brandId, Integer migrationLogId, Object platformTicket, Exception e) {
        ZohoTicket zohoTicket = (ZohoTicket) platformTicket;
        try{
            CustomInternalServerException exception = (CustomInternalServerException)e;
            logger.info("Migration service error for brand id :: {} and Zoho Ticket ID :: {} Error code :: {}  Error message :: {}",
                    brandId,zohoTicket.getId(), exception.getErrorCode().getCode(), exception.getErrorCode().getMessage());
        }catch (Exception ex){
            logger.info("An unexpected error occurred while migrating ticket for brand id :: {} with id :: {} error :: {} ",brandId,zohoTicket.getId(), Arrays.toString(e.getStackTrace()));
        }
        migrationDataService.createTicketMigrationLog(migrationLogId, zohoTicket.getId(), null, null, TicketMigrationEnum.FAILED);
    }

    @Override
    public PlatformCustomerMappingEntity getPlatformCustomerMapping(Object platformTicket, BrandConfigurationDto brandConfigurationDto) {
        ZohoTicket zohoTicket = (ZohoTicket) platformTicket;
        return getPlatformCustomerMapping(zohoTicket.getContactId(),brandConfigurationDto.getId());
    }

    @Override
    public CustomerBo getCustomerForTicket(Object platformTicket, BrandConfigurationDto brandConfigurationDto) {
        ZohoTicket zohoTicket=(ZohoTicket) platformTicket;
        ZohoContact zohoContact=zohoService.getZohoContactById(zohoTicket.getContactId());
    CustomerBo customerBo=new CustomerBo();
    customerBo.setPlatformCustomer(zohoContact);
        return customerBo;
    }

    @Override
    public Customer createCustomerFromPlatformCustomer(CustomerBo platformCustomer, BrandConfigurationDto brandConfigurationDto) {
        ZohoContact zohoContact = (ZohoContact) platformCustomer.getPlatformCustomer();
        return createCustomer(zohoContact,brandConfigurationDto);
    }


    @Override
    public List<CustomerLabelValue> createCustomerLabelValue(Customer customer, CustomerBo platformCustomer, BrandConfigurationDto brandConfigurationDto, BrandFieldConfiguration brandFieldConfiguration) {
        ZohoContact zohoContact = (ZohoContact)platformCustomer.getPlatformCustomer();
        return createCustomerLabelValues(brandFieldConfiguration,brandConfigurationDto,customer,zohoContact.getEmail(), zohoContact.getPhone());
    }

    @Override
    public Long getBrandUserId(Object platformTicket, BrandConfigurationDto brandConfigurationDto) {
        ZohoTicket zohoTicket = (ZohoTicket) platformTicket;
        return getBrandUserId(zohoTicket.getAssigneeId(),brandConfigurationDto.getDefaultAgentId(),brandConfigurationDto.getId());
    }

    @Override
    public QueuedAttachmentsDto createQueuedAttachmentDto(Object platformConversation,
                                                          Ticket ticket,
                                                          ThirdPartyData thirdPartyData,
                                                          BrandConfigurationDto brandConfigurationDto,
                                                          ForwardFeed forwardFeed) {
//        List<ZohoThreadAttachment> zohoThreadAttachmentList= new ArrayList<>();
        ZohoThread zohoThread = (ZohoThread) platformConversation;
//        ZohoTicket zohoTicket=zohoService.getZohoTicketById(zohoThread.getTicketId());
//        List<ZohoThread> zohoThreadList= zohoService.getZohoThreadByTicketId(zohoTicket.getID());
//        for (ZohoThread thread : zohoThreadList) {
//            zohoThreadAttachmentList.add(zohoService.getZohoThreadAttachment(thread.getID()));
//        }
//            ZohoThreadAttachment zohoThreadAttachment = zohoService.getZohoThreadAttachment(zohoThread.getId());
        if(Objects.nonNull(zohoService.getZohoThreadAttachment(zohoThread.getId())) && (zohoService.getZohoThreadAttachment(zohoThread.getId()).size() != 0)) {
            if (Objects.nonNull(forwardFeed)) {
                return createQueuedAttachmentDto(brandConfigurationDto.getBrandId(),
                        ticket.getId(), forwardFeed.getId(), null, zohoThread, forwardFeed.getCreatedAt(),
                        forwardFeed.getUpdatedAt(), brandConfigurationDto.getPlatformId());
            } else {
                return createQueuedAttachmentDto(brandConfigurationDto.getBrandId(), ticket.getId(),
                        null, thirdPartyData.getId(),
                        zohoThread, thirdPartyData.getCreatedAt(),
                        thirdPartyData.getUpdatedAt(), brandConfigurationDto.getPlatformId());
            }
        }
            return null;
        }


    private QueuedAttachmentsDto createQueuedAttachmentDto(Integer brandId, Long ticketId, Long forwardFeedId,
                                                           Long thirdPartyDataId,
                                                           ZohoThread zohoThread, Date createdAt, Date updatedAt,
                                                           Integer platformId) {
//        ZohoThreadAttachment zohoThreadAttachment=zohoService.getZohoThreadAttachment(zohoThread.getId());
        return migrationDataService.createQueuedAttachmentDto(brandId,ticketId,forwardFeedId,
                thirdPartyDataId,zohoThread.getId(),
                createdAt,updatedAt,platformId,gson.toJson(zohoService.getZohoThreadAttachment(zohoThread.getId())));
    }

    @Override
    public List<ForwardFeedAttachmentDto> uploadAttachmentsForForwardFeed(String attachmentListJson, Integer brandId) {
        List<ZohoThreadAttachment> zohoThreadAttachmentList = zohoService
                .getZohoUploadAttachmentFromJson(attachmentListJson);
        List<ForwardFeedAttachmentDto> forwardFeedAttachmentDtos =  zohoService.createForwardFeedAttachmentDtoList(zohoThreadAttachmentList,brandId);
        return forwardFeedAttachmentDtos;
    }

    @Override
    public ForwardFeed createForwardFeed(Ticket ticket, Object platformConversation, Object platformTicket) {
        ZohoThread zohoThread = (ZohoThread) platformConversation;
        ZohoTicket zohoTicket = (ZohoTicket)platformTicket;
        return zohoService.generateForwardFeed(ticket,zohoThread,zohoTicket);
    }

    @Override
    public ForwardCustomerInfoValueJsonDto createForwardCustomerInfoValueDto(Object platformTicket, Object platformConversation, BrandConfigurationDto brandConfigurationDto, Long customerId, BrandFieldConfiguration brandFieldConfiguration) {
        ZohoTicket zohoTicket = (ZohoTicket) platformTicket;
        ZohoThread zohoThread=(ZohoThread) platformConversation;
        Customer customer = migrationDataService.getCustomerById(customerId);
        CustomerLabelValue customerLabelValue = getCustomerLabelValueForCustomerIdAndFieldId(customerId,
                brandFieldConfiguration.getEmailCustomerFieldId().intValue());
        String email = customer.getName() + "@noemail.com";
        if(Objects.nonNull(customerLabelValue)){
            email = customerLabelValue.getCustomerLabelText();
        }
        return generateValueJsonForForwardCustomerInfoDto(zohoThread.getIsPrivate(), zohoThread.getThreadStatus().equals("EMAIL OUTGOING"),
                customer.getName(),email,brandConfigurationDto);
//        return null;
    }

    @Override
    public void createTicketSuccessMigrationLog(Integer migrationLogId, Ticket ticket, Object platformTicket) {
        ZohoTicket zohoTicket = (ZohoTicket) platformTicket;
        migrationDataService.createTicketMigrationLog(migrationLogId, zohoTicket.getId(),
                ticket.getBrandTicketId(), ticket.getId(), TicketMigrationEnum.SUCCESS);
    }

    @Override
    public Ticket createTicketFromPlatformTicket(Object platformTicket, Integer brandId, Long oneDirectCustomerId, Integer brandUserId, Long latestBrandTicketId) {
        ZohoTicket zohoTicket = (ZohoTicket)platformTicket;
        return zohoService.buildOneDirectTicket(zohoTicket,brandId,oneDirectCustomerId,brandUserId
                ,latestBrandTicketId);
    }

    @Override
    public Map<String, String> uploadAttachmentsForThirdPartyData(String attachmentListJson, Integer brandId) {
        List<ZohoThreadAttachment> zohoThreadAttachmentList = zohoService
                .getZohoUploadAttachmentFromJson(attachmentListJson);
        return zohoService.uploadAttachments(zohoThreadAttachmentList,brandId);
    }

    @Override
    public PlatformCustomerMappingEntity createPlatformCustomerMapping(Object platformCustomer, BrandConfigurationDto brandConfigurationDto, Customer customer) {
        ZohoContact zohoContact = (ZohoContact)platformCustomer;
        return createPlatformCustomerMapping(zohoContact.getId(),customer.getId(),
                brandConfigurationDto.getId());
    }

    @Override
    public TicketFieldValue getPlatformTicketIdTicketField(Ticket ticket, Integer brandId, Object platformTicket, BrandFieldConfiguration brandFieldConfiguration) {
        Long oneDirectLabelIdForTicketFieldZohoTicketId = brandFieldConfiguration.getPlatformTicketIdTicketFieldId();
        ZohoTicket zohoTicket = (ZohoTicket)platformTicket;
        return getPlatformTicketIdTicketField(oneDirectLabelIdForTicketFieldZohoTicketId,ticket,brandId,zohoTicket.getId());
    }

    @Override
    public List<CustomFieldBo> getCustomFieldBoList(Object platformTicket) {
            ZohoTicket zohoTicket = (ZohoTicket) platformTicket;
            List<CustomFieldBo> customFieldBoList = new ArrayList<>();
            List<String> customFieldList=new ArrayList<>();
            customFieldList.add(CustomFieldConstants.CUSTOM_FIELD_FOLLOW_UPS);
            customFieldList.add(CustomFieldConstants.CUSTOM_FIELD_ISSUE);
            customFieldList.add(CustomFieldConstants.CUSTOM_FIELD_NEXT_ACTION);
            customFieldList.add(CustomFieldConstants.CUSTOM_FIELD_LOB);
            customFieldList.add(CustomFieldConstants.CUSTOM_FIELD_PICKLIST_1);
        for (String s : customFieldList) {
            if (!Objects.equals(zohoTicket.getCf_follow_ups(), "") && s.equals(CustomFieldConstants.CUSTOM_FIELD_FOLLOW_UPS)) {
                customFieldBoList.add(new CustomFieldBo(CustomFieldConstants.CUSTOM_FIELD_FOLLOW_UPS,
                        zohoTicket.getCf_follow_ups()));
            }
            if (!Objects.equals(zohoTicket.getCf_issue(), "") && s.equals(CustomFieldConstants.CUSTOM_FIELD_ISSUE)) {
                customFieldBoList.add(new CustomFieldBo(CustomFieldConstants.CUSTOM_FIELD_ISSUE,
                        zohoTicket.getCf_issue()));
            }
            if (!Objects.equals(zohoTicket.getCf_next_action(), "") && s.equals(CustomFieldConstants.CUSTOM_FIELD_NEXT_ACTION)) {
                customFieldBoList.add(new CustomFieldBo(CustomFieldConstants.CUSTOM_FIELD_NEXT_ACTION,
                        zohoTicket.getCf_next_action()));
            }
            if (!Objects.equals(zohoTicket.getCf_lob(), "") && s.equals(CustomFieldConstants.CUSTOM_FIELD_LOB)) {
                customFieldBoList.add(new CustomFieldBo(CustomFieldConstants.CUSTOM_FIELD_LOB,
                        zohoTicket.getCf_lob()));
            }
            if (!Objects.equals(zohoTicket.getCf_picklist_1(), "") && s.equals(CustomFieldConstants.CUSTOM_FIELD_PICKLIST_1)) {
                customFieldBoList.add(new CustomFieldBo(CustomFieldConstants.CUSTOM_FIELD_PICKLIST_1,
                        zohoTicket.getCf_picklist_1()));
            }
        }
            return customFieldBoList;
        }

    @Override
    public ThirdPartyData createThirdPartyDataForTicket(Ticket ticket, Object platformConversations) {
                ZohoThread zohoThread = (ZohoThread) platformConversations;
            return createThirdPartyData(ticket,zohoThread.getSummary());

    }

    private Customer createCustomer(ZohoContact zohoContact, BrandConfigurationDto brandConfigurationDto) {
        return zohoService.addCustomer(zohoContact,brandConfigurationDto);
    }
    }
package com.onedirect.migrationapi.repos.onedirect.master;

import com.onedirect.migrationapi.entities.TicketFieldValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface TicketFieldValueRepo extends JpaRepository<TicketFieldValue,Long> {

    @Query("select tfv from TicketFieldValue tfv where tfv.brandId=?1 and tfv.ticketLabelText=?2 and tfv.ticketLabelId = ?3")
    @Transactional(readOnly = true)
    List<TicketFieldValue> getTicketFieldValueForGivenValue(Integer brandId,String value,Integer fieldId);
}

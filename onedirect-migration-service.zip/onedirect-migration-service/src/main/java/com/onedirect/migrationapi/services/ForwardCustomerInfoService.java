package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.ForwardCustomerInfo;

public interface ForwardCustomerInfoService {
    public ForwardCustomerInfo createForwardCustomerInfo(ForwardCustomerInfo forwardCustomerInfo);
}

package com.onedirect.migrationapi.dtos.zendesk.ticket;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicket;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskTicketResponseDto {

    @JsonProperty("tickets")
    private List<ZendeskTicket> tickets;
    @JsonProperty("after_url")
    private String afterUrl;
    @JsonProperty("before_url")
    private String beforeUrl;
    @JsonProperty("after_cursor")
    private String afterCursor;
    @JsonProperty("before_cursor")
    private String beforeCursor;
    @JsonProperty("end_of_stream")
    private Boolean endOfStream;

}

package com.onedirect.migrationapi.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.Date;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class ForwardFeedDto {

    private Long id;

    private Integer brandId;

    private Long customerId;

    private Long brandUserId;

    private Long ticketId;

    private Integer teamId;

    private Long parentId;

    private Integer brandCannedResponseId;

    private String subject;

    private String hashSubject;

    private String resourceText;

    private String parsedResourceText;

    private String messageId;

    private String hashMessageId;

    private Byte messageType;

    private Byte messageState;

    private Byte sentiment;

    private Date resourcePublishDate;

    private Integer brandParserConfigId;

    private Byte status = 1;

    private Date createdAt;

    private Date updatedAt;
}

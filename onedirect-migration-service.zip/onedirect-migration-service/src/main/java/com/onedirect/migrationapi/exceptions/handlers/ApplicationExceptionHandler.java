package com.onedirect.migrationapi.exceptions.handlers;

import com.onedirect.commonutils.exceptions.exception.FatalException;
import com.onedirect.commonutils.exceptions.exception.ServiceException;
import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.dtos.ErrorResponseDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author jp
 */

@ControllerAdvice
public class ApplicationExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationExceptionHandler.class);

    @ExceptionHandler({FatalException.class})
    @ResponseBody
    public ResponseEntity<?> handleFatalExceptions(final FatalException e) {
        String stackTrace = e.getStackTraceInStringFmt();

        String joinedInfo = String.join(", ", e.getInfo());

        logger.error("{} {} Message :: {}, Cause :: {}", Constants.FATAL_ERROR_PREFIX, joinedInfo,
                e.getMessage(), stackTrace);

        ErrorResponseDto errorResponse = new ErrorResponseDto(e.getCode(), e.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler({ServiceException.class})
    public ResponseEntity<?> handleServiceExceptions(final ServiceException e) {
        String stackTrace = e.getStackTraceInStringFmt();

        logger.error("{} {}, Message :: {}, Cause :: {}", Constants.SERVICE_ERROR_PREFIX,
                String.join(", ", e.getInfo()), e.getMessage(), stackTrace);

        ErrorResponseDto errorResponse = new ErrorResponseDto(e.getCode(), e.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
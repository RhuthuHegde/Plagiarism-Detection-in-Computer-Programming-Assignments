package com.onedirect.migrationapi.repos.migration.slave.zohorepo.conversation;

import com.onedirect.migrationapi.entities.zoho.thread.ZohoThread;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ZohoThreadRepo extends JpaRepository<ZohoThread,Long> {
    @Query("SELECT zth FROM ZohoThread zth WHERE zth.ticketId=?1")
    List<ZohoThread> findZohoThreadByTicketId(Long ticketID);
}

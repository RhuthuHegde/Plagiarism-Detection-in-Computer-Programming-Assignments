package com.onedirect.migrationapi.configs;

import com.onedirect.migrationapi.constants.BeanConstant;
import com.onedirect.migrationapi.constants.DataConfigConstant;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "db.config")
@PropertySources(value = {@PropertySource("classpath:dataSourcesConfig.properties")})
public class DataSourceConfiguration {

    private String ddlAuto;
    private Integer cacheQueryPlanSize;
    private String fmtSql;
    private String showSql;
    private String dialect;

    @Bean(name = BeanConstant.JPA_REPO)
    public Map<String, Object> jpaProperties() {
        Map<String, Object> jpaProperties = new HashMap<>();
        jpaProperties.put(DataConfigConstant.HIBERNATE_DIALCET, dialect);
        jpaProperties.put(DataConfigConstant.HIBERNATE_SHOW_SQL, showSql);
        jpaProperties.put(DataConfigConstant.HIBERNATE_FORMAT_SQL, fmtSql);
        jpaProperties.put(DataConfigConstant.HIBERNATE_AUTO, ddlAuto);
        jpaProperties.put(DataConfigConstant.HIBERNATE_QUERYPLAN_CACHESIZE, cacheQueryPlanSize);
        return jpaProperties;
    }
}

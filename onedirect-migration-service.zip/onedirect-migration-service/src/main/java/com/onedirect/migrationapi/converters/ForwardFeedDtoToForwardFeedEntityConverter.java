package com.onedirect.migrationapi.converters;

import com.onedirect.migrationapi.dtos.ForwardFeedDto;
import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.utils.GenericBuilder;

import java.util.Date;

/**
 * @author jp
 */

public class ForwardFeedDtoToForwardFeedEntityConverter extends GenericMigrationServiceConverter<ForwardFeedDto, ForwardFeed>{
    public ForwardFeedDtoToForwardFeedEntityConverter() {
        super(forwardFeedDto -> {
            if(forwardFeedDto == null){
                return null;
            }
            return GenericBuilder.of(ForwardFeed::new)
                    .with(ForwardFeed::setId, forwardFeedDto.getId() == null ? null : forwardFeedDto.getId())
                    .with(ForwardFeed::setBrandId, forwardFeedDto.getBrandId())
                    .with(ForwardFeed::setCustomerId, forwardFeedDto.getCustomerId())
                    .with(ForwardFeed::setBrandUserId, forwardFeedDto.getBrandUserId())
                    .with(ForwardFeed::setTicketId, forwardFeedDto.getTicketId())
                    .with(ForwardFeed::setTeamId, forwardFeedDto.getTeamId())
                    .with(ForwardFeed::setParentId, forwardFeedDto.getParentId())
                    .with(ForwardFeed::setBrandCannedResponseId, forwardFeedDto.getBrandCannedResponseId())
                    .with(ForwardFeed::setSubject, forwardFeedDto.getSubject())
                    .with(ForwardFeed::setHashSubject, forwardFeedDto.getHashSubject())
                    .with(ForwardFeed::setResourceText, forwardFeedDto.getResourceText())
                    .with(ForwardFeed::setParsedResourceText, forwardFeedDto.getParsedResourceText())
                    .with(ForwardFeed::setMessageId, forwardFeedDto.getMessageId())
                    .with(ForwardFeed::setHashMessageId, forwardFeedDto.getHashMessageId())
                    .with(ForwardFeed::setMessageType, forwardFeedDto.getMessageType())
                    .with(ForwardFeed::setMessageState, forwardFeedDto.getMessageState())
                    .with(ForwardFeed::setSentiment, forwardFeedDto.getSentiment())
                    .with(ForwardFeed::setResourcePublishDate, forwardFeedDto.getResourcePublishDate())
                    .with(ForwardFeed::setBrandParserConfigId, forwardFeedDto.getBrandParserConfigId())
                    .with(ForwardFeed::setStatus, forwardFeedDto.getStatus())
                    .with(ForwardFeed::setCreatedAt, forwardFeedDto.getCreatedAt())
                    .with(ForwardFeed::setUpdatedAt, new Date())
                    .build();

        }, null);
    }
}

package com.onedirect.migrationapi.repos.migration.slave;

import com.onedirect.migrationapi.entities.MigrationLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author jp
 */

@Repository
public interface MigrationLogRepo extends JpaRepository<MigrationLog, Integer> {
}

package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.services.XMLFileReaderService;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;

@Service
public class XMLFileReaderServiceImpl implements XMLFileReaderService {

    SAXParserFactory factory = SAXParserFactory.newInstance();
    @Override
    public void readAndParseXMLFileWithHandler(String path, DefaultHandler handler) {
        try {
            SAXParser saxParser = factory.newSAXParser();
            saxParser.parse(path,handler);
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
    }
}
package com.onedirect.migrationapi.dtos;

import com.onedirect.commonutils.utils.JsonUtil;
import com.onedirect.migrationapi.enums.StorageType;

/**
 * @author jp
 */

public class FileMetaData {
    private StorageType storageType;
    private String url;
    private String contentType;
    private String contentDisposition;
    private Long contentLength;
    private String fileName;
    private String uniqueId;

    private FileMetaData(FileMetaData.Builder builder) {
        this.storageType = builder.storageType;
        this.url = builder.url;
        this.contentType = builder.contentType;
        this.fileName = builder.fileName;
        this.contentLength = builder.contentLength;
        this.uniqueId = builder.uniqueId;
        this.contentDisposition = builder.contentDisposition;
    }

    public static FileMetaData.Builder Builder() {
        return new FileMetaData.Builder();
    }

    public StorageType getStorageType() {
        return this.storageType;
    }

    public void setStorageType(StorageType storageType) {
        this.storageType = storageType;
    }

    public String getUrl() {
        return this.url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getContentType() {
        return this.contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileName() {
        return this.fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Long getContentLength() {
        return this.contentLength;
    }

    public void setContentLength(Long contentLength) {
        this.contentLength = contentLength;
    }

    public String getUniqueId() {
        return this.uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getContentDisposition() {
        return this.contentDisposition;
    }

    public void setContentDisposition(String contentDisposition) {
        this.contentDisposition = contentDisposition;
    }

    public String toString() {
        return JsonUtil.toJson(this);
    }

    public static final class Builder {
        private StorageType storageType;
        private String url;
        private String contentType;
        private String fileName;
        private Long contentLength;
        private String uniqueId;
        private String contentDisposition;

        private Builder() {
        }

        public FileMetaData build() {
            return new FileMetaData(this);
        }

        public FileMetaData.Builder storageType(StorageType storageType) {
            this.storageType = storageType;
            return this;
        }

        public FileMetaData.Builder url(String url) {
            this.url = url;
            return this;
        }

        public FileMetaData.Builder contentType(String contentType) {
            this.contentType = contentType;
            return this;
        }

        public FileMetaData.Builder fileName(String fileName) {
            this.fileName = fileName;
            return this;
        }

        public FileMetaData.Builder contentLength(Long contentLength) {
            this.contentLength = contentLength;
            return this;
        }

        public FileMetaData.Builder uniqueId(String uniqueId) {
            this.uniqueId = uniqueId;
            return this;
        }

        public FileMetaData.Builder contentDisposition(String contentDisposition) {
            this.contentDisposition = contentDisposition;
            return this;
        }
    }
}

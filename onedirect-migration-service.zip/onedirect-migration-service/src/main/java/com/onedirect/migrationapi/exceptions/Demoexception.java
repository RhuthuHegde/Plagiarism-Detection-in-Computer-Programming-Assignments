package com.onedirect.migrationapi.exceptions;

/**
 * @author jp
 */
public class Demoexception {
}

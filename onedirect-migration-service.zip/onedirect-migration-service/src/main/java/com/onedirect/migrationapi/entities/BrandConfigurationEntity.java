package com.onedirect.migrationapi.entities;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "brand_configuration")
public class BrandConfigurationEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "brand_id")
    private Integer brandId;

    @Column(name = "brand_support_name")
    private String brandSupportName;

    @Column(name = "brand_support_address")
    private String brandSupportAddress;

    @Column(name = "platform_domain")
    private String platformDomain;

    @Column(name = "platform_id")
    private Integer platformId;

    @Column(name = "platform_auth_key")
    private String platformAuthorizationKey;

    @Column(name = "record_status")
    private Byte recordStatus;

    @Column(name = "is_migration_enabled")
    private Boolean isMigrationEnabled;

    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "updated_at")
    private Date updatedAt;

    @Column(name="default_agent_id")
    private Long defaultAgentId;
}

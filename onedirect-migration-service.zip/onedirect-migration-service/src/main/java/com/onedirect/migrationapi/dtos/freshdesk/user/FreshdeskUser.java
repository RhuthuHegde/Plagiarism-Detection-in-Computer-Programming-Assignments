package com.onedirect.migrationapi.dtos.freshdesk.user;

public class FreshdeskUser {
    String address;
    String createdAt;
    Long customerId;
    String description;
    String email;
    Long facebookProfileId;
    Long id;
    String name;
    String phone;
    String twitterId;
    String updatedAt;
    String mobile;

    @Override
    public String
    toString() {
        return "FreshdeskUser{" +
                "address='" + address + '\'' +
                ", createdAt='" + createdAt + '\'' +
                ", customerId=" + customerId +
                ", description='" + description + '\'' +
                ", email='" + email + '\'' +
                ", facebookProfileId=" + facebookProfileId +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", twitterId='" + twitterId + '\'' +
                ", updatedAt='" + updatedAt + '\'' +
                ", mobile='" + mobile + '\'' +
                '}';
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getFacebookProfileId() {
        return facebookProfileId;
    }

    public void setFacebookProfileId(Long facebookProfileId) {
        this.facebookProfileId = facebookProfileId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTwitterId() {
        return twitterId;
    }

    public void setTwitterId(String twitterId) {
        this.twitterId = twitterId;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}

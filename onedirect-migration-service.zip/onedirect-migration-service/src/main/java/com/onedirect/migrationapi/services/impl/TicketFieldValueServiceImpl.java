package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.TicketFieldValue;
import com.onedirect.migrationapi.repos.onedirect.master.TicketFieldValueRepo;
import com.onedirect.migrationapi.services.TicketFieldValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketFieldValueServiceImpl implements TicketFieldValueService {

    @Autowired
    TicketFieldValueRepo ticketFieldValueRepo;

    @Override
    public TicketFieldValue addTicketFieldValue(TicketFieldValue ticketFieldValue) {
        return ticketFieldValueRepo.save(ticketFieldValue);
    }

    @Override
    public List<TicketFieldValue> getTicketFieldValueForGivenValue(Integer brandId, String value, Integer fieldId) {
    return ticketFieldValueRepo.getTicketFieldValueForGivenValue(brandId,value,fieldId);
    }
}

package com.onedirect.migrationapi.entities.zoho.ticket;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoTicketAssignee {
     private Long id;
     private String firstName;
     private String lastName;
     private String email;
     private String photoURL;

}

package com.onedirect.migrationapi.enums;

public enum TicketFieldValueTypeEnum {
    TEXT(1),
    INT(2),
    DECIMAL(3),
    LOCATION(4),
    DATE(5),
    BOOL(6);
    private int id;
    public int getId(){
        return id;
    }
    private TicketFieldValueTypeEnum(int id){
        this.id = id;
    }
}

package com.onedirect.migrationapi.repos.onedirect.master;

import com.onedirect.migrationapi.entities.TicketTag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TicketTagRepo extends JpaRepository<TicketTag,Long> {
}

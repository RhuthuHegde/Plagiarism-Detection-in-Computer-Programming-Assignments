package com.onedirect.migrationapi.dtos.zendesk.comment;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskCommentsDto {

        @JsonProperty("next_page")
        private String nextPage;
        @JsonProperty("previous_page")
        private String previousPage;
        @JsonProperty("count")
        private Integer count;

        @JsonProperty("comments")
        private List<ZendeskComment> comments;
}


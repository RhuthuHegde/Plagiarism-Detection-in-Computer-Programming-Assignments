package com.onedirect.migrationapi.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.Date;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class BrandConfigurationDto {

    private Integer id;

    private Integer brandId;

    private String brandSupportName;

    private String brandSupportAddress;

    private String platformDomain;

    private Integer platformId;

    private String platformAuthorizationKey;

    private Byte recordStatus;

    private Boolean isMigrationEnabled;

    private Date createdAt;

    private Date updatedAt;

    private Long defaultAgentId;
}

package com.onedirect.migrationapi.enums;

public enum TicketStatusType {
  NEW((byte) 0, "new"),
  OPEN((byte) 1, "open"),
  PENDING((byte) 2, "pending"),
  AWAITING_RESPONSE((byte) 3, "awaitingResponse"),
  RESOLVED((byte) 4, "resolved"),
  CLOSED((byte) 5, "closed");

  private byte id;
  private String value;

  TicketStatusType(byte id, String value) {
    this.id = id;
    this.value = value;
  }

  public static TicketStatusType getEnumByValue(String status) {
    for (TicketStatusType statusType : TicketStatusType.values()) {
      if (statusType.getValue().equalsIgnoreCase(status)) {
        return statusType;
      }
    }
    return null;
  }

  public static TicketStatusType getEnumById(Byte id) {
    for (TicketStatusType statusType : TicketStatusType.values()) {
      if (statusType.getId() == id) {
        return statusType;
      }
    }
    return null;
  }

  public byte getId() {
    return id;
  }

  public String getValue() {
    return value;
  }
}

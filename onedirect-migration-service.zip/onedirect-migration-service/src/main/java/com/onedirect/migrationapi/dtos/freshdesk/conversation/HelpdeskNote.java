package com.onedirect.migrationapi.dtos.freshdesk.conversation;

import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskAttachment;

import java.util.List;

public class HelpdeskNote {
    private String body;
    private String bodyHtml;
    private String createdAt;
    private String updatedAt;
    private List<FreshdeskAttachment> freshdeskAttachmentList;
    private Integer source;
    private Long Id;
    private Boolean _private;
    private Boolean incoming;

    public Boolean get_private() {
        return _private;
    }

    public void set_private(Boolean _private) {
        this._private = _private;
    }

    public Boolean getIncoming() {
        return incoming;
    }

    public void setIncoming(Boolean incoming) {
        this.incoming = incoming;
    }

    public String getBodyHtml() {
        return bodyHtml;
    }

    public void setBodyHtml(String bodyHtml) {
        this.bodyHtml = bodyHtml;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<FreshdeskAttachment> getFreshdeskAttachmentList() {
        return freshdeskAttachmentList;
    }

    public void setFreshdeskAttachmentList(List<FreshdeskAttachment> freshdeskAttachmentList) {
        this.freshdeskAttachmentList = freshdeskAttachmentList;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    @Override
    public String toString() {
        return "HelpdeskNote{" +
                "body='" + body + '\'' +
                ", bodyHtml='" + bodyHtml + '\'' +
                ", createdAt='" + createdAt + '\'' +
                ", updatedAt='" + updatedAt + '\'' +
                ", freshdeskAttachmentList=" + freshdeskAttachmentList +
                ", source=" + source +
                ", Id=" + Id +
                ", _private=" + _private +
                ", incoming=" + incoming +
                '}';
    }
}

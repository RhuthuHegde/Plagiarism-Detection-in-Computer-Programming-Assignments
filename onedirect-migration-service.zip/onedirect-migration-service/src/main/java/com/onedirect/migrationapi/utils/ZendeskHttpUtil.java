package com.onedirect.migrationapi.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.services.impl.ZendeskServiceImpl;
import com.onedirect.migrationapi.strategy.ZendeskRetryStrategy;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class ZendeskHttpUtil {

    private static final Logger logger = LoggerFactory.getLogger(ZendeskHttpUtil.class);

    public static <T> T getFromZendesk(String url, Map<String,Object> headers,Class<T> returnType){
        ZendeskRetryStrategy zendeskRetryStrategy = new ZendeskRetryStrategy();
        T responseDto = null;
        while(zendeskRetryStrategy.shouldRetry()){
            try{
                responseDto = HttpClientUtil.get(url,new ArrayList<>(),returnType,headers);
                if(Objects.nonNull(responseDto))
                    return responseDto;
            }catch (IOException e){
                    zendeskRetryStrategy.errorOccurred();
            }
        }
        return responseDto;
    }

    public static <T> T fetchFromZendesk(String url, Map<String, String> headers, Class<T> returnType) {
        HttpClient httpClient = HttpClients.custom()
                .setDefaultRequestConfig(RequestConfig.custom()
                        .setCookieSpec(CookieSpecs.STANDARD).build()).build();
        HttpGet request = new HttpGet(url);
        populateHeaderMap(headers, request);
        HttpResponse response = null;
        try {
            response = httpClient.execute(request);
            if(response.getStatusLine().getStatusCode() == 404)
                return null;
            if(response.getStatusLine().getStatusCode() != 200) {
                Thread.sleep(60000);
                response = httpClient.execute(request);
                if(response.getStatusLine().getStatusCode() == 404)
                    return null;
                if(response.getStatusLine().getStatusCode() != 200) {
                    Thread.sleep(60000);
                    response = httpClient.execute(request);
                    if(response.getStatusLine().getStatusCode() == 404)
                        return null;
                    if(response.getStatusLine().getStatusCode() != 200)
                        throw new CustomInternalServerException("Max retries exceeded for zendesk external api",
                                ErrorCodes.ZENDESK_MAX_RETRY_ERROR);
                }
            }

            if(response.getStatusLine().getStatusCode() == 200) {
                HttpEntity httpEntity = response.getEntity();
                if (httpEntity != null) {
                    String responseString = EntityUtils.toString(httpEntity);
                    if(!StringUtils.isEmpty(responseString)) {
                        ObjectMapper mapper = new ObjectMapper();
                        T zendeskDto = mapper.readValue(responseString, returnType);
                        return zendeskDto;
                    }
                }
            }
        } catch (IOException | InterruptedException e) {
            logger.info("Error while calling zendesk external api. " + e);
            throw new CustomInternalServerException("Error occurred while fetch data from zendesk external api.",
                    ErrorCodes.ZENDESK_SERVICE_ERROR);
        }
        return null;
    }

    private static void populateHeaderMap(Map<String, String> headers, HttpRequestBase request) {
        if (headers == null) {
            headers = new HashMap();
        }

        ((Map)headers).put("Content-Type", "application/json");
        Iterator var2 = ((Map)headers).entrySet().iterator();

        while(var2.hasNext()) {
            Map.Entry<String, String> header = (Map.Entry)var2.next();
            request.addHeader((String)header.getKey(), (String)header.getValue());
        }

    }

}

package com.onedirect.migrationapi.dtos.zendesk.ticket;

import com.fasterxml.jackson.annotation.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskSatisfactionRating {

    @JsonProperty("score")
    private String score;


}
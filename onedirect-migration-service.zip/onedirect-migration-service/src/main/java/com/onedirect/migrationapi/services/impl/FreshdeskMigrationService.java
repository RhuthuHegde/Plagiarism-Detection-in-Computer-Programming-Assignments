package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.rpc.Help;
import com.onedirect.migrationapi.bos.ConversationListBo;
import com.onedirect.migrationapi.bos.CustomFieldBo;
import com.onedirect.migrationapi.bos.CustomerBo;
import com.onedirect.migrationapi.bos.TicketListBo;
import com.onedirect.migrationapi.constants.MigrationPlatformConstants;
import com.onedirect.migrationapi.dtos.*;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskAttachment;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskTicketsDto;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskUserDto;
import com.onedirect.migrationapi.dtos.freshdesk.conversation.HelpdeskNote;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.FreshdeskCustomField;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.HelpdeskTag;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.HelpdeskTicket;
import com.onedirect.migrationapi.dtos.freshdesk.user.FreshdeskUser;
import com.onedirect.migrationapi.dtos.zendesk.comment.ZendeskComment;
import com.onedirect.migrationapi.dtos.zendesk.ticket.ZendeskTicket;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.enums.TicketMigrationEnum;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.pojos.BrandFieldConfiguration;
import com.onedirect.migrationapi.pojos.TicketMigrationStats;
import com.onedirect.migrationapi.services.FreshdeskService;
import com.onedirect.migrationapi.services.MigrationDataService;
import com.onedirect.migrationapi.services.PlatformMigrationService;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.io.File;
import java.util.*;

@Service
public class FreshdeskMigrationService extends PlatformMigrationService {
    @Autowired
    FreshdeskService freshdeskService;

    @Autowired
    MigrationDataService migrationDataService;

    private static Gson gson = new Gson();

    private static final Logger logger = LoggerFactory.getLogger(FreshdeskMigrationService.class);

    @Override
    public void performPreMigration(BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog,BrandFieldConfiguration brandFieldConfiguration) {
        migrateAllCustomersForBrand(brandConfigurationDto,brandFieldConfiguration);
    }

    private void migrateAllCustomersForBrand(BrandConfigurationDto brandConfigurationDto,BrandFieldConfiguration brandFieldConfiguration) {
        String usersPath = freshdeskService.createDataPath(MigrationPlatformConstants.FRESHDESK_DIR_PATH,brandConfigurationDto.getBrandId(),"",MigrationPlatformConstants.FRESHDESK_USER_FOLDER_NAME);
        File dir = new File(usersPath);
        File[] directoryListing = dir.listFiles();
        for (File child : directoryListing) {
            try {
                logger.info("Processing customers from file :: {}",child.getName());
                FreshdeskUserDto freshdeskUserDto = freshdeskService.getFreshdeskUserDtoFromFile(child);
                List<Customer> customerList = freshdeskService.buildCustomersFromFreshdeskUserDto(freshdeskUserDto,brandConfigurationDto.getBrandId());
                createCustomersAndPerformMapping(freshdeskUserDto,customerList,brandConfigurationDto,
                            brandFieldConfiguration,child.getName());
            }catch (Exception e){
                logger.info("Unable to process customers from file :: {} Exception occurred :: {}",child.getName(),e);
            }
        }
    }

    @Override
    public Boolean shouldTicketBeMigrated(Object platformTicket, TicketMigrationStats ticketMigrationStats,
                                          BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog,
                                          BrandFieldConfiguration brandFieldConfiguration) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        if(doesTicketAlreadyExist(brandConfigurationDto.getBrandId(),helpdeskTicket.getDisplayId(),brandFieldConfiguration)){
            ticketMigrationStats.setTicketsAlreadyMigrated(ticketMigrationStats.getTicketsAlreadyMigrated() + 1);
            return false;
        }
        return true;
    }

    private void createCustomersAndPerformMapping(FreshdeskUserDto freshdeskUserDto, List<Customer> customerList,
                                                  BrandConfigurationDto brandConfigurationDto,
                                                  BrandFieldConfiguration brandFieldConfiguration,
                                                  String fileName
                                                  ) {
        List<FreshdeskUser> freshdeskUserList = freshdeskUserDto.getFreshdeskUserList();
        for(int i=0;i<freshdeskUserDto.getFreshdeskUserList().size();i++){
            FreshdeskUser freshdeskUser = freshdeskUserList.get(i);
            Customer customer = customerList.get(i);
            try{
                if(Objects.isNull(getPlatformCustomerMapping(freshdeskUser.getId(),brandConfigurationDto.getId()))){
                    Customer savedCustomer = migrationDataService.addCustomer(customer);
                    String email = null;
                    if(Objects.nonNull(freshdeskUser.getEmail()) && !freshdeskUser.getEmail().isEmpty()){
                        email = freshdeskUser.getEmail();
                    }else if (Objects.nonNull(freshdeskUser.getFacebookProfileId())){
                        email = freshdeskUser.getFacebookProfileId().toString() +"@facebook.com";
                    }else if(Objects.nonNull(freshdeskUser.getTwitterId()) && !freshdeskUser.getTwitterId().isEmpty()){
                        email = freshdeskUser.getTwitterId() + "@twitter.com";
                    }
                    String phone = null;
                    if(Objects.nonNull(freshdeskUser.getPhone()) && !freshdeskUser.getPhone().isEmpty()){
                        phone = freshdeskUser.getPhone();
                    }
                    if(Objects.nonNull(freshdeskUser.getMobile()) && !freshdeskUser.getMobile().isEmpty()){
                        phone = freshdeskUser.getMobile();
                    }
                    List<CustomerLabelValue> customerLabelValueList = createCustomerLabelValues(brandFieldConfiguration,brandConfigurationDto,customer,email,phone);
                    createPlatformCustomerMapping(freshdeskUser.getId(),savedCustomer.getId(),brandConfigurationDto.getId());
                }
            }catch (Exception e){
                logger.info("There was a problem migrating customer with Freshdesk customer Id :: {} from file name :: {}  Exception : {}",freshdeskUser.getId(),fileName,e);
            }

        }
    }

    @Override
    public TicketListBo getTickets(BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog, Map<String, Object> params) {
        FreshdeskTicketsDto freshdeskTicketsDto;
        TicketListBo ticketListBo = new TicketListBo();
        Integer currentIndex;
        if(Objects.isNull(migrationLog.getFileList())){
            migrationLog.setFileList(getListOfAllTicketsJson(brandConfigurationDto.getBrandId()));
        }
        List<String> fileList = getFileListFromJson(migrationLog.getFileList());
        if(Objects.nonNull(params) && params.containsKey(MigrationPlatformConstants.PARAM_KEY_TICKET_INDEX)){
            currentIndex = (Integer) params.get(MigrationPlatformConstants.PARAM_KEY_TICKET_INDEX);
            if(currentIndex>=fileList.size()){
                return null;
            }else{
                FreshdeskTicketsDto freshdeskTicketsDto1 = freshdeskService.getFreshDeskTicketsDtoFromFile(brandConfigurationDto.getBrandId()
                        ,fileList.get(currentIndex));
                freshdeskTicketsDto = freshdeskTicketsDto1;
                params.put(MigrationPlatformConstants.PARAM_KEY_TICKET_INDEX,currentIndex+1);
                if(Objects.isNull(freshdeskTicketsDto1)){
                    return getTickets(brandConfigurationDto,migrationLog,params);
                }
                ticketListBo.setParams(params);
            }
        }else{
            currentIndex = 0;
            FreshdeskTicketsDto freshdeskTicketsDto1 = freshdeskService.getFreshDeskTicketsDtoFromFile(brandConfigurationDto.getBrandId(),fileList.get(0));
            freshdeskTicketsDto = freshdeskTicketsDto1;
            Map<String,Object> newParams = new HashMap<>();
            newParams.put(MigrationPlatformConstants.PARAM_KEY_TICKET_INDEX,1);
            if(Objects.isNull(freshdeskTicketsDto1)){
                return getTickets(brandConfigurationDto,migrationLog,newParams);
            }
            ticketListBo.setParams(newParams);
        }
        List<Object> platformTicketList = new ArrayList<>();
        platformTicketList.addAll(freshdeskTicketsDto.getHelpdeskTicketList());
        ticketListBo.setTicketList(platformTicketList);
        logger.info("Processing tickets from file :: {}",fileList.get(currentIndex));
        return ticketListBo;
    }

    private String getListOfAllTicketsJson(Integer brandId) {
        String ticketsDirPath = freshdeskService.createDataPath(MigrationPlatformConstants.FRESHDESK_DIR_PATH,brandId,
                "",MigrationPlatformConstants.FRESHDESK_TICKETS_FOLDER_NAME);
        File dir = new File(ticketsDirPath);
        List<String> filenames = new ArrayList<>();
        if(dir.exists() && dir.listFiles().length==0){
            throw new CustomInternalServerException(ErrorCodes.FRESHDESK_TICKETS_NOT_FOUND.getMessage(),ErrorCodes.FRESHDESK_TICKETS_NOT_FOUND);
        }
        for(File child: Objects.requireNonNull(dir.listFiles())){
            filenames.add(FilenameUtils.getBaseName(child.getName()));
        }
        return gson.toJson(filenames);
    }

    private List<String> getFileListFromJson(String fileList) {
        return gson.fromJson(fileList,new TypeToken<List<String>>(){}.getType());
    }

    @Override
    public void validateMigrationRequest(MigrationRequestDto migrationRequestDto,
                                         BrandConfigurationEntity brandConfigurationEntity,
                                         BrandFieldConfiguration brandFieldConfiguration
                                         ) {
        if(!freshdeskService.doTicketsExistForBrand(brandConfigurationEntity.getBrandId())){
            logger.info("Data not found for brand");
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Data not found for brand");
        }
        if(Objects.isNull(brandFieldConfiguration.getEmailCustomerFieldId())){
            logger.info("Email customer field not configured for brand");
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Email customer field not configured for brand");
        }
    }

    @Override
    public ConversationListBo getConversationsForTicket(Object ticket, BrandConfigurationDto brandConfigurationDto) {
        //TODO : Add a source check to include only relevant conversations
        ConversationListBo conversationListBo = new ConversationListBo();
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)ticket;
        HelpdeskNote firstConversationNote = createFirstNoteFromTicket(helpdeskTicket);
        List<Object> platformConversationList = new ArrayList<>();
        platformConversationList.add(firstConversationNote);
        for(HelpdeskNote helpdeskNote: helpdeskTicket.getNotes()){
            if (helpdeskNote.getSource()!=4){
                platformConversationList.add(helpdeskNote);
            }
        }
        conversationListBo.setPlatformConversations(platformConversationList);
        return conversationListBo;
    }

    private HelpdeskNote createFirstNoteFromTicket(HelpdeskTicket helpdeskTicket) {
        return freshdeskService.createFirstHelpdeskNoteFromTicket(helpdeskTicket);
    }

    @Override
    public void createTicketFailureMigrationLog(Integer brandID,Integer migrationLogId, Object platformTicket, Exception e) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket) platformTicket;
        try{
            CustomInternalServerException exception = (CustomInternalServerException)e;
            logger.info("Migration service error for brand id :: {} and Freshdesk Ticket ID :: {} Error code :: {}  Error message :: {}",
                    brandID,helpdeskTicket.getDisplayId(), exception.getErrorCode().getCode(), exception.getErrorCode().getMessage());
        }catch (Exception ex){
            logger.info("An unexpected error occurred while migrating ticket for brand id :: {} with id :: {} error :: {} ",brandID,helpdeskTicket.getDisplayId(),Arrays.toString(e.getStackTrace()));
        }
        migrationDataService.createTicketMigrationLog(migrationLogId,helpdeskTicket.getDisplayId().longValue(), null, null, TicketMigrationEnum.FAILED);
    }

    @Override
    public PlatformCustomerMappingEntity getPlatformCustomerMapping(Object platformTicket, BrandConfigurationDto brandConfigurationDto) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        return getPlatformCustomerMapping(helpdeskTicket.getRequesterId(),brandConfigurationDto.getId());
    }

    @Override
    public CustomerBo getCustomerForTicket(Object platformTicket, BrandConfigurationDto brandConfigurationDto) {
        throw new CustomInternalServerException("Freshdesk customer does not exist for given ticket", ErrorCodes.FRESHDESK_CUSTOMER_DOES_NOT_EXIST);
    }

    @Override
    public Customer createCustomerFromPlatformCustomer(CustomerBo platformCustomer, BrandConfigurationDto brandConfigurationDto) {
        return null;
    }

    @Override
    public List<CustomerLabelValue> createCustomerLabelValue(Customer customer, CustomerBo platformCustomer, BrandConfigurationDto brandConfigurationDto, BrandFieldConfiguration brandFieldConfiguration) {
        return null;
    }

    @Override
    public Long getBrandUserId(Object platformTicket, BrandConfigurationDto brandConfigurationDto) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket) platformTicket;
        return getBrandUserId(helpdeskTicket.getResponderId(),brandConfigurationDto.getDefaultAgentId(),brandConfigurationDto.getId());
    }

    @Override
    public List<TicketTag> createTicketTagsForPlatformTicket(Object platformTicket, Ticket ticket, Integer brandId, BrandFieldConfiguration brandFieldConfiguration) {
        List<TicketTag> ticketTagList = super.createTicketTagsForPlatformTicket(platformTicket, ticket, brandId, brandFieldConfiguration);
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        if(Objects.nonNull(brandFieldConfiguration.getTicketTagMap())){
            Map<String,Integer> ticketTagMap = brandFieldConfiguration.getTicketTagMap();
            for(HelpdeskTag helpdeskTag:helpdeskTicket.getHelpdeskTagList()){
                Integer ticketTagId = ticketTagMap.get(helpdeskTag.getName());
                if(Objects.nonNull(ticketTagId)){
                    ticketTagList.add(migrationDataService.buildTicketTagFromTicketId(ticket,brandId,ticketTagId));
                }

            }
        }
        return ticketTagList;
    }

    @Override
    public ThirdPartyData createThirdPartyDataForTicket(Ticket ticket, Object firstConversation) {
        HelpdeskNote helpdeskNote = (HelpdeskNote)firstConversation;
        String description = ((Objects.nonNull(helpdeskNote.getBodyHtml())) && (!helpdeskNote.getBodyHtml().isEmpty()))?helpdeskNote.getBodyHtml():".";
        return createThirdPartyData(ticket,description);
    }

    @Override
    public QueuedAttachmentsDto createQueuedAttachmentDto(Object platformConversation, Ticket ticket, ThirdPartyData thirdPartyData, BrandConfigurationDto brandConfigurationDto, ForwardFeed forwardFeed) {
        HelpdeskNote helpdeskNote = (HelpdeskNote) platformConversation;
        if(Objects.nonNull(helpdeskNote.getFreshdeskAttachmentList())
                && (helpdeskNote.getFreshdeskAttachmentList().size() != 0)){
            if(Objects.nonNull(forwardFeed)){
                return createQueuedAttachmentDto(brandConfigurationDto.getBrandId(),
                        ticket.getId(),forwardFeed.getId(),
                        null,helpdeskNote,forwardFeed.getCreatedAt(),
                        forwardFeed.getUpdatedAt(),brandConfigurationDto.getPlatformId());
            }else{
                return createQueuedAttachmentDto(brandConfigurationDto.getBrandId() , ticket.getId(),
                        null,thirdPartyData.getId(),
                        helpdeskNote,thirdPartyData.getCreatedAt(),
                        thirdPartyData.getUpdatedAt(),brandConfigurationDto.getPlatformId());
            }
        }
        return null;
    }

    private QueuedAttachmentsDto createQueuedAttachmentDto(Integer brandId, Long ticketId, Long forwardFeedId,
                                                           Long thirdPartyDataId,
                                                           HelpdeskNote helpdeskNote, Date createdAt, Date updatedAt,
                                                           Integer platformId) {
        return migrationDataService.createQueuedAttachmentDto(brandId,ticketId,forwardFeedId,
                thirdPartyDataId,helpdeskNote.getId(),
                createdAt,updatedAt,platformId,gson.toJson(helpdeskNote.getFreshdeskAttachmentList()));
    }

    @Override
    public List<ForwardFeedAttachmentDto> uploadAttachmentsForForwardFeed(String attachmentListJson, Integer brandId) {
        List<FreshdeskAttachment> freshdeskAttachmentList = freshdeskService.getFreshdeskAttachmentsFromJson(attachmentListJson);
        return freshdeskService.createForwardFeedAttachmentDtoList(freshdeskAttachmentList,brandId);
    }

    @Override
    public ForwardFeed createForwardFeed(Ticket ticket, Object platformConversation, Object platformTicket) {
        HelpdeskNote helpdeskNote = (HelpdeskNote)platformConversation;
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        return freshdeskService.generateForwardFeedEntity(ticket,helpdeskNote,helpdeskTicket);
    }

    @Override
    public ForwardCustomerInfoValueJsonDto createForwardCustomerInfoValueDto(Object platformTicket,
                                                                             Object platformConversation,
                                                                             BrandConfigurationDto brandConfigurationDto,
                                                                             Long customerId,
                                                                             BrandFieldConfiguration brandFieldConfiguration
                                                                             ) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        HelpdeskNote helpdeskNote = (HelpdeskNote)platformConversation;
        Customer customer = migrationDataService.getCustomerById(customerId);
        CustomerLabelValue customerLabelValue = getCustomerLabelValueForCustomerIdAndFieldId(customerId,
                brandFieldConfiguration.getEmailCustomerFieldId().intValue());
        String email = customer.getName() + "@noemail.com";
        if(Objects.nonNull(customerLabelValue)){
            email = customerLabelValue.getCustomerLabelText();
        }
        return generateValueJsonForForwardCustomerInfoDto(helpdeskNote.get_private(),!helpdeskNote.getIncoming(),
                customer.getName(),email,brandConfigurationDto);
    }

    @Override
    public void createTicketSuccessMigrationLog(Integer migrationLogId, Ticket ticket, Object platformTicket) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket) platformTicket;
        migrationDataService.createTicketMigrationLog(migrationLogId, helpdeskTicket.getDisplayId(),
                ticket.getBrandTicketId(), ticket.getId(), TicketMigrationEnum.SUCCESS);
    }

    @Override
    public Ticket createTicketFromPlatformTicket(Object platformTicket, Integer brandId, Long oneDirectCustomerId,
                                                 Integer brandUserId, Long latestBrandTicketId) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        return freshdeskService.buildTicketFromHelpdeskTicket(helpdeskTicket,brandId,oneDirectCustomerId,brandUserId
                ,latestBrandTicketId);
    }

    @Override
    public Map<String, String> uploadAttachmentsForThirdPartyData(String attachmentListJson, Integer brandId) {
        List<FreshdeskAttachment> freshdeskAttachmentList = freshdeskService.getFreshdeskAttachmentsFromJson(attachmentListJson);
        return freshdeskService.uploadAttachments(freshdeskAttachmentList,brandId);
    }

    @Override
    public PlatformCustomerMappingEntity createPlatformCustomerMapping(Object platformCustomer, BrandConfigurationDto brandConfigurationDto, Customer customer) {
        return null;
    }

    @Override
    public TicketFieldValue getPlatformTicketIdTicketField(Ticket ticket, Integer brandId, Object platformTicket, BrandFieldConfiguration brandFieldConfiguration) {
        Long labelIdForFreshdeskTicketId = brandFieldConfiguration.getPlatformTicketIdTicketFieldId();
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        return getPlatformTicketIdTicketField(labelIdForFreshdeskTicketId,ticket,brandId,helpdeskTicket.getDisplayId());
    }

    @Override
    public List<CustomFieldBo> getCustomFieldBoList(Object platformTicket) {
        HelpdeskTicket helpdeskTicket = (HelpdeskTicket)platformTicket;
        List<CustomFieldBo> customFieldBoList = new ArrayList<>();
        for(FreshdeskCustomField freshdeskCustomField:helpdeskTicket.getCustomFieldList()){
            customFieldBoList.add(new CustomFieldBo(freshdeskCustomField.getKey(),freshdeskCustomField.getValue()));
        }
        customFieldBoList.add(new CustomFieldBo(MigrationPlatformConstants.FRESHDESK_ATTRIBUTE_TICKET_TYPE,helpdeskTicket.getTicketType()));
        return customFieldBoList;
    }
}

package com.onedirect.migrationapi.utils;

import com.onedirect.migrationapi.configs.SlackConfig;
import com.onedirect.migrationapi.dtos.SlackNotificationDto;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * @author jp
 */

@Component
public class SlackNotificationUtil {

    private static final Logger LOG = LoggerFactory.getLogger(SlackNotificationUtil.class);

    private SlackConfig slackConfig;

    @Autowired
    private SlackNotificationUtil(SlackConfig slackConfig) {
        this.slackConfig = slackConfig;
    }

    private List<String> getTargetUsers() {
        String allTagUserList = slackConfig.getUsers();
        return Arrays.asList(allTagUserList.split(","));
    }

    private SlackNotificationDto generateSlackNotificationDto(
            String endPoint, String message, String description) {
        return new SlackNotificationDto(
                "Migration Service",
                endPoint,
                message,
                description,
                getTargetUsers(),
                slackConfig.getChannelName());
    }

    public void generateSlackNotification(String endPoint, String message, String description) {
        SlackNotificationRunnerThread slackNotificationRunnerThread =
                new SlackNotificationRunnerThread(
                        generateSlackNotificationDto(endPoint, message, description), slackConfig.getUrl());
        slackNotificationRunnerThread.start();
    }

    public void exceptionSlackNotification(String endPoint, String message, Exception ex) {
        SlackNotificationRunnerThread runnerThread =
                new SlackNotificationRunnerThread(
                        generateSlackNotificationDto(endPoint, message, ExceptionUtils.getStackTrace(ex)),
                        slackConfig.getUrl());
        runnerThread.start();
    }

    private class SlackNotificationRunnerThread extends Thread {

        private String url;
        private SlackNotificationDto slackNotificationDto;

        SlackNotificationRunnerThread(SlackNotificationDto slackNotificationDto, String url) {
            this.slackNotificationDto = slackNotificationDto;
            this.url = url;
        }

        @Override
        public void run() {
            try {
                HttpClientUtil.post(url, slackNotificationDto, String.class, null);
            } catch (Exception exception) {
                LOG.error("Exception Sending Slack Notification ::: ", exception);
            }
        }
    }
}

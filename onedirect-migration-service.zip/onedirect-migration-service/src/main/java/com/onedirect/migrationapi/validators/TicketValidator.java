package com.onedirect.migrationapi.validators;

import com.onedirect.migrationapi.entities.Ticket;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;

public class TicketValidator {

    private static TicketValidator ticketValidator = null;

    private TicketValidator() {

    }

    public static TicketValidator getInstance(){
        if(ticketValidator==null){
            return new TicketValidator();
        }
        return ticketValidator;
    }

    public void validateTicketRequest(Ticket createTicketDto) throws CustomInternalServerException {
        StringBuilder errorMessage = new StringBuilder();
        if (createTicketDto == null) {
            throw new CustomInternalServerException("Request Object cannot be null", ErrorCodes.INVALID_TICKET_CREATION_REQUEST);
        } else {
            if (createTicketDto.getCustomerId() == null) {
                errorMessage.append("CustomerId cannot be empty.");
            }
//            if (createTicketDto.getRequesterId() != null) {
//                errorMessage.append("Requester Id is not accepted for creating parent ticket.");
//            }
            if (createTicketDto.getSource() == null) {
                errorMessage.append("Source cannot be null and it should be in between 0 and 22.");
            }
            errorMessage = baseValidateTicket(createTicketDto, errorMessage);

            if (errorMessage.length() > 0) {
                throw new CustomInternalServerException(errorMessage.toString(),ErrorCodes.INVALID_TICKET_INFO);
            }
        }
    }

    private StringBuilder baseValidateTicket(Ticket createTicketDto,
                                             StringBuilder errorMessage) {
        if (createTicketDto.getShortDesc() != null && createTicketDto.getShortDesc().length() > 250) {
            errorMessage.append("Short description cannot exceed 250 characters");
        }
        if (createTicketDto.getCurrentStatus() == null) {
            errorMessage.append("Status cannot be null and it should be in between 0 and 4.");
        }
        if (createTicketDto.getCurrentPriority() == null) {
            errorMessage.append("Priority cannot be null and it should be in between 0 and 3.");
        }
        if (createTicketDto.getTicketType() == null) {
            errorMessage.append("Ticket type cannot be null and it should be in between 0 and 2");
        }
//        if (createTicketDto.getTicketUrl() != null && createTicketDto.getTicketUrl().length()
//                > 1000) {
//            errorMessage.append("Ticket url should not exceed 1000 characters.");
//        }
        return errorMessage;
    }
}

package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoSkillMap {

    private String name;
    private String description;
    private String status;
    private Long skillTypeId;
    private ZohoCriteria criteria;
    private List<Long> agentIds;
}

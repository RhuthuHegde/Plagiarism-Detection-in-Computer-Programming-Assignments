package com.onedirect.migrationapi.dtos.freshdesk;

import com.onedirect.migrationapi.dtos.freshdesk.ticket.HelpdeskTicket;

import java.util.List;

public class FreshdeskTicketsDto {
    private List<HelpdeskTicket> helpdeskTicketList;

    public List<HelpdeskTicket> getHelpdeskTicketList() {
        return helpdeskTicketList;
    }

    public void setHelpdeskTicketList(List<HelpdeskTicket> helpdeskTicketList) {
        this.helpdeskTicketList = helpdeskTicketList;
    }

    @Override
    public String toString() {
        return "FreshdeskTicketsDto{" +
                "helpdeskTicketList=" + helpdeskTicketList +
                '}';
    }
}

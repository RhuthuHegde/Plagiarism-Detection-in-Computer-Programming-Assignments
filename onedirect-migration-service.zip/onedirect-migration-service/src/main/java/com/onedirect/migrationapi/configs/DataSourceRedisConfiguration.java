package com.onedirect.migrationapi.configs;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.*;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @author jp
 */

@Configuration
@ConfigurationProperties(prefix = "redis.config")
@PropertySources(value = {@PropertySource("classpath:dataSourcesConfig.properties")})
public class DataSourceRedisConfiguration {

    private String hostName;
    private Integer port;
    private Integer dbCompartment;
    private String password;

    @Bean
    JedisConnectionFactory jedisConnectionFactory() {
        final JedisConnectionFactory connectionFactory = new JedisConnectionFactory();
        connectionFactory.setDatabase(dbCompartment);
        connectionFactory.setHostName(hostName);
        connectionFactory.setPort(port);
        connectionFactory.setPoolConfig(new JedisPoolConfig());
        connectionFactory.setUsePool(true);
        connectionFactory.setPassword(password);
        return connectionFactory;
    }

    @Bean
    RedisTemplate<String, String> redisTemplate() {
        final RedisTemplate<String, String> template = new RedisTemplate<String, String>();
        template.setConnectionFactory(jedisConnectionFactory());
        template.setDefaultSerializer(new StringRedisSerializer());
        return template;
    }

    @Bean
    RedisTemplate<String, Object> objectRedisTemplate() {
        final RedisTemplate<String, Object> template = new RedisTemplate<String, Object>();
        template.setConnectionFactory(jedisConnectionFactory());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new JdkSerializationRedisSerializer());
        return template;
    }

    @Bean
    @Primary
    RedisTemplate<Object, Object> template(RedisConnectionFactory connectionFactory) {
        RedisTemplate<Object, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(connectionFactory);
        return template;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public Integer getDbCompartment() {
        return dbCompartment;
    }

    public void setDbCompartment(Integer dbCompartment) {
        this.dbCompartment = dbCompartment;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

package com.onedirect.migrationapi.repos.migration.slave.zohorepo.agent;

import com.onedirect.migrationapi.entities.zoho.ZohoAgent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ZohoAgentRepo extends JpaRepository<ZohoAgent,Long> {
    @Query("SELECT za from ZohoAgent za WHERE za.id=?1")
    ZohoAgent findZohoAgentByID(Long ID);
}

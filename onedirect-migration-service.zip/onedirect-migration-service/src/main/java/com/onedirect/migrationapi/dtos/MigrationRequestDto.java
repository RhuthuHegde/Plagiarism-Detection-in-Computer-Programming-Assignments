package com.onedirect.migrationapi.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.io.Serializable;
import java.util.List;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class MigrationRequestDto implements Serializable {

    @JsonProperty("start_time")
    private Long startTime;

    @JsonProperty("brand_id")
    private Integer brandId;

    @JsonProperty("end_time")
    private Long endTime;

    @JsonProperty("number_of_tickets")
    private Long numberOfTickets;

    @JsonProperty("platform_id")
    private Integer platformId;

    @JsonProperty("file_names")
    private List<String> fileNames;

}

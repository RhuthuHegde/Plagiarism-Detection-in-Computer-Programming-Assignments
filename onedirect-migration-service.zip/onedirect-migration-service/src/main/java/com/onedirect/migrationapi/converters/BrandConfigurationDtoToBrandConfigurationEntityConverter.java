package com.onedirect.migrationapi.converters;

import com.onedirect.migrationapi.dtos.BrandConfigurationDto;
import com.onedirect.migrationapi.entities.BrandConfigurationEntity;
import com.onedirect.migrationapi.utils.GenericBuilder;

import java.util.Date;

/**
 * @author jp
 */
public class BrandConfigurationDtoToBrandConfigurationEntityConverter extends GenericMigrationServiceConverter<BrandConfigurationDto, BrandConfigurationEntity>{
    public BrandConfigurationDtoToBrandConfigurationEntityConverter() {
        super(brandConfigurationDto -> {
            if(brandConfigurationDto == null){
                return null;
            }
            return GenericBuilder.of(BrandConfigurationEntity::new)
                    .with(BrandConfigurationEntity::setId, brandConfigurationDto.getId() == null ? null : brandConfigurationDto.getId())
                    .with(BrandConfigurationEntity::setBrandId, brandConfigurationDto.getBrandId())
                    .with(BrandConfigurationEntity::setBrandSupportName, brandConfigurationDto.getBrandSupportName())
                    .with(BrandConfigurationEntity::setBrandSupportAddress, brandConfigurationDto.getBrandSupportAddress())
                    .with(BrandConfigurationEntity::setPlatformDomain, brandConfigurationDto.getPlatformDomain())
                    .with(BrandConfigurationEntity::setPlatformId, brandConfigurationDto.getPlatformId())
                    .with(BrandConfigurationEntity::setPlatformAuthorizationKey, brandConfigurationDto.getPlatformAuthorizationKey())
                    .with(BrandConfigurationEntity::setRecordStatus, brandConfigurationDto.getRecordStatus())
                    .with(BrandConfigurationEntity::setIsMigrationEnabled, brandConfigurationDto.getIsMigrationEnabled())
                    .with(BrandConfigurationEntity::setCreatedAt, brandConfigurationDto.getCreatedAt())
                    .with(BrandConfigurationEntity::setUpdatedAt, new Date())
                    .with(BrandConfigurationEntity::setDefaultAgentId,brandConfigurationDto.getDefaultAgentId())
                    .build();

        }, null);
    }
}

package com.onedirect.migrationapi.dtos.zendesk.branduser;

import java.util.List;

import com.fasterxml.jackson.annotation.*;
import com.onedirect.migrationapi.dtos.zendesk.ZendeskAttachment;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskUser {

    @JsonProperty("id")
    private Long id;
    @JsonProperty("url")
    private String url;
    @JsonProperty("name")
    private String name;
    @JsonProperty("email")
    private String email;
    @JsonProperty("created_at")
    private String createdAt;
    @JsonProperty("updated_at")
    private String updatedAt;
    @JsonProperty("time_zone")
    private String timeZone;
    @JsonProperty("iana_time_zone")
    private String ianaTimeZone;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("shared_phone_number")
    private Boolean sharedPhoneNumber;
    @JsonProperty("photo")
    private ZendeskAttachment photo;
    @JsonProperty("locale_id")
    private Integer localeId;
    @JsonProperty("locale")
    private String locale;
    @JsonProperty("organization_id")
    private Long organizationId;
    @JsonProperty("role")
    private String role;
    @JsonProperty("verified")
    private Boolean verified;
    @JsonProperty("external_id")
    private String externalId;
    @JsonProperty("tags")
    private List<Object> tags = null;
    @JsonProperty("alias")
    private String alias;
    @JsonProperty("active")
    private Boolean active;
    @JsonProperty("shared")
    private Boolean shared;
    @JsonProperty("shared_agent")
    private Boolean sharedAgent;
    @JsonProperty("last_login_at")
    private String lastLoginAt;
    @JsonProperty("two_factor_auth_enabled")
    private Boolean twoFactorAuthEnabled;
    @JsonProperty("signature")
    private String signature;
    @JsonProperty("details")
    private String details;
    @JsonProperty("notes")
    private String notes;
    @JsonProperty("role_type")
    private Integer roleType;
    @JsonProperty("custom_role_id")
    private Long customRoleId;
    @JsonProperty("moderator")
    private Boolean moderator;
    @JsonProperty("ticket_restriction")
    private String ticketRestriction;
    @JsonProperty("only_private_comments")
    private Boolean onlyPrivateComments;
    @JsonProperty("restricted_agent")
    private Boolean restrictedAgent;
    @JsonProperty("suspended")
    private Boolean suspended;
    @JsonProperty("default_group_id")
    private Long defaultGroupId;
    @JsonProperty("report_csv")
    private Boolean reportCsv;
    @JsonProperty("user_fields")
    private ZendeskUserFields userFields;
}

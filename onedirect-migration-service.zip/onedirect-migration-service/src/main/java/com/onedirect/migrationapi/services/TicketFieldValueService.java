package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.TicketFieldValue;

import java.util.List;

public interface TicketFieldValueService {
    public TicketFieldValue addTicketFieldValue(TicketFieldValue ticketFieldValue);
    public List<TicketFieldValue> getTicketFieldValueForGivenValue(Integer brandId, String value, Integer fieldId);
}

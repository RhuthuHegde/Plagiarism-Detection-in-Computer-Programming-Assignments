package com.onedirect.migrationapi.dtos.freshdesk.ticket;

import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskAttachment;
import com.onedirect.migrationapi.dtos.freshdesk.conversation.HelpdeskNote;

import java.util.List;

public class HelpdeskTicket {
    private String createdAt;
    private String description;
    private String descriptionHtml;
    private String ticketType;
    private Long displayId;
    private Long requesterId;
    private Long responderId;
    private Integer source;
    private Integer status;
    private String subject;
    private String updatedAt;
    private Integer priority;
    private List<HelpdeskNote> notes;
    private List<FreshdeskAttachment> freshdeskAttachmentList;
    private List<HelpdeskTag> helpdeskTagList;
    private List<FreshdeskCustomField> customFieldList;

    @Override
    public String toString() {
        return "HelpdeskTicket{" +
                "createdAt='" + createdAt + '\'' +
                ", description='" + description + '\'' +
                ", descriptionHtml='" + descriptionHtml + '\'' +
                ", ticketType='" + ticketType + '\'' +
                ", displayId=" + displayId +
                ", requesterId=" + requesterId +
                ", responderId=" + responderId +
                ", source=" + source +
                ", status=" + status +
                ", subject='" + subject + '\'' +
                ", updatedAt='" + updatedAt + '\'' +
                ", priority=" + priority +
                ", notes=" + notes +
                ", freshdeskAttachmentList=" + freshdeskAttachmentList +
                ", helpdeskTagList=" + helpdeskTagList +
                ", customFieldList=" + customFieldList +
                '}';
    }

    public String getTicketType() {
        return ticketType;
    }

    public void setTicketType(String ticketType) {
        this.ticketType = ticketType;
    }

    public String getDescriptionHtml() {
        return descriptionHtml;
    }

    public void setDescriptionHtml(String descriptionHtml) {
        this.descriptionHtml = descriptionHtml;
    }

    public List<FreshdeskCustomField> getCustomFieldList() {
        return customFieldList;
    }

    public void setCustomFieldList(List<FreshdeskCustomField> customFieldList) {
        this.customFieldList = customFieldList;
    }

    public List<FreshdeskAttachment> getFreshdeskAttachmentList() {
        return freshdeskAttachmentList;
    }

    public void setFreshdeskAttachmentList(List<FreshdeskAttachment> freshdeskAttachmentList) {
        this.freshdeskAttachmentList = freshdeskAttachmentList;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getDisplayId() {
        return displayId;
    }

    public void setDisplayId(Long displayId) {
        this.displayId = displayId;
    }

    public Long getRequesterId() {
        return requesterId;
    }

    public void setRequesterId(Long requesterId) {
        this.requesterId = requesterId;
    }

    public Long getResponderId() {
        return responderId;
    }

    public void setResponderId(Long responderId) {
        this.responderId = responderId;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public List<HelpdeskNote> getNotes() {
        return notes;
    }

    public void setNotes(List<HelpdeskNote> notes) {
        this.notes = notes;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public List<HelpdeskTag> getHelpdeskTagList() {
        return helpdeskTagList;
    }

    public void setHelpdeskTagList(List<HelpdeskTag> helpdeskTagList) {
        this.helpdeskTagList = helpdeskTagList;
    }
}

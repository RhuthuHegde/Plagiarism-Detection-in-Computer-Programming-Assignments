package com.onedirect.migrationapi.converters;

import com.onedirect.migrationapi.dtos.MigrationLogDto;
import com.onedirect.migrationapi.entities.MigrationLog;
import com.onedirect.migrationapi.utils.GenericBuilder;

import java.util.Date;

/**
 * @author jp
 */
public class MigrationLogToMigrationLogDtoEntityConverter extends GenericMigrationServiceConverter<MigrationLog ,MigrationLogDto>{
    public MigrationLogToMigrationLogDtoEntityConverter() {
        super(migrationLog -> {
            if(migrationLog == null){
                return null;
            }
            return GenericBuilder.of(MigrationLogDto::new)
                    .with(MigrationLogDto::setId, migrationLog.getId() == null ? null : Integer.valueOf(migrationLog.getId()))
                    .with(MigrationLogDto::setBrandConfigurationId, migrationLog.getBrandConfigurationId())
                    .with(MigrationLogDto::setRecordStatus, migrationLog.getRecordStatus())
                    .with(MigrationLogDto::setMigrationStatus, migrationLog.getMigrationStatus())
                    .with(MigrationLogDto::setStartTimestamp, migrationLog.getStartTimestamp())
                    .with(MigrationLogDto::setEndTimestamp, migrationLog.getEndTimestamp())
                    .with(MigrationLogDto::setCreatedAt, migrationLog.getCreatedAt())
                    .with(MigrationLogDto::setUpdatedAt, new Date())
                    .with(MigrationLogDto::setNumberOfTickets,migrationLog.getNumberOfTickets())
                    .build();

        }, null);
    }
}

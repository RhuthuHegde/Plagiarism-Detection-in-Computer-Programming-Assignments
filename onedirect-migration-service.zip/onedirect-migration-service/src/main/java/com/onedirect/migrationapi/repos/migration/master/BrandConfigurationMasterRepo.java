package com.onedirect.migrationapi.repos.migration.master;

import com.onedirect.migrationapi.entities.BrandConfigurationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author jp
 */

public interface BrandConfigurationMasterRepo extends JpaRepository<BrandConfigurationEntity, Integer> {

}

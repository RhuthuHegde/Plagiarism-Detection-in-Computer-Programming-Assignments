package com.onedirect.migrationapi.entities;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "ticket_migration_log")
public class TicketMigrationLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name ="migration_log_id")
    private Integer migrationLogId;

    @Column(name = "platform_ticket_id")
    private Long platformTicketId;

    @Column(name = "brand_ticket_id")
    private Long brandTicketId;

    @Column(name = "onedirect_ticket_id")
    private Long oneDirectTicketId;

    @Column(name = "status")
    private Byte status;

    @Column(name = "created_at")
    private Date createdAt;
}

package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.ForwardFeedReferenceIds;

public interface ForwardFeedReferenceIdsService {
    public ForwardFeedReferenceIds createForwardFeedReferenceIds(ForwardFeedReferenceIds forwardFeedReferenceIds);
}

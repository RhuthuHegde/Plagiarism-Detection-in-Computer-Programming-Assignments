package com.onedirect.migrationapi.repos.migration.slave;

import com.onedirect.migrationapi.entities.PlatformAgentMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PlatformAgentMappingRepo extends JpaRepository<PlatformAgentMapping,Long> {
    @Query(value = "SELECT adz FROM PlatformAgentMapping adz WHERE adz.platformAssigneeId =?1 AND adz.brandConfigurationId=?2")
    PlatformAgentMapping findPlatformAgentMappingByAssigneeIdAndBrandConfigurationId(Long assigneeId,Integer brandConfigurationId);
}

package com.onedirect.migrationapi.entities.zoho.agentcomment;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoCommenter {
private String name;
private String firstName;
private String lastName;
private String roleName;
private String email;
private String type;
private String photoURL;
}

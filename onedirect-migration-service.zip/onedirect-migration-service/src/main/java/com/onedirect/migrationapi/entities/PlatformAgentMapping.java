package com.onedirect.migrationapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "platform_agent_mapping")
public class PlatformAgentMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "platform_assignee_id")
    private Long platformAssigneeId;

    @Column(name = "email")
    private String email;

    @Column(name = "brand_user_id")
    private Long brandUserId;

    @Column(name = "brand_configuration_id")
    private Integer brandConfigurationId;
}

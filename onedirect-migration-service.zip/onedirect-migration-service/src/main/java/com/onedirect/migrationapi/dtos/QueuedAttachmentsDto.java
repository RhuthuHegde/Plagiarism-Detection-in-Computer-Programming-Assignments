package com.onedirect.migrationapi.dtos;

import lombok.*;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@ToString
@NoArgsConstructor
public class QueuedAttachmentsDto {
    Integer brandId;

    Long ticketId;

    Long forwardFeedId;

    Long platformConversationId;

    Long thirdPartyDataId;

    Integer platformId;

    Date createdAt;

    Date updatedAt;

    String attachmentListJson;

}

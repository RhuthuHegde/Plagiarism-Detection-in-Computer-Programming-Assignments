package com.onedirect.migrationapi.pojos;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PlatformTicketFieldOption extends TicketFieldOption{
    private String platformOptionValue;
    public PlatformTicketFieldOption(String optionValue, Long optionId, String platformOptionValue) {
        super(optionValue, optionId);
        this.platformOptionValue = platformOptionValue;
    }
}

package com.onedirect.migrationapi.entities.zoho.contact;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoContactDto {

        private ZohoContact contact;

}
package com.onedirect.migrationapi.pojos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BrandFieldConfiguration {
    private BrandTicketFieldConfiguration brandTicketFieldConfiguration;
    private List<Long>  presetTags;
    private Map<String,Integer> ticketTagMap;
    private Long emailCustomerFieldId;
    private Long phoneCustomerFieldId;
    private Long platformTicketIdTicketFieldId;

}

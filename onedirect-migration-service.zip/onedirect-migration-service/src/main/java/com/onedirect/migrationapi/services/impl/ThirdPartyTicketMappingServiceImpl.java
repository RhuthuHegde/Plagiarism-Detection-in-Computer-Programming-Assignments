package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.ThirdPartyTicketMapping;
import com.onedirect.migrationapi.repos.onedirect.master.ThirdPartyTicketMappingRepo;
import com.onedirect.migrationapi.services.ThirdPartyTicketMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ThirdPartyTicketMappingServiceImpl implements ThirdPartyTicketMappingService {

    @Autowired
    ThirdPartyTicketMappingRepo thirdPartyTicketMappingRepo;

    @Override
    public ThirdPartyTicketMapping addThirdPartyTicketMapping(ThirdPartyTicketMapping thirdPartyTicketMapping) {
        return thirdPartyTicketMappingRepo.save(thirdPartyTicketMapping);
    }
}

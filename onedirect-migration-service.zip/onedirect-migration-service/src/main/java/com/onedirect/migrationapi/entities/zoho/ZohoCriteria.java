package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoCriteria {
     private List<ZohoFieldConditions> fieldConditions;
     private String pattern;
}

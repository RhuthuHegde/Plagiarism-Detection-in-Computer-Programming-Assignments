package com.onedirect.migrationapi.converters;

import java.util.Collection;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author jp
 */
public abstract class GenericMigrationServiceConverter<Ttype, Utype> {
    private final Function<Ttype, Utype> fromDto;
    private final Function<Utype, Ttype> toDto;

    public GenericMigrationServiceConverter(Function<Ttype, Utype> fromDto, Function<Utype, Ttype> toDto) {
        this.fromDto = fromDto;
        this.toDto = toDto;
    }

    public final Ttype convertFromUDtoToTDto(final Utype uType) {
        return toDto.apply(uType);
    }

    public final Utype convertFromTDtoToUDto(final Ttype tType) {
        return fromDto.apply(tType);
    }

    public final List<Utype> createTtypeToListOfUtype(final Collection<Ttype> dtoCustomers) {
        return dtoCustomers.stream().map(this::convertFromTDtoToUDto).collect(Collectors.toList());
    }

    public final List<Ttype> createUtypesToListOfTtype(final Collection<Utype> dtoCustomers) {
        return dtoCustomers.stream().map(this::convertFromUDtoToTDto).collect(Collectors.toList());
    }
}

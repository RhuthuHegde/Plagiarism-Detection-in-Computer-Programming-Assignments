package com.onedirect.migrationapi.services;

import org.xml.sax.helpers.DefaultHandler;

public interface XMLFileReaderService {
    void readAndParseXMLFileWithHandler(String path, DefaultHandler handler);
}

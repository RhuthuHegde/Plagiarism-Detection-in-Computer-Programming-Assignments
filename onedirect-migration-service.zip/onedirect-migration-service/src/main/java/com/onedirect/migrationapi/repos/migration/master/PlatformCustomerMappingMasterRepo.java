package com.onedirect.migrationapi.repos.migration.master;

import com.onedirect.migrationapi.entities.PlatformCustomerMappingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PlatformCustomerMappingMasterRepo extends JpaRepository<PlatformCustomerMappingEntity,Long> {

}

package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.dtos.FileMetaData;
import com.onedirect.migrationapi.dtos.StorageObject;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.services.FileTransferService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

/**
 * @author jp
 */

@Service
public class FileTransferServiceImpl implements FileTransferService {

    @Value("${migrationapi.gcp.bucketName}")
    private String migrationBucketName;

    @Autowired
    private GoogleStorageService googleStorageService;

    private static final Logger logger = LoggerFactory.getLogger(FileTransferServiceImpl.class);

    @Override
    public String migrateAttachment(Integer brandId, String attachmentUrl, String fileName) {
        InputStream inputStream = downloadFile(attachmentUrl);
        String uploadedFileUrl = uploadFileToGCP(brandId, inputStream, fileName);
        return uploadedFileUrl;
    }

    public String uploadFileToGCP(Integer brandId, InputStream inputStream, String fileName) {
        FileMetaData fileMetaData = null;
        try {
            StorageObject storageObject = createStorageObject(brandId, migrationBucketName, fileName);
            fileMetaData = googleStorageService.upload(inputStream, storageObject);
            logger.info("[GCP Upload] Successfully uploaded to GCP with filename : {} ," +
                    " with location {}", fileName, storageObject.getUniqueName());
        }  catch (Exception gcpException) {
            logger.error("Some error occurred while uploading file to gcp for file :: {}",fileName, gcpException);
            throw new CustomInternalServerException("Failed to upload file:: " + fileName + " to GCP", ErrorCodes.FAILED_TO_UPLOAD_FILE_TO_GCP);
        }
        try {
            return URLDecoder.decode(fileMetaData.getUrl(), String.valueOf(StandardCharsets.UTF_8));
        } catch (UnsupportedEncodingException e) {
            logger.error("Error while decoding file url from GCP. brandId :: {}, fileName :: {}", brandId, fileName);
            throw new CustomInternalServerException("Failed to decode file url from GCP. brandId :: " + brandId + " fileName :: " + fileName, ErrorCodes.FAILED_TO_DECODE_FILE_URL);
        }
    }

    private StorageObject createStorageObject(Integer brandId, String migrationBucketName, String fileName) {
        String key = createFullyQualifiedPath(Constants.BASE_FILE_PATH, migrationBucketName, brandId, fileName);
        return StorageObject.Builder().uniqueName(key).contentType(Constants.APPLICATION_OCTET_STREAM_VALUE).fileLabel(fileName).build();
    }

    private String createFullyQualifiedPath(String baseFilePath, String migrationBucketName, Integer brandId, String fileName) {
        String path = baseFilePath;
        path = path.replaceFirst("\\[BRAND_ID\\]", Integer.toString(brandId));
        path = path.replaceFirst("\\[BUCKET_NAME\\]", migrationBucketName);
        path = path.replaceFirst("\\[FILE_NAME\\]", fileName.replace(" ","_"));
        return path;
    }

    public InputStream downloadFile(String attachmentUrl) {
        try {
            URLConnection website = new URL(attachmentUrl).openConnection();
            website.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)");
            website.setRequestProperty("Accept", "*/*");
            InputStream in = website.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(in);
            return bis;
        } catch (MalformedURLException e){
            logger.error("Cannot download file for url ::" + attachmentUrl);
            throw new CustomInternalServerException("Cannot download file for url ::" + attachmentUrl, ErrorCodes.FAILED_TO_DOWNLOAD_FILE);
        } catch (IOException e) {
            logger.error("IO exception occurred for url::" + attachmentUrl);
            throw new CustomInternalServerException("IO exception occurred for url::" + attachmentUrl, ErrorCodes.FAILED_TO_DOWNLOAD_FILE);
        }
    }
}

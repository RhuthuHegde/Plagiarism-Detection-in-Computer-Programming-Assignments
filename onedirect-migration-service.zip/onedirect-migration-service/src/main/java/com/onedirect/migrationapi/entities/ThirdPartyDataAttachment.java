package com.onedirect.migrationapi.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "third_party_data_attachment")
public class ThirdPartyDataAttachment implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "brand_id")
    private Integer brandId;
    @Column(name = "third_party_data_id")
    private Long thirdPartyDataId;
    @Column(name = "attachment_name")
    private String attachmentName;
    @Column(name = "attachment_url")
    private String attachmentUrl;
    @Column(name = "created_by")
    private Integer createdBy;
    @Column(name = "created_at")
    private Date createdAt;
    @Column(name = "updated_at")
    private Date updatedAt;
    @Column(name = "record_status")
    private Byte recordStatus;
}
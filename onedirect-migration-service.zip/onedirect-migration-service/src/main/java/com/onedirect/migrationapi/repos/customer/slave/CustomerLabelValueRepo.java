package com.onedirect.migrationapi.repos.customer.slave;

import com.onedirect.migrationapi.entities.CustomerLabelValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerLabelValueRepo extends JpaRepository<CustomerLabelValue,Long> {
    @Query(value = "SELECT clv FROM CustomerLabelValue clv WHERE clv.customerId =?1 AND clv.customerLabelId = ?2")
    CustomerLabelValue findCustomerLabelValueByCustomerIdAndCustomerLabelId(Long customerId, Integer customerLabelId);
}

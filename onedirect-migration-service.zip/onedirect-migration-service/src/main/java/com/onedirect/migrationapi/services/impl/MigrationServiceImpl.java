package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.onedirect.migrationapi.bos.ConversationListBo;
import com.onedirect.migrationapi.bos.CustomFieldBo;
import com.onedirect.migrationapi.bos.CustomerBo;
import com.onedirect.migrationapi.bos.TicketListBo;
import com.onedirect.migrationapi.configs.MigrationRabbitMQConfig;
import com.onedirect.migrationapi.converters.CustomConverterMapperUtil;
import com.onedirect.migrationapi.dtos.*;
import com.onedirect.migrationapi.entities.*;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.enums.MigrationStatusEnum;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.exceptions.ServiceException;
import com.onedirect.migrationapi.pojos.*;
import com.onedirect.migrationapi.services.*;
import com.onedirect.migrationapi.repos.onedirect.slave.TicketRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author hrishikesh
 */

@Service
public class MigrationServiceImpl implements MigrationService {


    @Autowired
    RedisCacheService redisCacheService;

    @Autowired
    TicketRepository ticketRepository;

    private static final Logger logger = LoggerFactory.getLogger(MigrationServiceImpl.class);


    @Autowired
    FileTransferService fileTransferService;

    @Autowired
    ThirdPartyDataAttachmentService thirdPartyDataAttachmentService;


    @Autowired
    ForwardFeedAttachmentService forwardFeedAttachmentService;


    @Autowired
    TicketFieldValueService ticketFieldValueService;

    @Autowired
    MigrationRabbitMQConfig rabbitMQConfig;

    @Autowired
    PlatformMigrationFactory platformMigrationFactory;

    @Autowired
    MigrationDataService migrationDataService;

    private static Gson gson = new Gson();

    @Resource(name = "BrandFieldConfiguration")
    private Map<Integer, BrandFieldConfiguration> brandFieldConfigurationMap;


    public PlatformMigrationService getPlatformMigrationService(Integer platformId){
        if(Objects.isNull(platformId)){
            throw new ServiceException(ErrorCodes.BAD_REQUEST.getCode(), "PlatformID cannot be null");
        }
        PlatformMigrationService platformMigrationService = platformMigrationFactory.getPlatformMigrationService(platformId);
        if(Objects.isNull(platformMigrationService)){
            throw new ServiceException(ErrorCodes.BAD_REQUEST.getCode(),"Invalid platformID");
        }
        return platformMigrationService;
    }
    private void pushMigrationRequestToQueue(MigrationRequestDto migrationRequestDto) {
        rabbitMQConfig.rabbitTemplate().convertAndSend(migrationRequestDto);
    }
    @Override
    public void handleMigrationRequest(MigrationRequestDto migrationRequestDto){
        PlatformMigrationService platformMigrationService = getPlatformMigrationService(migrationRequestDto.getPlatformId());
        validateMigrationRequest(migrationRequestDto,platformMigrationService);
        pushMigrationRequestToQueue(migrationRequestDto);
    }
    @Override
    public void processMigrationRequest(MigrationRequestDto migrationRequestDto){
        Integer migrationLogId = createMigrationLogFromDto(migrationRequestDto);
        PlatformMigrationService platformMigrationService = getPlatformMigrationService(migrationRequestDto.getPlatformId());
        startMigration(migrationLogId,platformMigrationService);
    }
    @Override
    public void processAttachmentFromQueue(QueuedAttachmentsDto queuedAttachmentsDto) throws CustomInternalServerException{
        PlatformMigrationService platformMigrationService = platformMigrationFactory.getPlatformMigrationService(queuedAttachmentsDto.getPlatformId());
        if(Objects.isNull(queuedAttachmentsDto.getForwardFeedId())){
            createThirdPartyDataAttachments(platformMigrationService,queuedAttachmentsDto.getAttachmentListJson(),queuedAttachmentsDto.getBrandId(),
                    queuedAttachmentsDto.getThirdPartyDataId());
            logger.info("Attachments processed for third party data id :: {}",queuedAttachmentsDto.getThirdPartyDataId());
        }else {
            createForwardFeedAttachment(platformMigrationService,queuedAttachmentsDto.getBrandId(), queuedAttachmentsDto.getForwardFeedId(),
                    queuedAttachmentsDto.getCreatedAt(),queuedAttachmentsDto.getAttachmentListJson(),
                    queuedAttachmentsDto.getPlatformConversationId());
            logger.info("Attachments processed for forward feed id :: {}",queuedAttachmentsDto.getForwardFeedId());
        }
    }

    private void createForwardFeedAttachment(PlatformMigrationService platformMigrationService,Integer brandId, Long forwardFeedId, Date createdAt,
                                             String attachmentListJson, Long platformConversationId) {
        List<ForwardFeedAttachmentDto> forwardFeedAttachmentDtoList = platformMigrationService.uploadAttachmentsForForwardFeed(attachmentListJson,brandId);
        migrationDataService.createForwardFeedAttachment(brandId,forwardFeedId,createdAt,forwardFeedAttachmentDtoList,platformConversationId);
    }

    private void createThirdPartyDataAttachments(PlatformMigrationService platformMigrationService,
                                                 String attachmentListJson, Integer brandId, Long thirdPartyDataId) {
        Map<String,String> uploadedAttachments = platformMigrationService.uploadAttachmentsForThirdPartyData(attachmentListJson,brandId);
        for (Map.Entry mapEntry : uploadedAttachments.entrySet()) {
            migrationDataService.addThirdPartyDataAttachment((String) mapEntry.getKey(), (String) mapEntry.getValue(), brandId, thirdPartyDataId.intValue());
        }
    }

    private void startMigration(Integer migrationLogId,PlatformMigrationService platformMigrationService) {
        logger.info("Migration in progress for migration log id :: {}", migrationLogId);
        long startTime = System.nanoTime();
        updateMigrationStatus(migrationLogId, MigrationStatusEnum.IN_PROGRESS.getId());
        MigrationLog migrationLog = migrationDataService.getMigrationLogById(migrationLogId);
        BrandConfigurationEntity brandConfigurationEntity =
                migrationDataService.getBrandConfigurationEntityById(migrationLog.getBrandConfigurationId());
        BrandConfigurationDto brandConfigurationDto =
                CustomConverterMapperUtil.map(brandConfigurationEntity, BrandConfigurationDto.class);
        BrandFieldConfiguration brandFieldConfiguration = brandFieldConfigurationMap.get(brandConfigurationDto.getBrandId());
        //Keeps track of number of tickets processed so far
        TicketMigrationStats ticketMigrationStats = new TicketMigrationStats();
        try {
            platformMigrationService.performPreMigration(brandConfigurationDto,migrationLog,brandFieldConfiguration);
            TicketListBo ticketListBo = platformMigrationService.getTickets(brandConfigurationDto,migrationLog,null);
            while (shouldMigrationContinue(platformMigrationService,ticketListBo,migrationLog,ticketMigrationStats,brandConfigurationDto)){
                migrateTickets(platformMigrationService,ticketListBo,ticketMigrationStats,brandConfigurationDto,migrationLog,brandFieldConfiguration);
                ticketListBo = platformMigrationService.getTickets(brandConfigurationDto,migrationLog,ticketListBo.getParams());
            }
        }
        catch (CustomInternalServerException customInternalServerException){
            logger.info("There was a problem processing this request , ERROR CODE :: {}  ERROR MESSAGE :: {}",
                    customInternalServerException.getErrorCode().getCode(),
                    customInternalServerException.getErrorCode().getMessage());
            updateMigrationStatus(migrationLogId, MigrationStatusEnum.FAILED.getId());
        }
        long endTime  = System.nanoTime();
        long elapsedTime = endTime - startTime;
        double seconds = (double)elapsedTime / 1_000_000_000.0;
        logger.info("Migration completed for migration log id :: {} and took a total time of :: {}s",
                migrationLogId,seconds);
        logger.info("No of migrated tickets :: {}",ticketMigrationStats.getTicketsMigrated());
        logger.info("No of failed tickets :: {}",ticketMigrationStats.getTicketsFailed());
        logger.info("No of tickets already migrated :: {}",ticketMigrationStats.getTicketsAlreadyMigrated());
        logger.info("Total no of tickets processed :: {}",ticketMigrationStats.getTicketsProcessed());
        updateMigrationStatus(migrationLogId, MigrationStatusEnum.COMPLETED.getId());
    }

    private void migrateTickets(PlatformMigrationService platformMigrationService,TicketListBo ticketListBo,
                                TicketMigrationStats ticketMigrationStats,
                                BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog,
                                BrandFieldConfiguration brandFieldConfiguration) {
        for(Object platformTicket:ticketListBo.getTicketList()){
            if(shouldTicketBeMigrated(platformMigrationService, platformTicket,ticketMigrationStats,brandConfigurationDto,
                    migrationLog,brandFieldConfiguration)){
                try{
                    ConversationListBo conversationListBo = platformMigrationService.getConversationsForTicket(
                            platformTicket,brandConfigurationDto);
                    PlatformCustomerMappingEntity platformCustomerMappingEntity = getPlatformCustomerMappingEntity(
                            platformMigrationService,
                            platformTicket,brandConfigurationDto,brandFieldConfiguration);
                    Long brandUserId = getBrandUserId(platformMigrationService,platformTicket,
                            brandConfigurationDto);
                    Long latestBrandTicketId = getBrandTicketIdFromRedis(brandConfigurationDto.getBrandId());
                    Ticket ticket = createTicketFromPlatformTicket(platformMigrationService,platformTicket,
                            brandConfigurationDto.getBrandId(),
                            platformCustomerMappingEntity.getOneDirectCustomerId(),
                            brandUserId.intValue(),latestBrandTicketId);
                    ThirdPartyData thirdPartyData = platformMigrationService.createThirdPartyDataForTicket(ticket,conversationListBo.getPlatformConversations().get(0));
                    ThirdPartyTicketMapping thirdPartyTicketMapping =
                            createThirdPartyTicketMapping(ticket, thirdPartyData.getId(),
                                    platformCustomerMappingEntity.getOneDirectCustomerId(), brandUserId);
                    List<QueuedAttachmentsDto> queuedAttachmentsDtoList = new ArrayList<>();
                    addThirdPartyDataAttachment(platformMigrationService,queuedAttachmentsDtoList,
                            conversationListBo.getPlatformConversations(),platformTicket,ticket,
                            thirdPartyData,brandConfigurationDto);
                    processForwardFeed(platformMigrationService,platformTicket,
                            conversationListBo.getPlatformConversations(),ticket,brandConfigurationDto,
                            queuedAttachmentsDtoList,platformCustomerMappingEntity.getOneDirectCustomerId(),
                            brandFieldConfiguration);
                    if(Objects.nonNull(brandFieldConfiguration)){
                        List<TicketFieldValue> ticketFieldValueList = createTicketFieldValueForPlatformTicket(
                                platformMigrationService, ticket, brandConfigurationDto.getBrandId(),platformTicket,
                                brandFieldConfiguration);
                        List<TicketTag> ticketTag = createTicketTagsForPlatformTicket(platformMigrationService,
                                platformTicket,ticket, brandConfigurationDto.getBrandId(), brandFieldConfiguration);
                    }
                    pushAttachmentsIntoQueue(queuedAttachmentsDtoList);
                    createTicketMigrationLog(platformMigrationService,migrationLog,ticket,platformTicket);
                    ticketMigrationStats.setTicketsMigrated(ticketMigrationStats.getTicketsMigrated()+1);
                } catch (Exception e) {
                    ticketMigrationStats.setTicketsFailed(ticketMigrationStats.getTicketsFailed()+1);
                    platformMigrationService.createTicketFailureMigrationLog(brandConfigurationDto.getBrandId(),migrationLog.getId(),platformTicket,e);
                }

            }
        }
    }

    private void createTicketMigrationLog(PlatformMigrationService platformMigrationService, MigrationLog migrationLog,
                                          Ticket ticket, Object platformTicket) {
        platformMigrationService.createTicketSuccessMigrationLog(migrationLog.getId(),ticket,platformTicket);
    }

    private void processForwardFeed(PlatformMigrationService platformMigrationService,Object platformTicket,
                                    List<Object> platformConversations, Ticket ticket,
                                    BrandConfigurationDto brandConfigurationDto,
                                    List<QueuedAttachmentsDto> queuedAttachmentsDtoList,
                                    Long customerId,BrandFieldConfiguration brandFieldConfiguration) {
        for(int i=1;i<platformConversations.size();i++){
            Object platformConversation = platformConversations.get(i);
            ForwardFeed forwardFeed = createForwardFeedForConversation(platformMigrationService,ticket,
                    platformConversation,platformTicket);
            if(Objects.nonNull(forwardFeed)){
                ForwardCustomerInfo forwardCustomerInfo =
                        createForwardCustomerInfoForPlatformConversation(platformMigrationService,forwardFeed,
                                platformTicket,platformConversation,brandConfigurationDto,customerId,
                                brandFieldConfiguration);
                ForwardFeedReferenceIds forwardFeedReferenceIds =
                        migrationDataService.createForwardFeedReferenceIds(forwardFeed);
                addForwardFeedAttachment(platformMigrationService,
                        ticket,brandConfigurationDto,forwardFeed,platformTicket,
                        platformConversation,queuedAttachmentsDtoList);
            }
        }
    }

    private void addForwardFeedAttachment(PlatformMigrationService platformMigrationService,Ticket ticket,
                                          BrandConfigurationDto brandConfigurationDto, ForwardFeed forwardFeed,
                                          Object platformTicket, Object platformConversation,
                                          List<QueuedAttachmentsDto> queuedAttachmentsDtoList
                                          ) {
        QueuedAttachmentsDto queuedAttachmentsDto = platformMigrationService
                .createQueuedAttachmentDto(platformConversation,ticket,null,
                        brandConfigurationDto,forwardFeed);
        if(Objects.nonNull(queuedAttachmentsDto)){
            queuedAttachmentsDtoList.add(queuedAttachmentsDto);
        }
    }

    private ForwardCustomerInfo createForwardCustomerInfoForPlatformConversation(PlatformMigrationService platformMigrationService,
                                                                                 ForwardFeed forwardFeed,
                                                                                 Object platformTicket,
                                                                                 Object platformConversation,
                                                                                 BrandConfigurationDto brandConfigurationDto,
                                                                                 Long customerId,
                                                                                 BrandFieldConfiguration brandFieldConfiguration
                                                                                 ) {
        ForwardCustomerInfoValueJsonDto forwardCustomerInfoValueDto = platformMigrationService
                .createForwardCustomerInfoValueDto(platformTicket,platformConversation,brandConfigurationDto,customerId,brandFieldConfiguration);
        return migrationDataService.createForwardCustomerInfo(forwardFeed,gson.toJson(forwardCustomerInfoValueDto));
    }

    private ForwardFeed createForwardFeedForConversation(PlatformMigrationService platformMigrationService,Ticket ticket, Object platformConversation, Object platformTicket) {
        ForwardFeed forwardFeed = platformMigrationService.createForwardFeed(ticket,platformConversation,platformTicket);
        return migrationDataService.addForwardFeed(forwardFeed);
    }

    private void addThirdPartyDataAttachment(PlatformMigrationService platformMigrationService,List<QueuedAttachmentsDto> queuedAttachmentsDtoList,
                                             List<Object> platformConversations, Object platformTicket,
                                             Ticket ticket, ThirdPartyData thirdPartyData,
                                             BrandConfigurationDto brandConfigurationDto) {
        if (platformConversations.size() > 0) {
            QueuedAttachmentsDto queuedAttachmentsDto = platformMigrationService.createQueuedAttachmentDto(
                    platformConversations.get(0),ticket,
                    thirdPartyData, brandConfigurationDto,null);
            if (Objects.nonNull(queuedAttachmentsDto)) {
                queuedAttachmentsDtoList.add(queuedAttachmentsDto);
            }
        }
    }

    private ThirdPartyTicketMapping createThirdPartyTicketMapping(Ticket ticket, Long thirdPartyDataId, Long oneDirectCustomerId, Long brandUserId) {
        return migrationDataService.createThirdPartyTicketMapping(ticket,thirdPartyDataId,oneDirectCustomerId,brandUserId);
    }

    private List<TicketTag> createTicketTagsForPlatformTicket(PlatformMigrationService platformMigrationService,
                                                              Object platformTicket, Ticket ticket, Integer brandId,
                                                              BrandFieldConfiguration brandFieldConfiguration) {
        List<TicketTag> ticketTagList = platformMigrationService.createTicketTagsForPlatformTicket(platformTicket,
                ticket,brandId,brandFieldConfiguration);
        List<TicketTag> resultantList = new ArrayList<>();
        for(TicketTag tag:ticketTagList){
            resultantList.add(migrationDataService.addTag(tag));
        }
        return resultantList;
    }

    private List<TicketFieldValue> createTicketFieldValueForPlatformTicket(PlatformMigrationService platformMigrationService,
                                                                           Ticket ticket, Integer brandId,
                                                                           Object platformTicket,
                                                                           BrandFieldConfiguration brandFieldConfiguration) {
        List<CustomFieldBo> customFieldBoList = platformMigrationService.getCustomFieldBoList(platformTicket);
        List<TicketFieldValue> ticketFieldValueList =mapTicketFieldValues(platformMigrationService,platformTicket,
                ticket,brandId,customFieldBoList,brandFieldConfiguration);
        List<TicketFieldValue> resultantList = new ArrayList<>();
        for(TicketFieldValue ticketFieldValue:ticketFieldValueList){
            resultantList.add(migrationDataService.addTicketFieldValue(ticketFieldValue));
        }
        return resultantList;
    }

    private Ticket createTicketFromPlatformTicket(PlatformMigrationService platformMigrationService,Object platformTicket, Integer brandId,
                                                  Long oneDirectCustomerId, Integer brandUserId, Long latestBrandTicketId) {
        Ticket ticket = platformMigrationService.createTicketFromPlatformTicket(platformTicket,brandId,oneDirectCustomerId,brandUserId,latestBrandTicketId);
        return migrationDataService.addTicket(ticket);
    }

    private Long getBrandUserId(PlatformMigrationService platformMigrationService,
                                Object platformTicket, BrandConfigurationDto brandConfigurationDto) {
        return platformMigrationService.getBrandUserId(platformTicket,brandConfigurationDto);
    }

    private PlatformCustomerMappingEntity getPlatformCustomerMappingEntity(PlatformMigrationService platformMigrationService,
                                                                           Object platformTicket, BrandConfigurationDto brandConfigurationDto,
                                                                           BrandFieldConfiguration brandFieldConfiguration
                                                                           ){
        PlatformCustomerMappingEntity platformCustomerMappingEntity = platformMigrationService
                .getPlatformCustomerMapping(platformTicket,brandConfigurationDto);
        if(Objects.isNull(platformCustomerMappingEntity)){
            CustomerBo platformCustomer = platformMigrationService.getCustomerForTicket(platformTicket,brandConfigurationDto);
            Customer customer = createCustomer(platformMigrationService,platformCustomer,brandConfigurationDto);
            createCustomerLabelValue(platformMigrationService,customer,platformCustomer,brandConfigurationDto,brandFieldConfiguration);
            platformCustomerMappingEntity = platformMigrationService.createPlatformCustomerMapping(platformCustomer.getPlatformCustomer(),brandConfigurationDto,customer);
        }
        return platformCustomerMappingEntity;
    }

    private List<CustomerLabelValue> createCustomerLabelValue(PlatformMigrationService platformMigrationService,Customer customer, CustomerBo platformCustomer,
                                          BrandConfigurationDto brandConfigurationDto,
                                          BrandFieldConfiguration brandFieldConfiguration) {
        List<CustomerLabelValue> customerLabelValueList = platformMigrationService.createCustomerLabelValue(customer,platformCustomer,brandConfigurationDto,brandFieldConfiguration);
        List<CustomerLabelValue> resultList = new ArrayList<>();
        for(CustomerLabelValue customerLabelValue:customerLabelValueList){
            resultList.add(migrationDataService.addCustomerLabelValue(customerLabelValue));
        }
        return resultList;
    }

    private Customer createCustomer(PlatformMigrationService platformMigrationService, CustomerBo platformCustomer,
                                    BrandConfigurationDto brandConfigurationDto) {
        Customer customer = platformMigrationService.createCustomerFromPlatformCustomer(platformCustomer,brandConfigurationDto);
        return migrationDataService.addCustomer(customer);
    }

    private boolean shouldTicketBeMigrated(PlatformMigrationService platformMigrationService, Object ticket,
                                           TicketMigrationStats ticketMigrationStats,
                                           BrandConfigurationDto brandConfigurationDto, MigrationLog migrationLog,
                                           BrandFieldConfiguration brandFieldConfiguration
                                           ) {
        if( (Objects.nonNull(migrationLog.getNumberOfTickets()) && ticketMigrationStats.getTicketsProcessed() < migrationLog.getNumberOfTickets())
                || Objects.isNull(migrationLog.getNumberOfTickets())){
            return platformMigrationService.shouldTicketBeMigrated(ticket,ticketMigrationStats,brandConfigurationDto,migrationLog,brandFieldConfiguration);
        }
        return false;
    }

    private boolean shouldMigrationContinue(PlatformMigrationService platformMigrationService,
                                            TicketListBo ticketListBo, MigrationLog migrationLog,
                                            TicketMigrationStats ticketMigrationStats, BrandConfigurationDto brandConfigurationDto) {
             return  Objects.nonNull(ticketListBo) && Objects.nonNull(ticketListBo.getTicketList()) &&
                        !(Objects.nonNull(migrationLog.getNumberOfTickets())
                                && ticketMigrationStats.getTicketsProcessed().equals(migrationLog.getNumberOfTickets()))
                && platformMigrationService.shouldMigrationContinue(ticketListBo,ticketMigrationStats,migrationLog,brandConfigurationDto);
    }

    private void updateMigrationStatus(Integer migrationLogId, Byte migrationStatus) {
        MigrationLog migrationLog = migrationDataService.getMigrationLogById(migrationLogId);
        if (Objects.isNull(migrationLog)) {
            throw new CustomInternalServerException("Unable to update migration status, No migration log with id:: "
                    + migrationLogId + " found.", ErrorCodes.UPDATE_MIGRATION_LOG_ERROR);
        }
        migrationLog.setMigrationStatus(migrationStatus);
        migrationDataService.createMigrationLog(migrationLog);
    }

    private Integer createMigrationLogFromDto(MigrationRequestDto migrationRequestDto) {
        BrandConfigurationEntity brandConfigurationEntity = migrationDataService.getBrandConfigurationEntityByBrandIdAndPlatformId(
                migrationRequestDto.getBrandId(),migrationRequestDto.getPlatformId());
        MigrationLogDto migrationLogDto = new MigrationLogDto();
        migrationLogDto.setBrandConfigurationId(brandConfigurationEntity.getId());
        migrationLogDto.setRecordStatus((byte) 1);
        migrationLogDto.setStartTimestamp(migrationRequestDto.getStartTime());
        migrationLogDto.setEndTimestamp(migrationRequestDto.getEndTime());
        migrationLogDto.setMigrationStatus(MigrationStatusEnum.ENQUEUED.getId());
        migrationLogDto.setCreatedAt(new Date());
        migrationLogDto.setNumberOfTickets(migrationRequestDto.getNumberOfTickets());
        if(Objects.nonNull(migrationRequestDto.getFileNames()) && migrationRequestDto.getFileNames().size()>0){
            migrationLogDto.setFileList(gson.toJson(migrationRequestDto.getFileNames()));
        }else{
            migrationLogDto.setFileList(null);
        }
        MigrationLog migrationLog = CustomConverterMapperUtil.map(migrationLogDto, MigrationLog.class);
        return migrationDataService.createMigrationLog(migrationLog);
    }

    private void validateMigrationRequest(MigrationRequestDto migrationRequestDto, PlatformMigrationService platformMigrationService) {
        if (!isMigrationEnabledForBrandAndPlatform(
                migrationRequestDto.getBrandId(), migrationRequestDto.getPlatformId())) {
            logger.info("Migration is disabled for brandId :: {}", migrationRequestDto.getBrandId());
            throw new ResponseStatusException(HttpStatus.METHOD_NOT_ALLOWED, "Migration is disabled for brand.");
        }
        BrandConfigurationEntity brandConfigurationEntity = migrationDataService
                .getBrandConfigurationEntityByBrandIdAndPlatformId(migrationRequestDto.getBrandId(),
                        migrationRequestDto.getPlatformId());
        BrandFieldConfiguration brandFieldConfiguration = brandFieldConfigurationMap.get(brandConfigurationEntity.getBrandId());
        platformMigrationService.validateMigrationRequest(migrationRequestDto,brandConfigurationEntity,brandFieldConfiguration);
    }


    public Boolean isMigrationEnabledForBrandAndPlatform(Integer brandId, Integer platformId) {
        BrandConfigurationEntity brandConfigurationEntity = migrationDataService.getBrandConfigurationEntityByBrandIdAndPlatformId(brandId, platformId);
        if(Objects.isNull(brandConfigurationEntity)) {
            throw new CustomInternalServerException("Brand Configuration not found for brandId:: " + brandId
                    + " and platformId:: " + platformId, ErrorCodes.BRAND_CONFIGURATION_NOT_FOUND);
        }
        return brandConfigurationEntity.getIsMigrationEnabled();
    }

    public Long getBrandTicketIdFromRedis(Integer brandId) {
        Long brandTicketId = redisCacheService.incrementAndGetAtomicLong(brandId + "_ticketCount");
        if (brandTicketId == null || brandTicketId <= 1) {
            Long maxBrandTicketId = ticketRepository.getMaxBrandTicketId(brandId);
            if (maxBrandTicketId == null) {
                if (brandTicketId == null) {
                    brandTicketId = redisCacheService.incrementAndGetAtomicLong(brandId + "_ticketCount");
                }
            } else {
                redisCacheService.setAtomicLong(brandId + "_ticketCount", maxBrandTicketId);
                brandTicketId = redisCacheService.incrementAndGetAtomicLong(brandId + "_ticketCount");
            }
        }
        return brandTicketId;
    }

    @Override
    public void pushAttachmentsIntoQueue(List<QueuedAttachmentsDto> queuedAttachmentsDtoList) {
        for(QueuedAttachmentsDto queuedAttachmentsDto:queuedAttachmentsDtoList){
            rabbitMQConfig.attachmentsRabbitTemplate().convertAndSend(queuedAttachmentsDto);
        }
    }

    public List<TicketFieldValue> mapTicketFieldValues(PlatformMigrationService platformMigrationService,Object platformTicket,Ticket ticket, Integer brandId,
                                                       List<CustomFieldBo> platformCustomFieldList,
                                                       BrandFieldConfiguration brandFieldConfiguration) {
        List<TicketFieldValue> ticketFieldValueList = new ArrayList<>();
        //Get the ticketfield mapping configuration for the given brandID
        BrandTicketFieldConfiguration brandTicketFieldConfiguration = brandFieldConfiguration.getBrandTicketFieldConfiguration();
        if(Objects.nonNull(brandTicketFieldConfiguration)){
            //A map with the key as the platform custom field ID and value as a list all the options for it .
            Map<String, List<PlatformTicketFieldOption>> ticketFieldOptionsMap = brandTicketFieldConfiguration.getTicketFieldOptionMap();
            //A map with key as platform custom field ID and value as the corresponding one direct label values for it ( type of field on OD and its label ID ).
            Map<String, TicketFieldLabel> ticketFieldLabelsMap = brandTicketFieldConfiguration.getTicketFieldLabelMap();

            //Go through the list of all custom fields for the platform ticket
            for(CustomFieldBo platformCustomField:platformCustomFieldList){
                //Checking if the current custom field has been requested for migration by the brand
                TicketFieldLabel ticketFieldLabel = ticketFieldLabelsMap.get(platformCustomField.getKey());
                if(Objects.isNull(ticketFieldLabel)){
                    continue;
                }
                // If the current field is a dropdown , getOneDirectTicketFieldOptionForGivenPlatformCustomField()
                // will return the OneDirect option mapping for it.
                PlatformTicketFieldOption platformTicketFieldOption = getOneDirectTicketFieldOptionForGivenPlatformCustomField(ticketFieldOptionsMap,platformCustomField);
                //If option is null that means it's not a dropdown field and the optionId will be set to null
                Long optionId = Objects.isNull(platformTicketFieldOption)?null: platformTicketFieldOption.getOptionId();
                //If option is null it means that it's not a dropdown field and its value will be set to whatever
                // value was set in the platform ticket.
                String optionValue = Objects.isNull(platformTicketFieldOption)?platformCustomField.getValue(): platformTicketFieldOption.getOptionValue();
                if(optionValue!=null){
                    TicketFieldValue ticketFieldValue = migrationDataService.buildTicketFieldValueFromTicket(ticket,brandId,
                            ticketFieldLabel.getLabelId(), ticketFieldLabel.getTicketFieldValueType(),optionId,optionValue);
                    ticketFieldValueList.add(ticketFieldValue);
                }
            }
        }
        //All tickets migrated from Platform will require a "Platform ticket ID" field to be populated
        // with the corresponding Platform ticket ID
        TicketFieldValue platformTicketIdTicketField = platformMigrationService.getPlatformTicketIdTicketField(ticket,brandId,platformTicket,brandFieldConfiguration);
        if(Objects.nonNull(platformTicketIdTicketField)){
            ticketFieldValueList.add(platformTicketIdTicketField);
        }
        return ticketFieldValueList;
    }
    private PlatformTicketFieldOption getOneDirectTicketFieldOptionForGivenPlatformCustomField(Map<String, List<PlatformTicketFieldOption>> ticketFieldOptionsMap, CustomFieldBo customFieldBo) {
        List<PlatformTicketFieldOption> ticketFieldOptionList = ticketFieldOptionsMap.get(customFieldBo.getKey().toString());
        if(Objects.nonNull(ticketFieldOptionList) && customFieldBo.getValue()!=null){
            for(PlatformTicketFieldOption option:ticketFieldOptionList){
                if(customFieldBo.getValue().toLowerCase().equals(option.getPlatformOptionValue().toLowerCase())){
                    return option;
                }
            }
        }
        return null;
    }
}

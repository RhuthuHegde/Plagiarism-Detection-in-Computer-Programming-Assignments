package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.CustomerLabelValue;

public interface CustomerLabelValueService {
    public CustomerLabelValue addCustomerLabelValue(CustomerLabelValue customerLabelValue);
    public CustomerLabelValue getCustomerLabelValueByCustomerIdAndCustomerLabelId(Long customerId,Integer customerLabelId);
}

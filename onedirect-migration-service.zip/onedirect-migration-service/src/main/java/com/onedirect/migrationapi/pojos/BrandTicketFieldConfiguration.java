package com.onedirect.migrationapi.pojos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@AllArgsConstructor
public class BrandTicketFieldConfiguration {
    Map<String, List<PlatformTicketFieldOption>> ticketFieldOptionMap;
    Map<String, TicketFieldLabel> ticketFieldLabelMap;
}

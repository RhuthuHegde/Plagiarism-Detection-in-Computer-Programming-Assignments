package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.repos.customer.master.CustomerMasterRepo;
import com.onedirect.migrationapi.repos.customer.slave.CustomerRepo;
import com.onedirect.migrationapi.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    CustomerMasterRepo customerMasterRepo;

    @Autowired
    CustomerRepo customerRepo;

    @Override
    public Customer addCustomer(Customer customer) {
        return customerMasterRepo.save(customer);
    }

    public Customer findCustomerById(Long customerId){
        Optional<Customer> optionalCustomer =  customerRepo.findById(customerId);
        if(optionalCustomer.isPresent()){
            return optionalCustomer.get();
        }else{
            throw new CustomInternalServerException("Unable to find customer");
        }
    }

}

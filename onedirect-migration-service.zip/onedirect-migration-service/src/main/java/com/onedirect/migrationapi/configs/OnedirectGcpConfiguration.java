package com.onedirect.migrationapi.configs;

import com.google.auth.Credentials;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.onedirect.datautils.enums.StorageEnvironment;
import com.onedirect.datautils.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import java.io.IOException;

/**
 * @author jp
 */

@Configuration
@ComponentScan
@PropertySource(
        ignoreResourceNotFound = true,
        value = {"classpath:gcp.properties"}
)
public class OnedirectGcpConfiguration {
    @Value("${gcp.credential.staging.path}")
    private String googleCredentialStagingPath;
    @Value("${gcp.credential.production.path}")
    private String googleCredentialProductionPath;
    @Value("${gcp.project_id}")
    private String projectId;
    @Autowired
    private Environment env;

    public OnedirectGcpConfiguration() {
    }

    @Bean
    public Storage gcpStorageInstance() throws IOException {
        Credentials credentials = GoogleCredentials.fromStream(FileUtil.getInputStream(this.environmentCredentials(), this));
        return (Storage)((StorageOptions.Builder)((StorageOptions.Builder)StorageOptions.newBuilder().setCredentials(credentials)).setProjectId(this.projectId)).build().getService();
    }

    private String environmentCredentials() {
        String storageEnvironment = this.env.getProperty("storage.environment");
        return StorageEnvironment.getByName(storageEnvironment) == StorageEnvironment.PRODUCTION ? this.googleCredentialProductionPath : this.googleCredentialStagingPath;
    }
}

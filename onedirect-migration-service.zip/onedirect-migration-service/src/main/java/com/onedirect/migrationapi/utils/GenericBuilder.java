package com.onedirect.migrationapi.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * @author jp
 */

public class GenericBuilder<Ttype> {

    private final Supplier<Ttype> INSTANCE;
    private List<Consumer<Ttype>> instanceModifiers = new ArrayList<>();


    public GenericBuilder(Supplier<Ttype> instance) {
        this.INSTANCE = instance;
    }

    public static <Ttype> GenericBuilder<Ttype> of(Supplier<Ttype> instantiator) {
        return new GenericBuilder<>(instantiator);
    }

    public <U> GenericBuilder<Ttype> with(BiConsumer<Ttype, U> consumer, U value) {
        Consumer<Ttype> consumer1 = instance -> consumer.accept(instance, value);
        instanceModifiers.add(consumer1);
        return this;
    }

    public Ttype build() {
        Ttype value = INSTANCE.get();
        instanceModifiers.forEach(modifier -> modifier.accept(value));
        instanceModifiers.clear();
        return value;
    }
}

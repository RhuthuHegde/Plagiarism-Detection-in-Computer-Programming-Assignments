package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.ThirdPartyDataAttachment;

public interface ThirdPartyDataAttachmentService {
    public ThirdPartyDataAttachment createThirdPartyDataAttachment(ThirdPartyDataAttachment thirdPartyDataAttachment);

    ThirdPartyDataAttachment generateThirdPartyDataAttachment(Integer brandId,
                                                              Long thirdPartyDataId,
                                                              String attachmentName,
                                                              String attachmentUrl);
}

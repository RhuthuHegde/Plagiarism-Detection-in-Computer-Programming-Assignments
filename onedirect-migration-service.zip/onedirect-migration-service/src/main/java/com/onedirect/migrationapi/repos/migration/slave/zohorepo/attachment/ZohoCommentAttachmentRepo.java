package com.onedirect.migrationapi.repos.migration.slave.zohorepo.attachment;

import com.onedirect.migrationapi.entities.zoho.agentcomment.ZohoUploadAttachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ZohoCommentAttachmentRepo extends JpaRepository<ZohoUploadAttachment,Long> {
    ZohoUploadAttachment findZohoUploadAttachmentByCommentId(Long commentId);
}

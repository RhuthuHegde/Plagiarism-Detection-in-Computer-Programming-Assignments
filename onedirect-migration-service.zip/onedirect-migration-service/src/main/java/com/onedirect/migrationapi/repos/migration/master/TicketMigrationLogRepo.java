package com.onedirect.migrationapi.repos.migration.master;

import com.onedirect.migrationapi.entities.TicketMigrationLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TicketMigrationLogRepo extends JpaRepository<TicketMigrationLog,Long> {
}

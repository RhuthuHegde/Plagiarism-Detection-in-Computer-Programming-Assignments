package com.onedirect.migrationapi.repos.migration.slave.zohorepo.ticket;

import com.onedirect.migrationapi.entities.zoho.ticket.ZohoTicket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ZohoTicketRepo extends JpaRepository<ZohoTicket,Long> {
    @Query("SELECT zti FROM ZohoTicket zti WHERE zti.id=?1")
    ZohoTicket findZohoTicketByID(Long ID);
    @Query("SELECT zti FROM ZohoTicket zti")
    List<ZohoTicket> findAll();
}

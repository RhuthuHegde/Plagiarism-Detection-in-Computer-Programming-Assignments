package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.BrandUser;
import com.onedirect.migrationapi.repos.onedirect.master.BrandUserRepo;
import com.onedirect.migrationapi.services.BrandUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BrandUserServiceImpl implements BrandUserService {

    @Autowired
    BrandUserRepo brandUserRepo;

    @Override
    public void addBrandUser(BrandUser brandUser) {
        System.out.println(brandUserRepo.save(brandUser));
    }
}

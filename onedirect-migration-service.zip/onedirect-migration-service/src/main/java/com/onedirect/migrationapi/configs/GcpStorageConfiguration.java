package com.onedirect.migrationapi.configs;

import org.springframework.context.annotation.Configuration;

/**
 * @author jp
 */

@Configuration
public @interface GcpStorageConfiguration {
}

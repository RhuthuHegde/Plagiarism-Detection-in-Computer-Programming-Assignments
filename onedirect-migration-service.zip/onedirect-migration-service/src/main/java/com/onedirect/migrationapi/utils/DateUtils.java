package com.onedirect.migrationapi.utils;

import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class DateUtils {
    public static Date convertToDate(String s, String format){
        if(Objects.nonNull(s)||s.equals("")){
            return null;
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        Date d = null;
        try{
            d = simpleDateFormat.parse(s);
        }catch (Exception e){
            throw new CustomInternalServerException("There was an error trying to convert the date :: "+s, ErrorCodes.FAILED_TO_CONVERT_DATE);
        }
        return d;
    }
    public static Date convertIsoDateStringToDate(String s){
        if(Objects.isNull(s) || s.equals("")){
            return null;
        }else{
            return Date.from(Instant.parse(s));
        }
    }

    public static Date convertIsoDataStringWithZoneToDate(String s){
        if(Objects.isNull(s) || s.equals("")){
            return null;
        }else{
            Instant instant = DateTimeFormatter.ISO_OFFSET_DATE_TIME.parse(s, Instant::from);
            return Date.from(instant);
        }
    }
}

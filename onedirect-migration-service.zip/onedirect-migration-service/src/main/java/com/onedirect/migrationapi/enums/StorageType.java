package com.onedirect.migrationapi.enums;

import com.onedirect.datautils.exceptions.InvalidStorageParameter;

/**
 * @author jp
 */

public enum StorageType {
    S3(0),
    GCP(1);

    private int id;

    public int getId() {
        return id;
    }

    private StorageType(int id) {
        this.id = id;
    }

    public static StorageType getById(int id) {
        StorageType[] var1 = values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            StorageType storageType = var1[var3];
            if(storageType.getId() == id) {
                return storageType;
            }
        }
        throw new InvalidStorageParameter("Unable to find the storage type for id :: " + id, new String[0]);
    }
}

package com.onedirect.migrationapi.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.Date;

/**
 * @author jp
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class MigrationLogDto {

    private Integer id;

    private Integer brandConfigurationId;

    private Byte recordStatus;

    private Byte migrationStatus;

    private Long startTimestamp;

    private Long endTimestamp;

    private Date createdAt;

    private Date updatedAt;

    private Long numberOfTickets;

    private String fileList;
}

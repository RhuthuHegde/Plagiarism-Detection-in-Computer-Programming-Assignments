package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.CustomerLabelValue;
import com.onedirect.migrationapi.repos.customer.master.CustomerLabelValueMasterRepo;
import com.onedirect.migrationapi.repos.customer.slave.CustomerLabelValueRepo;
import com.onedirect.migrationapi.services.CustomerLabelValueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerLabelValueServiceImpl implements CustomerLabelValueService {

    @Autowired
    CustomerLabelValueMasterRepo customerLabelValueMasterRepo;

    @Autowired
    CustomerLabelValueRepo customerLabelValueRepo;

    @Override
    public CustomerLabelValue addCustomerLabelValue(CustomerLabelValue customerLabelValue) {
        return customerLabelValueMasterRepo.save(customerLabelValue);
    }

    @Override
    public CustomerLabelValue getCustomerLabelValueByCustomerIdAndCustomerLabelId(Long customerId, Integer customerLabelId) {
        return customerLabelValueRepo.findCustomerLabelValueByCustomerIdAndCustomerLabelId(customerId,customerLabelId);
    }
}

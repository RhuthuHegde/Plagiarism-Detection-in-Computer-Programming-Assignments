package com.onedirect.migrationapi.pojos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TicketMigrationStats {
    private Long ticketsMigrated;
    private Long ticketsFailed;
    private Long ticketsAlreadyMigrated;

    public Long getTicketsProcessed(){
        return ticketsMigrated+ticketsFailed+ticketsAlreadyMigrated;
    }

    public TicketMigrationStats(){
        ticketsMigrated = (long)0;
        ticketsFailed = (long)0;
        ticketsAlreadyMigrated = (long)0;
    }
}

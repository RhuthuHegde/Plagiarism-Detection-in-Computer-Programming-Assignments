package com.onedirect.migrationapi.entities.zoho;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ZohoEvent {

    private Long id;
    private Long departmentId;
    private String subject;
    private String category;
    private String status;
    private Date startTime;
    private Long ticketId;
    private Long contactId;
    private String priority;
    private Long ownerId;
    private String description;
    private String reminder;
    private Long creatorId;
    private Long modifiedBy;
    private Date createdTime;
    private Date modifiedTime;
    private Long teamId;
    private Integer duration;
    private Long layoutId;
    private Date completedTime;
}

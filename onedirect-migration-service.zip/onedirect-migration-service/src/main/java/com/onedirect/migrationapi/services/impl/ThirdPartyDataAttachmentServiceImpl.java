package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.entities.ThirdPartyDataAttachment;
import com.onedirect.migrationapi.repos.onedirect.master.ThirdPartyDataAttachmentRepo;
import com.onedirect.migrationapi.services.ThirdPartyDataAttachmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class ThirdPartyDataAttachmentServiceImpl implements ThirdPartyDataAttachmentService {

    @Autowired
    ThirdPartyDataAttachmentRepo thirdPartyDataAttachmentRepo;

    @Override
    public ThirdPartyDataAttachment createThirdPartyDataAttachment(ThirdPartyDataAttachment thirdPartyDataAttachment) {
        return thirdPartyDataAttachmentRepo.save(thirdPartyDataAttachment);
    }

    @Override
    public ThirdPartyDataAttachment generateThirdPartyDataAttachment(Integer brandId, Long thirdPartyDataId, String attachmentName, String attachmentUrl) {
        ThirdPartyDataAttachment thirdPartyDataAttachment = new ThirdPartyDataAttachment();
        thirdPartyDataAttachment.setBrandId(brandId);
        thirdPartyDataAttachment.setThirdPartyDataId(thirdPartyDataId);
        thirdPartyDataAttachment.setAttachmentName(attachmentName);
        thirdPartyDataAttachment.setAttachmentUrl(attachmentUrl);
        thirdPartyDataAttachment.setCreatedBy(Constants.INT_SYSTEM_USER);
        thirdPartyDataAttachment.setCreatedAt(new Date());
        thirdPartyDataAttachment.setUpdatedAt(new Date());
        thirdPartyDataAttachment.setRecordStatus((byte) 1);
        return thirdPartyDataAttachment;
    }
}

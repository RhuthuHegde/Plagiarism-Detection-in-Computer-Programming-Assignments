package com.onedirect.migrationapi.constants.brand;

public class WazirxConstants {
    public static Integer WAZIRX_BRAND_ID = 8404;
    public static Integer WAZIRX_ONEDIRECT_LABEL_ID_FOR_TICKET_FIELD_ZENDESK_TICKET_ID = 11833;
    public static Integer WAZIRX_TICKET_TAG_ID = 32421;
    public static Integer WAZIRX_EMAIL_CUSTOMER_FIELD = 10263;
}

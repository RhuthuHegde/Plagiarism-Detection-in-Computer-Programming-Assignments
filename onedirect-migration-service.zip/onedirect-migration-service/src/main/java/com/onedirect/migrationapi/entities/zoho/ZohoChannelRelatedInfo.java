package com.onedirect.migrationapi.entities.zoho;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZohoChannelRelatedInfo {

    private String forumStatus;
    private String topicType;
    private String sourceLink;
    private Boolean isTopicDeleted;
}

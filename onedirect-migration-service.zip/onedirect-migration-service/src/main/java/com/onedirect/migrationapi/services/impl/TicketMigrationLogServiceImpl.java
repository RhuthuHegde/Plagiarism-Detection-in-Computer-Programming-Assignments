package com.onedirect.migrationapi.services.impl;

import com.onedirect.migrationapi.entities.TicketMigrationLog;
import com.onedirect.migrationapi.repos.migration.master.TicketMigrationLogRepo;
import com.onedirect.migrationapi.services.TicketMigrationLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TicketMigrationLogServiceImpl implements TicketMigrationLogService {

    @Autowired
    TicketMigrationLogRepo ticketMigrationLogRepo;

    @Override
    public TicketMigrationLog createTicketMigrationLog(TicketMigrationLog ticketMigrationLog) {
        return ticketMigrationLogRepo.save(ticketMigrationLog);
    }
}

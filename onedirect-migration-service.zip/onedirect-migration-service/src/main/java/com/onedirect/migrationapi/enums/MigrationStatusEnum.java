package com.onedirect.migrationapi.enums;

import java.util.HashMap;

/**
 * @author jp
 */
public enum MigrationStatusEnum {

    ENQUEUED((byte)0),
    IN_PROGRESS((byte)1),
    FAILED((byte)2),
    COMPLETED((byte)3);

    /**
     * The constant values.
     */
    public static final String values;

    /**
     * The reverse map.
     */
    static HashMap<Byte, MigrationStatusEnum> reverseMap;

    static {
        String sep = "";
        String val = "";
        reverseMap = new HashMap<>();
        for (MigrationStatusEnum migrationStatusEnum : MigrationStatusEnum.values()) {
            reverseMap.put(migrationStatusEnum.getId(), migrationStatusEnum);
            val += sep + migrationStatusEnum.id;
            sep = ",";
        }
        values = "(" + val + ")";
    }

    private byte id;

    MigrationStatusEnum(byte id) {
        this.id = id;
    }

    public byte getId() {
        return id;
    }


    public static MigrationStatusEnum getEnumById(Integer id) {
        if(id == null) {
            return null;
        }
        return reverseMap.get(id.byteValue());
    }

    public static boolean isValidId(Integer id) {
        if(id == null) {
            return true;
        }
        return reverseMap.containsKey(id.byteValue());
    }
}

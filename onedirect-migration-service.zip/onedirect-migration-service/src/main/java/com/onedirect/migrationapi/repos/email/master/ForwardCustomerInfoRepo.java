package com.onedirect.migrationapi.repos.email.master;

import com.onedirect.migrationapi.entities.ForwardCustomerInfo;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface ForwardCustomerInfoRepo extends JpaRepository<ForwardCustomerInfo, Long> {

    @Query(value = "select cinf from ForwardCustomerInfo cinf where cinf.feedId=:feedId and cinf.brandId=:brandId and cinf.status=1")
    ForwardCustomerInfo findByFeedIdAndBrandId(@Param("feedId") Long feedId, @Param("brandId") Integer brandId);

    @Transactional
    @Modifying
    @Query(value = "update ForwardCustomerInfo cinf set cinf.valueJson=:valueJson where " +
            "cinf.feedId=:feedId and" +
            " cinf.brandId=:brandId " +
            "and cinf.status=1")
    void updateByFeedIdAndBrandId(@Param("feedId") Long feedId, @Param("brandId") Integer brandId, @Param("valueJson") String valueJson);
}

package com.onedirect.migrationapi.dtos;

import com.onedirect.commonutils.utils.JsonUtil;
import com.onedirect.migrationapi.exceptions.InvalidStorageParameter;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jp
 */

public class StorageObject {
    private String uniqueName;
    private String fileLabel;
    private String contentType;
    private String contentDisposition;

    private StorageObject(StorageObject.Builder builder) {
        this.uniqueName = builder.uniqueName;
        this.contentType = builder.contentType;
        this.fileLabel = builder.fileLabel;
        this.contentDisposition = builder.contentDisposition;
    }

    public static StorageObject.Builder Builder() {
        return new StorageObject.Builder();
    }

    public String getUniqueName() {
        return this.uniqueName;
    }

    public void setUniqueName(String uniqueName) {
        this.uniqueName = uniqueName;
    }

    public String getContentType() {
        return this.contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileLabel() {
        return this.fileLabel;
    }

    public void setFileLabel(String fileLabel) {
        this.fileLabel = fileLabel;
    }

    public String getContentDisposition() {
        return this.contentDisposition;
    }

    public void setContentDisposition(String contentDisposition) {
        this.contentDisposition = contentDisposition;
    }

    public void validate() {
        List<String> messages = new ArrayList();
        if (this.fileLabel == null) {
            this.fileLabel = this.uniqueName;
        }

        if (this.uniqueName == null) {
            messages.add("Name of the file cannot be null");
        }

        if (messages.size() > 0) {
            throw new InvalidStorageParameter(StringUtils.join(new List[]{messages}), new String[0]);
        }
    }

    public String toString() {
        return JsonUtil.toJson(this);
    }

    public static final class Builder {
        private String uniqueName;
        private String contentType;
        private String fileLabel;
        private String contentDisposition;

        private Builder() {
        }

        public StorageObject build() {
            return new StorageObject(this);
        }

        public StorageObject.Builder uniqueName(String name) {
            this.uniqueName = name;
            return this;
        }

        public StorageObject.Builder contentType(String contentType) {
            this.contentType = contentType;
            return this;
        }

        public StorageObject.Builder fileLabel(String fileLabel) {
            this.fileLabel = fileLabel;
            return this;
        }

        public StorageObject.Builder contentDisposition(String contentDisposition) {
            this.contentDisposition = contentDisposition;
            return this;
        }
    }
}

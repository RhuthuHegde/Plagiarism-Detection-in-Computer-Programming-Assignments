package com.onedirect.migrationapi.constants.brand;

public class AsortConstants {
    public static Integer ASORT_BRAND_ID = 8424;
    public static Integer ASORT_ONEDIRECT_LABEL_ID_FOR_TICKET_FIELD_FRESHDESK_TICKET_ID = 12551;
    public static Integer ASORT_EMAIL_CUSTOMER_FIELD = 10630;
    public static Integer ASORT_PHONE_FIELD = 10628;
}

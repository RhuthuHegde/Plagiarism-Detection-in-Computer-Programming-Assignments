package com.onedirect.migrationapi.pojos;

import com.onedirect.migrationapi.enums.TicketFieldValueTypeEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PresetTicketFieldOption extends TicketFieldOption{
    private Integer labelId;
    private TicketFieldValueTypeEnum ticketFieldValueType;

    public PresetTicketFieldOption(String optionValue, Long optionId, Integer labelId,TicketFieldValueTypeEnum ticketFieldValueType) {
        super(optionValue, optionId);
        this.labelId = labelId;
        this.ticketFieldValueType = ticketFieldValueType;
    }
}

//package com.onedirect.migrationapi.dtos.zoho;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.onedirect.migrationapi.constants.MigrationPlatformConstants;
//import com.onedirect.migrationapi.dtos.zoho.contact.ZohoContact;
//import com.onedirect.migrationapi.dtos.zoho.ticket.ZohoTicket;
//import java.io.IOException;
//import java.net.URL;
//import java.util.Map;
//
//public class JsontoObject {
//    ObjectMapper mapper=new ObjectMapper();
//
//    public void setJsonObjectTicket() throws IOException {
//        ZohoTicket ticket=mapper.readValue(new URL(MigrationPlatformConstants.ZOHO_TICKET_FETCH_URL),ZohoTicket.class);
//        String cfJson= String.valueOf(ticket.getCf());
//        CustomFields customFields=mapper.readValue(cfJson,CustomFields.class);
//    }
//
//    public void setJsonObjectContact() throws IOException {
//        ZohoContact contact=mapper.readValue(new URL(MigrationPlatformConstants.ZOHO_USER_FETCH_URL),ZohoContact.class);
//        String cfJson= String.valueOf(contact.getCf());
//        CustomFields customFields=mapper.readValue(cfJson,CustomFields.class);
////        Map<String,String>  map=customFields.getCustomFields();
////        for(String key: map.keySet())
////        {
////            System.out.println(key+" "+map.get(key));
////        }
////    }
//}

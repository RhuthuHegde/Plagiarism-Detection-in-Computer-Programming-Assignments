package com.onedirect.migrationapi.dtos.zendesk;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZendeskTicketParty {
    private String address;
    private String name;
    @JsonProperty("original_recipients")
    private String originalRecipients;
    @JsonProperty("ticket_id")
    private String ticketId;
    private String subject;
    private String id;
    private String title;
    private Object deleted;
    @JsonProperty("revision_id")
    private String revisionId;
    @JsonProperty("topic_id")
    private String topicId;
    @JsonProperty("topic_name")
    private String topicName;
    @JsonProperty("profile_url")
    private String profileUrl;
    private String phone;
    @JsonProperty("formatted_phone")
    private String formattedPhone;
    @JsonProperty("facebook_id")
    private String facebookId;
    @JsonProperty("service_info")
    private String serviceInfo;
    @JsonProperty("supports_channelback")
    private String supportsChannelBack;
    @JsonProperty("supports_clickthrough")
    private String supportsClickthrough;
    @JsonProperty("registered_integration_service_name")
    private String registeredIntegrationServiceName;
}

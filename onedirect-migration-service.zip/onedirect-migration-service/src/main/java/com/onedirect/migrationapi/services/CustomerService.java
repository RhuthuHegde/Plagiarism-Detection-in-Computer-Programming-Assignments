package com.onedirect.migrationapi.services;

import com.onedirect.migrationapi.entities.Customer;

public interface CustomerService {
    public Customer addCustomer(Customer customer);
    public Customer findCustomerById(Long customerId);
}

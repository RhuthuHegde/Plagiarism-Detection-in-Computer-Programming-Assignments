package com.onedirect.migrationapi;

import com.onedirect.migrationapi.runnable.RealTimeDbConnectionLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.PostConstruct;

@ComponentScan(basePackages = {"com.onedirect"})
@SpringBootApplication
public class OnedirectMigrationServiceApplication {

    @Autowired
    RealTimeDbConnectionLogger realTimeDbConnectionLogger;

    public static void main(String[] args) {
        SpringApplication.run(OnedirectMigrationServiceApplication.class, args);
    }

    @PostConstruct
    public void runDbThreadLogger() {
        final Thread t = new Thread(realTimeDbConnectionLogger);
        t.start();
    }

}

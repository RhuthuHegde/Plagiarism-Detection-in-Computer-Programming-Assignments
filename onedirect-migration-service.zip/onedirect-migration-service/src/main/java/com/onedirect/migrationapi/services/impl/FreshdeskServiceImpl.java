package com.onedirect.migrationapi.services.impl;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.onedirect.migrationapi.constants.Constants;
import com.onedirect.migrationapi.constants.MigrationPlatformConstants;
import com.onedirect.migrationapi.converters.CustomConverterMapperUtil;
import com.onedirect.migrationapi.dtos.ForwardFeedAttachmentDto;
import com.onedirect.migrationapi.dtos.ForwardFeedDto;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskAttachment;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskTicketsDto;
import com.onedirect.migrationapi.dtos.freshdesk.FreshdeskUserDto;
import com.onedirect.migrationapi.dtos.freshdesk.conversation.HelpdeskNote;
import com.onedirect.migrationapi.dtos.freshdesk.ticket.HelpdeskTicket;
import com.onedirect.migrationapi.dtos.freshdesk.user.FreshdeskUser;
import com.onedirect.migrationapi.entities.Customer;
import com.onedirect.migrationapi.entities.ForwardFeed;
import com.onedirect.migrationapi.entities.Ticket;
import com.onedirect.migrationapi.enums.ErrorCodes;
import com.onedirect.migrationapi.exceptions.CustomInternalServerException;
import com.onedirect.migrationapi.services.FileTransferService;
import com.onedirect.migrationapi.services.FreshdeskService;
import com.onedirect.migrationapi.services.MigrationDataService;
import com.onedirect.migrationapi.services.XMLFileReaderService;
import com.onedirect.migrationapi.services.xmlhandler.TicketHandler;
import com.onedirect.migrationapi.services.xmlhandler.UserHandler;
import com.onedirect.migrationapi.utils.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.*;

@Service
public class FreshdeskServiceImpl implements FreshdeskService {

    @Autowired
    XMLFileReaderService xmlFileReaderService;

    @Autowired
    MigrationDataService migrationDataService;

    @Autowired
    FileTransferService fileTransferService;

    private static Gson gson = new Gson();
    private static final Logger logger = LoggerFactory.getLogger(FreshdeskServiceImpl.class);

    @Override
    public FreshdeskTicketsDto getFreshDeskTicketsDtoFromFile(Integer brandId, String fileName) {
        TicketHandler ticketHandler = new TicketHandler();
        String ticketsPath = createDataPath(MigrationPlatformConstants.FRESHDESK_FILE_PATH,
                brandId,fileName,MigrationPlatformConstants.FRESHDESK_TICKETS_FOLDER_NAME);
        File f = new File(ticketsPath);
        if(!f.exists()){
            logger.info("Ticket file :: {} does not exist",fileName);
            return null;
        }
        try {
            xmlFileReaderService.readAndParseXMLFileWithHandler(ticketsPath, ticketHandler);
            if (Objects.nonNull(ticketHandler.getFreshdeskTicketsDto()) && Objects.nonNull(ticketHandler
                    .getFreshdeskTicketsDto().getHelpdeskTicketList()) && ticketHandler.getFreshdeskTicketsDto().getHelpdeskTicketList().size() > 0) {
                return ticketHandler.getFreshdeskTicketsDto();
            }else{
                    throw new CustomInternalServerException(ErrorCodes.FRESHDESK_TICKETS_NOT_FOUND_FOR_FILE_NAME.getMessage(),ErrorCodes.FRESHDESK_TICKETS_NOT_FOUND_FOR_FILE_NAME);
            }
        }catch (Exception e){
            logger.info("Unable to parse file :: {}",fileName);
            return null;
        }
    }

    @Override
    public String createDataPath(String baseFilePath, Integer brandId, String fileName, String data){
        String path = baseFilePath;
        path = path.replaceFirst("\\[BRAND_ID\\]", Integer.toString(brandId));
        path = path.replaceFirst("\\[DATA\\]", data);
        path = path.replaceFirst("\\[FILE_NAME\\]",fileName);
        return path;
    }

    @Override
    public Boolean doTicketsExistForBrand(Integer brandId) {
        String brandDirectoryPath = createDataPath(MigrationPlatformConstants.FRESHDESK_DIR_PATH,
                brandId,"","");
        String ticketsDirectoryPath = createDataPath(MigrationPlatformConstants.FRESHDESK_DIR_PATH,
                brandId,"",MigrationPlatformConstants.FRESHDESK_TICKETS_FOLDER_NAME);
        String customersDirectoryPath = createDataPath(MigrationPlatformConstants.FRESHDESK_DIR_PATH,
                brandId,"",MigrationPlatformConstants.FRESHDESK_USER_FOLDER_NAME);
        return doesPathExist(brandDirectoryPath) && doesPathExist(ticketsDirectoryPath)
                && doesPathExist(customersDirectoryPath);
    }

    @Override
    public HelpdeskNote createFirstHelpdeskNoteFromTicket(HelpdeskTicket helpdeskTicket) {
        HelpdeskNote helpdeskNote = new HelpdeskNote();
        helpdeskNote.setCreatedAt(helpdeskTicket.getCreatedAt());
        helpdeskNote.setUpdatedAt(helpdeskTicket.getUpdatedAt());
        helpdeskNote.setBody(helpdeskTicket.getDescription());
        helpdeskNote.setFreshdeskAttachmentList(helpdeskTicket.getFreshdeskAttachmentList());
        helpdeskNote.setSource(0);
        helpdeskNote.setBodyHtml(helpdeskTicket.getDescriptionHtml());
        helpdeskNote.setIncoming(true);
        helpdeskNote.set_private(false);
        helpdeskNote.setId(helpdeskTicket.getDisplayId());
        return helpdeskNote;
    }

    @Override
    public FreshdeskUserDto getFreshdeskUserDtoFromFile(File file){
        UserHandler userHandler = new UserHandler();
        xmlFileReaderService.readAndParseXMLFileWithHandler(file.getAbsolutePath(),userHandler);
        return userHandler.getFreshdeskUserDto();
    }

    @Override
    public List<Customer> buildCustomersFromFreshdeskUserDto(FreshdeskUserDto freshdeskUserDto, Integer brandId) {
        List<Customer> customerList = new ArrayList<>();
        for(FreshdeskUser freshdeskUser:freshdeskUserDto.getFreshdeskUserList()){
            customerList.add(createCustomerFromFreshdeskUser(freshdeskUser,brandId));
        }
        return customerList;
    }

    @Override
    public Ticket buildTicketFromHelpdeskTicket(HelpdeskTicket helpdeskTicket,
                                                Integer brandId, Long customerId, Integer brandUserId,
                                                Long brandTicketId){
        Ticket ticket = new Ticket();
        ticket.setId(null);
        ticket.setCustomerId(customerId);
        ticket.setBrandId(brandId);
        ticket.setBrandTicketId(brandTicketId);
        ticket.setSource((byte)5);
        ticket.setSubSource((byte)8);
        if (Objects.nonNull(helpdeskTicket.getSubject())) {
            String odTicketSubject = helpdeskTicket.getSubject();
            if (odTicketSubject.length() > 250) {
                odTicketSubject = odTicketSubject.substring(0, 249);
            }
            ticket.setSubject(odTicketSubject);
        }
        else {
            ticket.setSubject("");
        }
        if (Objects.nonNull(helpdeskTicket.getDescription())) {
            String odTicketDescription = helpdeskTicket.getDescription();
            if (odTicketDescription.length() > 250) {
                odTicketDescription = odTicketDescription.substring(0, 249);
            }
            ticket.setShortDesc(odTicketDescription);
        }
        else {
            ticket.setShortDesc("");
        }
        if(helpdeskTicket.getSource().equals(MigrationPlatformConstants.FRESHDESK_TICKET_SOURCE_EMAIL)) {
            switch (helpdeskTicket.getStatus()) {
                case 2:
                    ticket.setCurrentStatus((byte) 1);
                    break;
                case 3:
                    ticket.setCurrentStatus((byte) 2);
                    break;
                case 4:
                    ticket.setCurrentStatus((byte) 4);
                    break;
                default:
                    ticket.setCurrentStatus((byte) 5);
                    break;
            }
        }else{
            ticket.setCurrentStatus((byte)5);
        }
        ticket.setCurrentPriority((byte)0);
        ticket.setTicketUrl(null);
        ticket.setTeamId(null);
        ticket.setFirstAssignmentDate(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskTicket.getCreatedAt()));
        ticket.setCurrentAssignmentDate(null);
        ticket.setCurrentlyAssignedTo(brandUserId);
        ticket.setResourcePublishDate(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskTicket.getCreatedAt()));
        ticket.setFirstBrandResponseDate(null);
        ticket.setLatestBrandResponseDate(null);
        ticket.setLatestCustomerResponseDate(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskTicket.getCreatedAt()));
        ticket.setDueDate(null);
        ticket.setCurrentSentiment((byte)2);
        ticket.setSlaBreachStatus((byte)0);
        ticket.setRefTicketId(null);
        ticket.setSplitParentId(null);
        ticket.setAccountId(null);
        ticket.setParentTicketId(null);
        ticket.setRequesterId(null);
        ticket.setTicketType((byte)0);
        ticket.setIsActionable((byte)1);
        ticket.setLastConversationDate(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskTicket.getCreatedAt()));
        ticket.setStatus((byte)1);
        ticket.setAssociationType((byte)0);
        ticket.setCurrentStatusUpdatedAt(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskTicket.getCreatedAt()));
        ticket.setCreatedAt(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskTicket.getCreatedAt()));
        ticket.setUpdatedAt(new Date());
        ticket.setCreatedBy(Constants.INT_SYSTEM_USER);
        ticket.setUpdatedBy(Constants.INT_SYSTEM_USER);
        ticket.setLastModifiedAt(new Date());
        ticket.setUpdatedByType((byte)1);
        ticket.setRecordStatus((byte)1);
        ticket.setFirstAssignedTo(null);
        ticket.setLastAssigneeUpdatedAt(null);
        ticket.setLastAssigneeResponseAt(null);
        return ticket;
    }

    private Customer createCustomerFromFreshdeskUser(FreshdeskUser freshdeskUser, Integer brandId) {
        Customer customer = new Customer();
        customer.setId(null);
        String name = null;
        if(Objects.isNull(freshdeskUser.getName()) || freshdeskUser.getName().isEmpty()){
            name = "nill";
        }else{
            name = freshdeskUser.getName();
        }
        if (name.length()>100){
            name = name.substring(0,99);
        }
        customer.setName(name);
        customer.setSource((byte)5);
        customer.setHandle(null);
        customer.setSourceUserId(null);
        customer.setProfilePictureUrl(null);
        customer.setStatus((byte)1);
        customer.setIsSpammer((byte)2);
        customer.setCreatedAt(DateUtils.convertIsoDataStringWithZoneToDate(freshdeskUser.getCreatedAt()));
        customer.setCreatedBy(Constants.INT_SYSTEM_USER);
        customer.setUpdatedAt(new Date());
        customer.setUpdatedBy(Constants.INT_SYSTEM_USER);
        customer.setBrandId(brandId);
        customer.setProductId((byte)1);
        customer.setExternalCustomerId(null);
        customer.setBrandCustomerId(null);
        return customer;
    }

    private Boolean doesPathExist(String path){
        File dir = new File(path);
        return dir.exists();
    }

    @Override
    public ForwardFeed generateForwardFeedEntity(Ticket ticket, HelpdeskNote helpdeskNote, HelpdeskTicket helpdeskTicket) {
        ForwardFeedDto forwardFeedDto = new ForwardFeedDto();
        forwardFeedDto.setBrandId(ticket.getBrandId());
        // TODO check brand user id
        if (helpdeskNote.getIncoming())
            forwardFeedDto.setCustomerId(ticket.getCustomerId());
        else
            forwardFeedDto.setBrandUserId(ticket.getCurrentlyAssignedTo().longValue());
        forwardFeedDto.setTicketId(ticket.getId());
        forwardFeedDto.setSubject(ticket.getSubject());
        forwardFeedDto.setResourceText(helpdeskNote.getBodyHtml());
        forwardFeedDto.setParsedResourceText(helpdeskNote.getBody());
        forwardFeedDto.setMessageType((byte) 4);
        forwardFeedDto.setMessageState((byte) 2);
        forwardFeedDto.setResourcePublishDate(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskNote.getCreatedAt()));
        forwardFeedDto.setStatus((byte) 1);
        forwardFeedDto.setCreatedAt(DateUtils.convertIsoDataStringWithZoneToDate(helpdeskNote.getCreatedAt()));
        forwardFeedDto.setUpdatedAt(new Date());
        ForwardFeed forwardFeedEntity = CustomConverterMapperUtil.map(forwardFeedDto, ForwardFeed.class);
        return forwardFeedEntity;
    }

    @Override
    public List<FreshdeskAttachment> getFreshdeskAttachmentsFromJson(String attachmentListJson) {
        return gson.fromJson(attachmentListJson,new TypeToken<List<FreshdeskAttachment>>(){}.getType());
    }

    @Override
    public Map<String, String> uploadAttachments(List<FreshdeskAttachment> freshdeskAttachmentList, Integer brandId) {
        Map<String,String> uploadedAttachments = new HashMap<>();
        freshdeskAttachmentList.forEach((freshdeskAttachment -> {
            uploadedAttachments.put(freshdeskAttachment.getContentFileName(),
                    fileTransferService.migrateAttachment(brandId,freshdeskAttachment.getAttachmentUrl(),
                            freshdeskAttachment.getContentFileName()));
        }));
        return uploadedAttachments;
    }

    @Override
    public List<ForwardFeedAttachmentDto> createForwardFeedAttachmentDtoList(List<FreshdeskAttachment> freshdeskAttachmentList, Integer brandId) {
        List<ForwardFeedAttachmentDto> valueJsonList = new ArrayList<>();
        for (FreshdeskAttachment freshdeskAttachment : freshdeskAttachmentList) {
            String gcpAttachmentUrl = fileTransferService.migrateAttachment(brandId,
                    freshdeskAttachment.getAttachmentUrl(), freshdeskAttachment.getContentFileName());
            ForwardFeedAttachmentDto forwardFeedAttachmentDto = new ForwardFeedAttachmentDto();
            forwardFeedAttachmentDto.setAttachmentName(freshdeskAttachment.getContentFileName());
            forwardFeedAttachmentDto.setAttachmentUrl(gcpAttachmentUrl);
            forwardFeedAttachmentDto.setAttachmentSize(freshdeskAttachment.getContentFileSize());
            forwardFeedAttachmentDto.setS3Bucket(2);
            valueJsonList.add(forwardFeedAttachmentDto);
        }
        return valueJsonList;
    }
}

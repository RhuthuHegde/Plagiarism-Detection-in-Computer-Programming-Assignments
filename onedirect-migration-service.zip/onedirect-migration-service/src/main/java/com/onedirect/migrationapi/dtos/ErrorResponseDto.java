package com.onedirect.migrationapi.dtos;

import com.onedirect.commonutils.utils.JsonUtil;

/**
 * @author jp
 */

public class ErrorResponseDto {

    private boolean isNewFormat = true;

    private String customMessageCode;

    private String err;

    public ErrorResponseDto() {
    }

    public ErrorResponseDto(String customMessageCode, String err) {
        this.customMessageCode = customMessageCode;
        this.err = err;
    }

    public boolean getIsNewFormat() {
        return isNewFormat;
    }

    public void setIsNewFormat(boolean isNewFormat) {
        this.isNewFormat = isNewFormat;
    }

    public String getCustomMessageCode() {
        return customMessageCode;
    }

    public void setCustomMessageCode(String customMessageCode) {
        this.customMessageCode = customMessageCode;
    }

    public void setErr(String err) {
        this.err = err;
    }

    public String getErr() {
        return err;
    }

    @Override
    public String toString() {
        return JsonUtil.toJson(this);
    }
}

package com.onedirect.migrationapi.repos.customer.master;

import com.onedirect.migrationapi.entities.CustomerLabelValue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerLabelValueMasterRepo extends JpaRepository<CustomerLabelValue,Long> {
}

package com.onedirect.migrationapi.entities.zoho.thread;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@Table(name="zoho_thread")
public class ZohoThread {
    @Id
    private Long id;
    private Long ticketId;
    private java.sql.Date createdTime;
    private String threadStatus;
    private String summary;
    private Boolean isPrivate;
    private String fromEmailAddress;
    private String receipients;
    private Long userId;
    private Long channelId;
}

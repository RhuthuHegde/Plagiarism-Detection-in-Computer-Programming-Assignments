package com.onedirect.migrationapi.constants.brand;

public class OneDirectConstants {
    public static Integer ONEDIRECT_BRAND_ID = 6221;
    public static Integer TESTING_ONEDIRECT_LABEL_ID_FOR_TICKET_FIELD_ZENDESK_TICKET_ID = 11907;
    public static Integer ONEDIRECT_EMAIL_CUSTOMER_FIELD = 1052;
    public static Integer ONEDIRECT_LABEL_ID_FOR_TICKET_FIELD_FRESHDESK_TICKET_ID = 12499;
}
